# from django.http import JsonResponse
from django.db.models import F, Value
from django.db.models.functions import Concat
# from django.shortcuts import render
# from django.views.decorators.csrf import csrf_exempt

from erp_models.ai_models import TbtInvtWarrantydealer as ai_warrantyDealer
from erp_models.ai_models import TbtInvtWarranty as ai_warranty
from erp_models.ai_models import TbtInvtWarrantyow as ai_warrantyOnline
from erp_models.ai_models import TbtInvtInvrqs as ai_gi
from erp_models.ai_models import TbmLgstCartype as ai_carType
from erp_models.ai_models import TbmLgstCarbrand as ai_carBrand
from erp_models.ai_models import TbmLgstCarmodel as ai_carModel
from erp_models.erp_models import Address as erp_address
from erp_models.erp_models import Province as erp_province
from erp_models.erp_models import District as erp_district
from erp_models.erp_models import Subdistrict as erp_subdistrict
from erp_models.erp_models import PostalCode as erp_zipCode
from erp_models.erp_models import CarBrand as erp_carBrand
from erp_models.erp_models import CarModel as erp_carModel
from erp_models.erp_models import Contact as erp_contact
from erp_models.erp_models import Product as erp_product
from erp_models.erp_models import Sex as erp_gender
from erp_models.erp_models import ServiceItem as erp_warranty
from erp_models.WOnline_models import MatchmakerAiProduct as erp_ai_brandmatch
from core.my_config import laminaPage_brand,xtraColePage_brand,glasiaPage_brand
# , District, Subdistrict, Contact

# Create your views here.
def orm_noneChecker(data,conditionKey):
    if data is not None:
        return getattr(data,conditionKey, None)
    else:
        return None
def get_ai_match_brand():
    aiProductBrand = {}
    tmpDatas = list(erp_ai_brandmatch.objects.using('WOnline').values('ai_product','erp_brand_id'))
    for data in tmpDatas:
        aiProductBrand[data['ai_product']]=data['erp_brand_id']
    return aiProductBrand
def get_ai_carBrand():
    aiCarBrand = {}
    tmpDatas = list(ai_carBrand.objects.using('ai').values('carbrandid','carbrandnm'))
    for data in tmpDatas:
        aiCarBrand[data['carbrandid']]=data['carbrandnm']
    return aiCarBrand
def get_ai_carModel():
    aiCarBrand = {}
    tmpDatas = list(ai_carModel.objects.using('ai').values('carmodelid','carmodelnm'))
    for data in tmpDatas:
        aiCarBrand[data['carmodelid']]=data['carmodelnm']
    return aiCarBrand
def get_ai_carType_byID(id):
    if id == 0:
        return ''
    tmpDatas = list(ai_carType.objects.using('ai').filter(cartypeid=id).values('cartypenm'))[0]['cartypenm']
    return tmpDatas
def get_ai_carBrand_byID(id):
    if id == 0:
        return ''
    tmpDatas = list(ai_carBrand.objects.using('ai').filter(carbrandid=id).values('carbrandnm'))[0]['carbrandnm']
    return tmpDatas
def get_ai_carModel_byID(id):
    if id == 0:
        return ''
    tmpDatas = list(ai_carModel.objects.using('ai').filter(carmodelid=id).values('carmodelnm'))[0]['carmodelnm']
    return tmpDatas
def ai_checkNull_productInstall (itemcd,intstallfilmscode):
    if intstallfilmscode != '':
        return intstallfilmscode
    else:
        return itemcd
def ai_check_nullProduct_returnHyphen(data):
    if data =='':
        return "-"
    else:
        return data
def ai_tranform_gender(data):
    if data == "M":
        return "Male"
    elif data == "F":
        return "Female"
    else:
        return "Another"
def ai_check_phone(data):
    if data != "":
        return "โทร "+ data
    else:
        return ""
def get_fullAddress(address,subdistrict,district,province,postcode):
    tmpTXT = ''
    if address!=None and subdistrict!=None and district!=None and postcode!=None:
        if province == "กรุงเทพมหานคร":
            tmpTXT = address + " แขวง" + subdistrict + " เขต" + district + " " + province + " " +postcode
        else:
            tmpTXT = address + " ตำบล" + subdistrict + " อำเภอ" + district + " จังหวัด" + province + " " +postcode
    return tmpTXT
def nonValue (data):
    if data is not None:
        return data
    else:
        return ''
def wNumberChecker(wNumber,pageBrand):
    ####data MarkUP
    datas = {
            'state':'',#'found/notFound',
            'sys_db':'',#'erp/ai',
            'register':'',#'registed/unRegisted',
            'brand':pageBrand,#'lamina/xtra-cole/glasia',
            'number_wrt':wNumber,
            'w_data':{
                'id_wrt':'',
                'product_id':'',
                'product_code':'',
                'contact_id':'',
                'contact_name':'',
                'contact_branch':'',
                'contact_namebranch':'',
                
                'cust_name':'',
                'cust_gender':'',
                'cust_birthday':'',
                'cust_address_full':'',
                'cust_address':'',
                'cust_subdistrict_id':'',
                'cust_subdistrict':'',
                'cust_district_id':'',
                'cust_district':'',
                'cust_province_id':'',
                'cust_province':'',
                'cust_postalcode':'',
                'cust_phone':'',
                'cust_mail':'',
                
                'cust_cartype':'',
                'cust_carbrand':'',
                'cust_carmodel':'',
                'cust_liceseplateblack':'',
                'cust_vin':'',
                'cust_install_date':'',
                'cust_warrant_exdate':'',
                
                'showroominstall_id':'',
                'showroominstall_name':'',
                'showroominstall_address':'',
                'showroominstall_phone':'',
                'another_position':''
    }}
    if pageBrand == 'lamina':
        productBrand = laminaPage_brand
    elif pageBrand == 'xtra-cole':
        productBrand = xtraColePage_brand
    elif pageBrand == 'glasia':
        productBrand = glasiaPage_brand
    else:
        datas['state'] = "notFound"
### Check in ERP:
    tmp_erpWarranty = list(erp_warranty.objects.filter(number = wNumber,product__brand__in=productBrand).exclude(state='voided').values('id',
            'state',
            'product',
            'product__code',
            'product__name',
            'contact',
            'contact__name',
            'contact__branch',
            'cust_name',
            'area_film_0',
            'cust_date',
            'warranty_exp_date',
            'cust_dob',
            'cust_sex_0',
            'cust_sex_0__name',
            'cust_phone', 
            'cust_address',
            'cust_subdistrict',
            'cust_district',
            'cust_province',
            'cust_country',                                                                                                                                            
            'cust_subdistrict__name',
            'cust_district__name',
            'cust_province__name',
            'cust_postal_code',
            'cust_country__name',
            'cust_license_plate_bk',
            'cust_vin',
            'cust_car_type_0',
            'cust_car_brand_0',
            'cust_car_model_0',
            'cust_car_type_0__name',
            'cust_car_brand_0__name',
            'cust_car_model_0__name',
            'cust_showroom',
            'cust_showroom_0',
            'cust_showroom_0__name',
            'cust_showroom_0__branch',
            'remark',
            'cust_license_plate',
            'front_license_plate',
            'remark'
            ))
### Check in AI:
    tmp_aiWarranty = list(ai_warrantyDealer.objects.using('ai').filter(warrantydealerno = wNumber).values('warrantydealerno','invrqsno','warrantydealerstt'))

    if len(tmp_erpWarranty) > 0:
        datas['state'] = "found"
        datas['sys_db'] = "erp"
        tmp_erp_showroomAddress = list(erp_address.objects.filter(contact=tmp_erpWarranty[0]['contact'],type='billing').values('address','province_0__name','phone'))
        
        # tmp_erp = erp_warranty.objects.using('erp').filter(number=wNumber).values('id','name')
        # datas = {'warranty_id': tmp_erpWarranty[0]['number']}
        if tmp_erpWarranty[0]['cust_name'] is not None and tmp_erpWarranty[0]['cust_car_brand_0'] is not None and tmp_erpWarranty[0]['cust_car_model_0'] is not None :
            datas['register'] = "registed"
            datas['w_data']['product_id'] = tmp_erpWarranty[0]['product']
            datas['w_data']['product_code'] = tmp_erpWarranty[0]['product__code']
            datas['w_data']['contact_id'] = tmp_erpWarranty[0]['contact']
            datas['w_data']['contact_name'] = tmp_erpWarranty[0]['contact__name']
            datas['w_data']['contact_branch'] = tmp_erpWarranty[0]['contact__branch']
            datas['w_data']['contact_namebranch'] = tmp_erpWarranty[0]['contact__name']+" "+tmp_erpWarranty[0]['contact__branch']
           
            datas['w_data']['cust_name'] = tmp_erpWarranty[0]['cust_name']
            datas['w_data']['cust_gender'] = tmp_erpWarranty[0]['cust_sex_0__name']
            datas['w_data']['cust_birthday'] = tmp_erpWarranty[0]['cust_dob']
            datas['w_data']['cust_address_full'] = get_fullAddress(tmp_erpWarranty[0]['cust_address'],tmp_erpWarranty[0]['cust_subdistrict__name'],tmp_erpWarranty[0]['cust_district__name'],tmp_erpWarranty[0]['cust_province__name'],tmp_erpWarranty[0]['cust_postal_code']) 
            datas['w_data']['cust_address'] = tmp_erpWarranty[0]['cust_address']
            datas['w_data']['cust_subdistrict_id'] = tmp_erpWarranty[0]['cust_subdistrict']
            datas['w_data']['cust_subdistrict'] =tmp_erpWarranty[0]['cust_subdistrict__name']
            datas['w_data']['cust_district_id'] = tmp_erpWarranty[0]['cust_district']
            datas['w_data']['cust_district'] = tmp_erpWarranty[0]['cust_district__name']
            datas['w_data']['cust_province_id'] = tmp_erpWarranty[0]['cust_province']
            datas['w_data']['cust_province'] = tmp_erpWarranty[0]['cust_province__name']
            datas['w_data']['cust_postalcode'] = tmp_erpWarranty[0]['cust_postal_code']
            datas['w_data']['cust_phone'] = tmp_erpWarranty[0]['cust_phone']
            
            datas['w_data']['cust_cartype_id'] = tmp_erpWarranty[0]['cust_car_type_0']
            datas['w_data']['cust_cartype'] = tmp_erpWarranty[0]['cust_car_type_0__name']
            datas['w_data']['cust_carbrand_id'] = tmp_erpWarranty[0]['cust_car_brand_0']
            datas['w_data']['cust_carbrand'] = tmp_erpWarranty[0]['cust_car_brand_0__name']
            datas['w_data']['cust_carmodel_id'] = tmp_erpWarranty[0]['cust_car_model_0']
            datas['w_data']['cust_carmodel'] = tmp_erpWarranty[0]['cust_car_model_0__name']
            datas['w_data']['cust_liceseplateblack'] = tmp_erpWarranty[0]['cust_license_plate_bk']
            datas['w_data']['cust_vin'] = tmp_erpWarranty[0]['cust_vin']
            datas['w_data']['cust_install_date'] =tmp_erpWarranty[0]['cust_date']
            datas['w_data']['cust_warrant_exdate'] = tmp_erpWarranty[0]['warranty_exp_date']
    
            datas['w_data']['showroominstall_id'] = tmp_erpWarranty[0]['cust_showroom_0']
            # datas['w_data']['showroominstall_name'] = tmp_erpWarranty[0]['cust_showroom_0__name']
            # datas['w_data']['showroominstall_branch'] = tmp_erpWarranty[0]['cust_showroom_0__branch']
            datas['w_data']['showroominstall_name'] = tmp_erpWarranty[0]['cust_showroom_0__name']+" "+nonValue(tmp_erpWarranty[0]['cust_showroom_0__branch'])
            datas['w_data']['showroominstall_address'] =  tmp_erp_showroomAddress[0]['address']
            datas['w_data']['showroominstall_phone'] = tmp_erp_showroomAddress[0]['phone']
            datas['w_data']['another_position'] = tmp_erpWarranty[0]['remark']
            print ('OK')
        elif tmp_erpWarranty[0]['cust_name'] is None and tmp_erpWarranty[0]['cust_car_brand_0'] is None and tmp_erpWarranty[0]['cust_car_model_0'] is None :
            datas['register'] = "unRegisted"
            datas['w_data']['product_id'] = tmp_erpWarranty[0]['product']
            datas['w_data']['product_code'] = tmp_erpWarranty[0]['product__code']
            datas['w_data']['contact_id'] = tmp_erpWarranty[0]['contact']
            datas['w_data']['contact_name'] = tmp_erpWarranty[0]['contact__name']
            datas['w_data']['contact_branch'] = tmp_erpWarranty[0]['contact__branch']
            datas['w_data']['contact_namebranch'] = tmp_erpWarranty[0]['contact__name']+" "+tmp_erpWarranty[0]['contact__branch']
           
        else:
            datas['state'] = "unCompleted"
            datas['register'] = "registed"
            datas['w_data']['product_id'] = tmp_erpWarranty[0]['product']
            datas['w_data']['product_code'] = tmp_erpWarranty[0]['product__code']
            datas['w_data']['contact_id'] = tmp_erpWarranty[0]['contact']
            datas['w_data']['contact_name'] = tmp_erpWarranty[0]['contact__name']
            datas['w_data']['contact_branch'] = tmp_erpWarranty[0]['contact__branch']
            datas['w_data']['contact_namebranch'] = tmp_erpWarranty[0]['contact__name']+" "+tmp_erpWarranty[0]['contact__branch']
           
            datas['w_data']['cust_name'] = tmp_erpWarranty[0]['cust_name']
            datas['w_data']['cust_gender'] = tmp_erpWarranty[0]['cust_sex_0__name']
            datas['w_data']['cust_birthday'] = tmp_erpWarranty[0]['cust_dob']
            datas['w_data']['cust_address_full'] = get_fullAddress(tmp_erpWarranty[0]['cust_address'],tmp_erpWarranty[0]['cust_subdistrict__name'],tmp_erpWarranty[0]['cust_district__name'],tmp_erpWarranty[0]['cust_province__name'],tmp_erpWarranty[0]['cust_postal_code']) 
            datas['w_data']['cust_address'] = tmp_erpWarranty[0]['cust_address']
            datas['w_data']['cust_subdistrict_id'] = tmp_erpWarranty[0]['cust_subdistrict']
            datas['w_data']['cust_subdistrict'] =tmp_erpWarranty[0]['cust_subdistrict__name']
            datas['w_data']['cust_district_id'] = tmp_erpWarranty[0]['cust_district']
            datas['w_data']['cust_district'] = tmp_erpWarranty[0]['cust_district__name']
            datas['w_data']['cust_province_id'] = tmp_erpWarranty[0]['cust_province']
            datas['w_data']['cust_province'] = tmp_erpWarranty[0]['cust_province__name']
            datas['w_data']['cust_postalcode'] = tmp_erpWarranty[0]['cust_postal_code']
            datas['w_data']['cust_phone'] = tmp_erpWarranty[0]['cust_phone']
            
            datas['w_data']['cust_cartype_id'] = tmp_erpWarranty[0]['cust_car_type_0']
            datas['w_data']['cust_cartype'] = tmp_erpWarranty[0]['cust_car_type_0__name']
            datas['w_data']['cust_carbrand_id'] = tmp_erpWarranty[0]['cust_car_brand_0']
            datas['w_data']['cust_carbrand'] = tmp_erpWarranty[0]['cust_car_brand_0__name']
            datas['w_data']['cust_carmodel_id'] = tmp_erpWarranty[0]['cust_car_model_0']
            datas['w_data']['cust_carmodel'] = tmp_erpWarranty[0]['cust_car_model_0__name']
            datas['w_data']['cust_liceseplateblack'] = tmp_erpWarranty[0]['cust_license_plate_bk']
            datas['w_data']['cust_vin'] = tmp_erpWarranty[0]['cust_vin']
            datas['w_data']['cust_install_date'] =tmp_erpWarranty[0]['cust_date']
            datas['w_data']['cust_warrant_exdate'] = tmp_erpWarranty[0]['warranty_exp_date']
    
            datas['w_data']['showroominstall_id'] = tmp_erpWarranty[0]['cust_showroom_0']
            # datas['w_data']['showroominstall_name'] = tmp_erpWarranty[0]['cust_showroom_0__name']
            # datas['w_data']['showroominstall_branch'] = tmp_erpWarranty[0]['cust_showroom_0__branch']
            datas['w_data']['showroominstall_name'] = tmp_erpWarranty[0]['cust_showroom_0__name']+" "+nonValue(tmp_erpWarranty[0]['cust_showroom_0__branch'])
            datas['w_data']['showroominstall_address'] =  tmp_erp_showroomAddress[0]['address']
            datas['w_data']['showroominstall_phone'] = tmp_erp_showroomAddress[0]['phone']
            datas['w_data']['another_position'] = tmp_erpWarranty[0]['remark']
    elif len(tmp_aiWarranty) > 0  :
        aiProduct_Brand = get_ai_match_brand()
        productCodeInAI = list(ai_gi.objects.using('ai').filter(invrqsno=tmp_aiWarranty[0]['invrqsno']).values('invrqsno','itemcd'))
        ## check brand of product == brand input ?
        
        if aiProduct_Brand[productCodeInAI[0]['itemcd']] in productBrand:
            datas['state']="found"
            datas['sys_db']="ai"
        
    ###### check wNumber Registed ?
    ########################################################################
    ######### Get Data To PrintingData  -----> Add column More Here
            tmp_ai_CSInput = list(ai_warranty.objects.using('ai').filter(warrantyno=wNumber,customerfirstname__gt='').annotate(cust_name=Concat( F('customerfirstname'),  Value(' '), F('customerlastname'))).values('cust_name','cartypeid','carbrandid','carmodelid','itemcd','installfilmcode','installdate','carchasis','carlicenseno','customersex','customermb','email','customeraddress','customertambol','customeramphur','customerprovince','customerpostcode','dealernm','dealeraddr1','dealeramphur','dealerprovince','dealerpostcode','dealertel' ))
            tmp_ai_WOInput = list(ai_warrantyOnline.objects.using('ai').filter(warrantyno=wNumber,customerfirstname__gt='').annotate(cust_name=Concat( F('customerfirstname'),  Value(' '), F('customerlastname'))).values('cust_name','cartypeid','carbrandid','carmodelid','itemcd','installfilmcode','installdate','carchasis','carlicenseno','customersex','customermb','email','customeraddress','customertambol','customeramphur','customerprovince','customerpostcode','dealernm','dealeraddr1','dealeramphur','dealerprovince','dealerpostcode','dealertel','birthday' ))
    ########################################################################   
            if len(tmp_ai_CSInput) > 0:
                datas['register']="registed"
                datas['w_data']['product_code'] = ai_checkNull_productInstall(tmp_ai_CSInput[0]['itemcd'],tmp_ai_CSInput[0]['installfilmcode'])
                datas['w_data']['cust_install_date'] = tmp_ai_CSInput[0]['installdate']
                datas['w_data']['cust_cartype'] = get_ai_carType_byID(tmp_ai_CSInput[0]['cartypeid'])
                datas['w_data']['cust_carbrand'] = get_ai_carBrand_byID(tmp_ai_CSInput[0]['carbrandid'])
                datas['w_data']['cust_carmodel'] = get_ai_carModel_byID(tmp_ai_CSInput[0]['carmodelid'])
                datas['w_data']['cust_liceseplateblack'] = tmp_ai_CSInput[0]['carlicenseno']
                datas['w_data']['cust_vin'] = tmp_ai_CSInput[0]['carchasis']
                datas['w_data']['cust_name'] = tmp_ai_CSInput[0]['cust_name']
                datas['w_data']['cust_birthday'] = "" ### DB have not this field
                datas['w_data']['cust_gender'] = ai_tranform_gender(tmp_ai_CSInput[0]['customersex'])
                datas['w_data']['cust_phone'] = tmp_ai_CSInput[0]['customermb']
                datas['w_data']['cust_mail'] = tmp_ai_CSInput[0]['email']
                datas['w_data']['cust_warrant_exdate'] = ""
                datas['w_data']['cust_address'] = tmp_ai_CSInput[0]['customeraddress']
                datas['w_data']['cust_district'] = tmp_ai_CSInput[0]['customeramphur']
                datas['w_data']['cust_subdistrict'] = tmp_ai_CSInput[0]['customertambol']
                datas['w_data']['cust_province'] = tmp_ai_CSInput[0]['customerprovince']
                datas['w_data']['cust_postalcode'] = tmp_ai_CSInput[0]['customerpostcode']
                datas['w_data']['cust_address_full'] = get_fullAddress(tmp_ai_CSInput[0]['customeraddress'],
                                                                    tmp_ai_CSInput[0]['customertambol'],
                                                                    tmp_ai_CSInput[0]['customeramphur'],
                                                                    tmp_ai_CSInput[0]['customerprovince'],
                                                                    tmp_ai_CSInput[0]['customerpostcode']) 
                datas['w_data']['showroominstall_name'] = tmp_ai_CSInput[0]['dealernm']
                datas['w_data']['showroominstall_address'] =  tmp_ai_CSInput[0]['dealeraddr1'] + " "+  tmp_ai_CSInput[0]['dealeramphur'] + " " + tmp_ai_CSInput[0]['dealerprovince'] + " " + tmp_ai_CSInput[0]['dealerpostcode'] #+ ai_check_phone( tmp_ai_CSInput[0]['dealertel'])
                datas['w_data']['showroominstall_phone'] = tmp_ai_CSInput[0]['dealertel']
                datas['w_data']['another_position'] = "รอบคัน รหัสฟิล์ม "+ ai_check_nullProduct_returnHyphen(tmp_ai_CSInput[0]['itemcd']) + " บานหน้า รหัสฟิล์ม "+ai_check_nullProduct_returnHyphen(tmp_ai_CSInput[0]['installfilmcode'])
                print('----CS')
            # #### Check in table tbt_invt_warrantyow [Online Input]    ,'dealeraddr1','dealeramphur','dealerprovince','dealerpostcode','dealertel' 
            elif len(tmp_ai_WOInput) > 0:
                datas['register']="registed"
                datas['w_data']['product_code'] = ai_checkNull_productInstall(tmp_ai_WOInput[0]['itemcd'],tmp_ai_WOInput[0]['installfilmcode'])
                datas['w_data']['cust_install_date'] = tmp_ai_WOInput[0]['installdate']
                datas['w_data']['cust_cartype'] = get_ai_carType_byID(tmp_ai_WOInput[0]['cartypeid'])
                datas['w_data']['cust_carbrand'] = get_ai_carBrand_byID(tmp_ai_WOInput[0]['carbrandid'])
                datas['w_data']['cust_carmodel'] = get_ai_carModel_byID(tmp_ai_WOInput[0]['carmodelid'])
                datas['w_data']['cust_liceseplateblack'] = tmp_ai_WOInput[0]['carlicenseno']
                datas['w_data']['cust_vin'] = tmp_ai_WOInput[0]['carchasis']
                datas['w_data']['cust_name'] = tmp_ai_WOInput[0]['cust_name']
                datas['w_data']['cust_birthday'] =tmp_ai_WOInput[0]['birthday']
                datas['w_data']['cust_gender'] = ai_tranform_gender(tmp_ai_WOInput[0]['customersex'])
                datas['w_data']['cust_phone'] = tmp_ai_WOInput[0]['customermb']
                datas['w_data']['cust_mail'] = tmp_ai_WOInput[0]['email']
                datas['w_data']['cust_warrant_exdate'] = ""
                datas['w_data']['cust_address'] = tmp_ai_WOInput[0]['customeraddress']
                datas['w_data']['cust_district'] = tmp_ai_WOInput[0]['customeramphur']
                datas['w_data']['cust_subdistrict'] = tmp_ai_WOInput[0]['customertambol']
                datas['w_data']['cust_province'] = tmp_ai_WOInput[0]['customerprovince']
                datas['w_data']['cust_postalcode'] = tmp_ai_WOInput[0]['customerpostcode']
                datas['w_data']['cust_address_full'] = get_fullAddress(tmp_ai_WOInput[0]['customeraddress'],
                                                                    tmp_ai_WOInput[0]['customertambol'],
                                                                    tmp_ai_WOInput[0]['customeramphur'],
                                                                    tmp_ai_WOInput[0]['customerprovince'],
                                                                    tmp_ai_WOInput[0]['customerpostcode']) 
                datas['w_data']['showroominstall_name'] = tmp_ai_WOInput[0]['dealernm']
                datas['w_data']['showroominstall_address'] =  tmp_ai_WOInput[0]['dealeraddr1'] + " "+  tmp_ai_WOInput[0]['dealeramphur'] + " " + tmp_ai_WOInput[0]['dealerprovince'] + " " + tmp_ai_WOInput[0]['dealerpostcode'] #+ ai_check_phone( tmp_ai_CSInput[0]['dealertel'])
                datas['w_data']['showroominstall_phone'] = tmp_ai_WOInput[0]['dealertel']
                datas['w_data']['another_position'] = "รอบคัน รหัสฟิล์ม "+ ai_check_nullProduct_returnHyphen(tmp_ai_WOInput[0]['itemcd']) + " บานหน้า รหัสฟิล์ม "+ai_check_nullProduct_returnHyphen(tmp_ai_WOInput[0]['installfilmcode'])
                print('----WO')
        else :    
            datas['state']="notFound"
            datas['register']="unRegisted"
            datas['sys_db']= "ai"
            
    else:
        datas['state'] = "notFound"
        datas['register'] = ''

    return datas
        # else:
        #     return JsonResponse(True ,safe=False)

def wFinder_cusName(request):
    if len(request.POST.get('cust_lastname'))>0:
        custName = request.POST.get('cust_firstname')+" "+request.POST.get('cust_lastname')
    else:
        custName = request.POST.get('cust_firstname')
    carData = request.POST.get('car_data')
    pageBrand = request.POST.get('brand_wrt')
    
    datas = {
        'state':'found',#'found/notFound',
        'brand':pageBrand,#'lamina/xtra-cole/glasia',
        'w_data':[]
    }
    #         'sys_db':'',#'erp/ai',
    #         'register':'',#'registed/unRegisted',
    #         'id_wrt':'',
    #         'number_wrt':'',
    #         'product_id':'',
    #         'product_code':'',
    #         'contact_id':'',
    #         'contact_name':'',
    #         'contact_branch':'',
    #         'contact_namebranch':'',
            
    #         'cust_name':'',
    #         'cust_gender':'',
    #         'cust_birthday':'',
    #         'cust_address_full':'',
    #         'cust_address':'',
    #         'cust_subdistrict_id':'',
    #         'cust_subdistrict':'',
    #         'cust_district_id':'',
    #         'cust_district':'',
    #         'cust_province_id':'',
    #         'cust_province':'',
    #         'cust_postalcode':'',
    #         'cust_phone':'',
    #         'cust_mail':'',
            
    #         'cust_cartype':'',
    #         'cust_carbrand':'',
    #         'cust_carmodel':'',
    #         'cust_liceseplateblack':'',
    #         'cust_vin':'',
    #         'cust_install_date':'',
    #         'cust_warrant_exdate':'',
            
    #         'showroominstall_id':'',
    #         'showroominstall_name':'',
    #         'showroominstall_address':'',
    #         'showroominstall_phone':'',
    #         'another_position':''
    # }}
        
    aiProduct_Brand = get_ai_match_brand()
    
    if pageBrand == 'lamina':
        productBrand = laminaPage_brand
    elif pageBrand == 'xtra-cole':
        productBrand = xtraColePage_brand
    elif pageBrand == 'glasia':
        productBrand = glasiaPage_brand
    else:
        datas['state'] = "notFound"
    if  request.POST.get('cardetail_condition') == 'vin':
        #### check erp
        erp_datas = list(erp_warranty.objects.filter(cust_name__icontains =custName,cust_vin__icontains =carData,product__brand__in=productBrand).values('id','number','cust_name','cust_car_brand_0__name','cust_car_model_0__name','cust_date','warranty_exp_date'))
        aics_datas  = list(ai_warranty.objects.using('ai').filter(customerfirstname__icontains=request.POST.get('cust_firstname'),customerlastname__icontains=request.POST.get('cust_lastname'),carchasis__icontains =carData).annotate(cust_name=Concat( F('customerfirstname'),  Value(' '), F('customerlastname'))).values('warrantyno','cust_name','carbrandid','carmodelid','installdate' ))
        aiwo_datas  = list(ai_warrantyOnline.objects.using('ai').filter(customerfirstname__icontains=request.POST.get('cust_firstname'),customerlastname__icontains=request.POST.get('cust_lastname'),carchasis__icontains =carData).annotate(cust_name=Concat( F('customerfirstname'),  Value(' '), F('customerlastname'))).values('warrantyno','cust_name','carbrandid','carmodelid','installdate' ))
        if len(erp_datas) > 0:
            for w_data in erp_datas:
                datas['w_data'].append(
                    {'number_wrt':w_data['number'],
                     'brand_wrt':pageBrand,
                     'sys_db':'erp',
                     'cust_name':w_data['cust_name'],
                     'cust_install_date':w_data['cust_date'],
                     'cust_carbrand':w_data['cust_car_brand_0__name'],
                     'cust_carmodel':w_data['cust_car_model_0__name']})
        
        elif len(aics_datas) > 0:
            for w_data in aics_datas:
                tmp_aiWarranty = list(ai_warrantyDealer.objects.using('ai').filter(warrantydealerno = w_data['warrantyno']).values('warrantydealerno','invrqsno'))
                productCodeInAI = list(ai_gi.objects.using('ai').filter(invrqsno=tmp_aiWarranty[0]['invrqsno']).values('invrqsno','itemcd'))
                if aiProduct_Brand[productCodeInAI[0]['itemcd']] in productBrand:
                    datas['w_data'].append(
                        {'number_wrt':w_data['warrantyno'],
                        'brand_wrt':pageBrand,
                        'sys_db':'ai',
                        'cust_name':w_data['cust_name'],
                        'cust_install_date':w_data['installdate'],
                        'cust_carbrand':get_ai_carBrand_byID(w_data['carbrandid']),
                        'cust_carmodel':get_ai_carModel_byID(w_data['carmodelid'])})
           
        elif len(aiwo_datas) > 0:
            for w_data in aiwo_datas:
                tmp_aiWarranty = list(ai_warrantyDealer.objects.using('ai').filter(warrantydealerno = w_data['warrantyno']).values('warrantydealerno','invrqsno'))
                productCodeInAI = list(ai_gi.objects.using('ai').filter(invrqsno=tmp_aiWarranty[0]['invrqsno']).values('invrqsno','itemcd'))
                if aiProduct_Brand[productCodeInAI[0]['itemcd']] in productBrand:
                    datas['w_data'].append(
                        {'number_wrt':w_data['warrantyno'],
                        'brand_wrt':pageBrand,
                        'sys_db':'ai',
                        'cust_name':w_data['cust_name'],
                        'cust_install_date':w_data['installdate'],
                        'cust_carbrand':get_ai_carBrand_byID(w_data['carbrandid']),
                        'cust_carmodel':get_ai_carModel_byID(w_data['carmodelid'])})
        else: 
            datas['state'] = "notFound"
            
 
    elif request.POST.get('cardetail_condition') == 'license':
        erp_datas = list(erp_warranty.objects.filter(cust_name__icontains =custName,cust_license_plate_bk__icontains =carData,product__brand__in=productBrand).values('id','number','cust_name','cust_car_brand_0__name','cust_car_model_0__name','cust_date','warranty_exp_date'))
        aics_datas  = list(ai_warranty.objects.using('ai').filter(customerfirstname__icontains=request.POST.get('cust_firstname'),customerlastname__icontains =request.POST.get('cust_lastname'),carlicenseno__icontains =carData).annotate(cust_name=Concat( F('customerfirstname'),  Value(' '), F('customerlastname'))).values('warrantyno','cust_name','carbrandid','carmodelid','installdate' ))
        aiwo_datas  = list(ai_warrantyOnline.objects.using('ai').filter(customerfirstname__icontains=request.POST.get('cust_firstname'),customerlastname__icontains =request.POST.get('cust_lastname'),carlicenseno__icontains =carData).annotate(cust_name=Concat( F('customerfirstname'),  Value(' '), F('customerlastname'))).values('warrantyno','cust_name','carbrandid','carmodelid','installdate' ))
        if len(erp_datas) > 0:
            for w_data in erp_datas:
                datas['w_data'].append(
                    {'number_wrt':w_data['number'],
                     'brand_wrt':pageBrand,
                     'sys_db':'erp',
                     'cust_name':w_data['cust_name'],
                     'cust_install_date':w_data['cust_date'],
                     'cust_carbrand':w_data['cust_car_brand_0__name'],
                     'cust_carmodel':w_data['cust_car_model_0__name']})
        
        elif len(aics_datas) > 0:
            for w_data in aics_datas:
                tmp_aiWarranty = list(ai_warrantyDealer.objects.using('ai').filter(warrantydealerno = w_data['warrantyno']).values('warrantydealerno','invrqsno'))
                productCodeInAI = list(ai_gi.objects.using('ai').filter(invrqsno=tmp_aiWarranty[0]['invrqsno']).values('invrqsno','itemcd'))
                if aiProduct_Brand[productCodeInAI[0]['itemcd']] in productBrand:
                    datas['w_data'].append(
                        {'number_wrt':w_data['warrantyno'],
                        'brand_wrt':pageBrand,
                        'sys_db':'ai',
                        'cust_name':w_data['cust_name'],
                        'cust_install_date':w_data['installdate'],
                        'cust_carbrand':get_ai_carBrand_byID(w_data['carbrandid']),
                        'cust_carmodel':get_ai_carModel_byID(w_data['carmodelid'])})
           
        elif len(aiwo_datas) > 0:
            for w_data in aiwo_datas:
                tmp_aiWarranty = list(ai_warrantyDealer.objects.using('ai').filter(warrantydealerno = w_data['warrantyno']).values('warrantydealerno','invrqsno'))
                productCodeInAI = list(ai_gi.objects.using('ai').filter(invrqsno=tmp_aiWarranty[0]['invrqsno']).values('invrqsno','itemcd'))
                if aiProduct_Brand[productCodeInAI[0]['itemcd']] in productBrand:
                    datas['w_data'].append(
                        {'number_wrt':w_data['warrantyno'],
                        'brand_wrt':pageBrand,
                        'sys_db':'ai',
                        'cust_name':w_data['cust_name'],
                        'cust_install_date':w_data['installdate'],
                        'cust_carbrand':get_ai_carBrand_byID(w_data['carbrandid']),
                        'cust_carmodel':get_ai_carModel_byID(w_data['carmodelid'])})
        else: 
            datas['state'] = "notFound"
        if datas['state'] == "notFound" and len(datas['w_data']) < 1:
            datas['state'] = "notFound"
    else:
        datas['state'] = "notFound"
        
    return datas
        
        
    

class warrantyFinder :
    def __init__(self,pageBrand):
        self.pageBrand = pageBrand
        self.datas = {
                'state':'',#'found/notFound',
                'sys_db':'',#'erp/ai',
                'register':'',#'registed/unRegisted',
                'brand':pageBrand,#'lamina/xtra-cole/glasia',
                'number_wrt':'',
                'w_data':{
                    'id_wrt':'',
                    'product_id':'',
                    'product_code':'',
                    'contact_id':'',
                    'contact_name':'',
                    'contact_branch':'',
                    'contact_namebranch':'',
                    
                    'cust_name':'',
                    'cust_gender':'',
                    'cust_birthday':'',
                    'cust_address_full':'',
                    'cust_address':'',
                    'cust_subdistrict_id':'',
                    'cust_subdistrict':'',
                    'cust_district_id':'',
                    'cust_district':'',
                    'cust_province_id':'',
                    'cust_province':'',
                    'cust_postalcode':'',
                    'cust_phone':'',
                    'cust_mail':'',
                    
                    'cust_cartype':'',
                    'cust_carbrand':'',
                    'cust_carmodel':'',
                    'cust_liceseplateblack':'',
                    'cust_vin':'',
                    'cust_install_date':'',
                    'cust_warrant_exdate':'',
                    
                    'showroominstall_id':'',
                    'showroominstall_name':'',
                    'showroominstall_address':'',
                    'showroominstall_phone':'',
                    'another_position':''
        }}
        pass
#     def  wFinder_wNumber (self):
#         pass
    
#     def wFinder_cusName (self,cus_name):
#         if self.pageBrand == 'lamina':
#             self.productBrand = laminaPage_brand
#         elif self.pageBrand == 'xtra-cole':
#             self.productBrand = xtraColePage_brand
#         elif self.pageBrand == 'glasia':
#             self.productBrand = glasiaPage_brand
#         else:
#             self.datas['state'] = "notFound"
#         tmp_erpWarranty = list(erp_warranty.objects.filter(name__in = cus_name, product__brand__in=self.productBrand).exclude(state='voided').values('id',
#                 'state',
#                 'product',
#                 'product__code',
#                 'product__name',
#                 'contact',
#                 'contact__name',
#                 'contact__branch',
#                 'cust_name',
#                 'area_film_0',
#                 'cust_date',
#                 'warranty_exp_date',
#                 # 'cust_birthday',
#                 'cust_sex_0',
#                 'cust_sex_0__name',
#                 'cust_phone', 
#                 'cust_address',
#                 'cust_subdistrict',
#                 'cust_district',
#                 'cust_province',
#                 'cust_country',                                                                                                                                            
#                 'cust_subdistrict__name',
#                 'cust_district__name',
#                 'cust_province__name',
#                 'cust_postal_code',
#                 'cust_country__name',
#                 'cust_license_plate_bk',
#                 'cust_vin',
#                 'cust_car_type_0',
#                 'cust_car_brand_0',
#                 'cust_car_model_0',
#                 'cust_car_type_0__name',
#                 'cust_car_brand_0__name',
#                 'cust_car_model_0__name',
#                 'cust_showroom',
#                 'cust_showroom_0',
#                 'cust_showroom_0__name',
#                 'cust_showroom_0__branch',
#                 'remark',
#                 'cust_license_plate',
#                 'front_license_plate',
#                 'remark' )) 
#     ### Check in AI:
#         tmp_aiWarranty = list(ai_warrantyDealer.objects.using('ai').filter(warrantydealerno = wNumber).values('warrantydealerno','invrqsno','warrantydealerstt'))

#         if len(tmp_erpWarranty) > 0:
#             self.datas['state'] = "found"
#             self.datas['sys_db'] = "erp"
#             tmp_erp_showroomAddress = list(erp_address.objects.filter(contact=tmp_erpWarranty[0]['contact'],type='billing').values('address','province_0__name','phone'))
            
#             # tmp_erp = erp_warranty.objects.using('erp').filter(number=wNumber).values('id','name')
#             # datas = {'warranty_id': tmp_erpWarranty[0]['number']}
#             if tmp_erpWarranty[0]['cust_name'] is not None and tmp_erpWarranty[0]['cust_car_brand_0'] is not None and tmp_erpWarranty[0]['cust_car_model_0'] is not None :
#                 self.datas['register'] = "registed"
#                 self.datas['w_data']['product_id'] = tmp_erpWarranty[0]['product']
#                 self.datas['w_data']['product_code'] = tmp_erpWarranty[0]['product__code']
#                 self.datas['w_data']['contact_id'] = tmp_erpWarranty[0]['contact']
#                 self.datas['w_data']['contact_name'] = tmp_erpWarranty[0]['contact__name']
#                 self.datas['w_data']['contact_branch'] = tmp_erpWarranty[0]['contact__branch']
#                 self.datas['w_data']['contact_namebranch'] = tmp_erpWarranty[0]['contact__name']+" "+tmp_erpWarranty[0]['contact__branch']
            
#                 self.datas['w_data']['cust_name'] = tmp_erpWarranty[0]['cust_name']
#                 self.datas['w_data']['cust_gender'] = tmp_erpWarranty[0]['cust_sex_0__name']
#                 # datas['w_data']['cust_birthday'] = tmp_erpWarranty[0]['cust_birthday']
#                 self.datas['w_data']['cust_address_full'] = get_fullAddress(tmp_erpWarranty[0]['cust_address'],tmp_erpWarranty[0]['cust_subdistrict__name'],tmp_erpWarranty[0]['cust_district__name'],tmp_erpWarranty[0]['cust_province__name'],tmp_erpWarranty[0]['cust_postal_code']) 
#                 self.datas['w_data']['cust_address'] = tmp_erpWarranty[0]['cust_address']
#                 self.datas['w_data']['cust_subdistrict_id'] = tmp_erpWarranty[0]['cust_subdistrict']
#                 self.datas['w_data']['cust_subdistrict'] =tmp_erpWarranty[0]['cust_subdistrict__name']
#                 self.datas['w_data']['cust_district_id'] = tmp_erpWarranty[0]['cust_district']
#                 self.datas['w_data']['cust_district'] = tmp_erpWarranty[0]['cust_district__name']
#                 self.datas['w_data']['cust_province_id'] = tmp_erpWarranty[0]['cust_province']
#                 self.datas['w_data']['cust_province'] = tmp_erpWarranty[0]['cust_province__name']
#                 self.datas['w_data']['cust_postalcode'] = tmp_erpWarranty[0]['cust_postal_code']
#                 self.datas['w_data']['cust_phone'] = tmp_erpWarranty[0]['cust_phone']
                
#                 self.datas['w_data']['cust_cartype_id'] = tmp_erpWarranty[0]['cust_car_type_0']
#                 self.datas['w_data']['cust_cartype'] = tmp_erpWarranty[0]['cust_car_type_0__name']
#                 self.datas['w_data']['cust_carbrand_id'] = tmp_erpWarranty[0]['cust_car_brand_0']
#                 self.datas['w_data']['cust_carbrand'] = tmp_erpWarranty[0]['cust_car_brand_0__name']
#                 self.datas['w_data']['cust_carmodel_id'] = tmp_erpWarranty[0]['cust_car_model_0']
#                 self.datas['w_data']['cust_carmodel'] = tmp_erpWarranty[0]['cust_car_model_0__name']
#                 self.datas['w_data']['cust_liceseplateblack'] = tmp_erpWarranty[0]['cust_license_plate_bk']
#                 self.datas['w_data']['cust_vin'] = tmp_erpWarranty[0]['cust_vin']
#                 self.datas['w_data']['cust_install_date'] =tmp_erpWarranty[0]['cust_date']
#                 self.datas['w_data']['cust_warrant_exdate'] = tmp_erpWarranty[0]['warranty_exp_date']
        
#                 self.datas['w_data']['showroominstall_id'] = tmp_erpWarranty[0]['cust_showroom_0']
#                 # datas['w_data']['showroominstall_name'] = tmp_erpWarranty[0]['cust_showroom_0__name']
#                 # datas['w_data']['showroominstall_branch'] = tmp_erpWarranty[0]['cust_showroom_0__branch']
#                 self.datas['w_data']['showroominstall_name'] = tmp_erpWarranty[0]['cust_showroom_0__name']+" "+tmp_erpWarranty[0]['cust_showroom_0__branch']
#                 self.datas['w_data']['showroominstall_address'] =  tmp_erp_showroomAddress[0]['address']
#                 self.datas['w_data']['showroominstall_phone'] = tmp_erp_showroomAddress[0]['phone']
#                 self.datas['w_data']['another_position'] = tmp_erpWarranty[0]['remark'] 
#             elif tmp_erpWarranty[0]['cust_name'] is None and tmp_erpWarranty[0]['cust_car_brand_0'] is None and tmp_erpWarranty[0]['cust_car_model_0'] is None :
#                 self.datas['register'] = "unRegisted"
#                 self.datas['w_data']['product_id'] = tmp_erpWarranty[0]['product']
#                 self.datas['w_data']['product_code'] = tmp_erpWarranty[0]['product__code']
#                 self.datas['w_data']['contact_id'] = tmp_erpWarranty[0]['contact']
#                 self.datas['w_data']['contact_name'] = tmp_erpWarranty[0]['contact__name']
#                 self.datas['w_data']['contact_branch'] = tmp_erpWarranty[0]['contact__branch']
#                 self.datas['w_data']['contact_namebranch'] = tmp_erpWarranty[0]['contact__name']+" "+tmp_erpWarranty[0]['contact__branch']
#             else:
#                 self.datas['state'] = "unCompleted"
#                 self.datas['register'] = "registed"
#                 self.datas['w_data']['product_id'] = tmp_erpWarranty[0]['product']
#                 self.datas['w_data']['product_code'] = tmp_erpWarranty[0]['product__code']
#                 self.datas['w_data']['contact_id'] = tmp_erpWarranty[0]['contact']
#                 self.datas['w_data']['contact_name'] = tmp_erpWarranty[0]['contact__name']
#                 self.datas['w_data']['contact_branch'] = tmp_erpWarranty[0]['contact__branch']
#                 self.datas['w_data']['contact_namebranch'] = tmp_erpWarranty[0]['contact__name']+" "+tmp_erpWarranty[0]['contact__branch']
            
#                 self.datas['w_data']['cust_name'] = tmp_erpWarranty[0]['cust_name']
#                 self.datas['w_data']['cust_gender'] = tmp_erpWarranty[0]['cust_sex_0__name']
#                 # datas['w_data']['cust_birthday'] = tmp_erpWarranty[0]['cust_birthday']
#                 self.datas['w_data']['cust_address_full'] = get_fullAddress(tmp_erpWarranty[0]['cust_address'],tmp_erpWarranty[0]['cust_subdistrict__name'],tmp_erpWarranty[0]['cust_district__name'],tmp_erpWarranty[0]['cust_province__name'],tmp_erpWarranty[0]['cust_postal_code']) 
#                 self.datas['w_data']['cust_address'] = tmp_erpWarranty[0]['cust_address']
#                 self.datas['w_data']['cust_subdistrict_id'] = tmp_erpWarranty[0]['cust_subdistrict']
#                 self.datas['w_data']['cust_subdistrict'] =tmp_erpWarranty[0]['cust_subdistrict__name']
#                 self.datas['w_data']['cust_district_id'] = tmp_erpWarranty[0]['cust_district']
#                 self.datas['w_data']['cust_district'] = tmp_erpWarranty[0]['cust_district__name']
#                 self.datas['w_data']['cust_province_id'] = tmp_erpWarranty[0]['cust_province']
#                 self.datas['w_data']['cust_province'] = tmp_erpWarranty[0]['cust_province__name']
#                 self.datas['w_data']['cust_postalcode'] = tmp_erpWarranty[0]['cust_postal_code']
#                 self.datas['w_data']['cust_phone'] = tmp_erpWarranty[0]['cust_phone']
                
#                 self.datas['w_data']['cust_cartype_id'] = tmp_erpWarranty[0]['cust_car_type_0']
#                 self.datas['w_data']['cust_cartype'] = tmp_erpWarranty[0]['cust_car_type_0__name']
#                 self.datas['w_data']['cust_carbrand_id'] = tmp_erpWarranty[0]['cust_car_brand_0']
#                 self.datas['w_data']['cust_carbrand'] = tmp_erpWarranty[0]['cust_car_brand_0__name']
#                 self.datas['w_data']['cust_carmodel_id'] = tmp_erpWarranty[0]['cust_car_model_0']
#                 self.datas['w_data']['cust_carmodel'] = tmp_erpWarranty[0]['cust_car_model_0__name']
#                 self.datas['w_data']['cust_liceseplateblack'] = tmp_erpWarranty[0]['cust_license_plate_bk']
#                 self.datas['w_data']['cust_vin'] = tmp_erpWarranty[0]['cust_vin']
#                 self.datas['w_data']['cust_install_date'] =tmp_erpWarranty[0]['cust_date']
#                 self.datas['w_data']['cust_warrant_exdate'] = tmp_erpWarranty[0]['warranty_exp_date']
        
#                 self.datas['w_data']['showroominstall_id'] = tmp_erpWarranty[0]['cust_showroom_0']
#                 # datas['w_data']['showroominstall_name'] = tmp_erpWarranty[0]['cust_showroom_0__name']
#                 # datas['w_data']['showroominstall_branch'] = tmp_erpWarranty[0]['cust_showroom_0__branch']
#                 self.datas['w_data']['showroominstall_name'] = tmp_erpWarranty[0]['cust_showroom_0__name']+" "+tmp_erpWarranty[0]['cust_showroom_0__branch']
#                 self.datas['w_data']['showroominstall_address'] =  tmp_erp_showroomAddress[0]['address']
#                 self.datas['w_data']['showroominstall_phone'] = tmp_erp_showroomAddress[0]['phone']
#                 self.datas['w_data']['another_position'] = tmp_erpWarranty[0]['remark']
#         elif len(tmp_aiWarranty) > 0  :
#             aiProduct_Brand = get_ai_match_brand()
#             productCodeInAI = list(ai_gi.objects.using('ai').filter(invrqsno=tmp_aiWarranty[0]['invrqsno']).values('invrqsno','itemcd'))
            
#             if aiProduct_Brand[productCodeInAI[0]['itemcd']] in productBrand:
#                 self.datas['state']="found"
#                 self.datas['sys_db']="ai"
                
#             ###### check wNumber Registed ?
#             ########################################################################
#             ######### Get Data To PrintingData  -----> Add column More Here
#                     tmp_ai_CSInput = list(ai_warranty.objects.using('ai').filter(warrantyno=wNumber,customerfirstname__gt='').annotate(cust_name=Concat( F('customerfirstname'),  Value(' '), F('customerlastname'))).values('cust_name','cartypeid','carbrandid','carmodelid','itemcd','installfilmcode','installdate','carchasis','carlicenseno','customersex','customermb','email','customeraddress','customertambol','customeramphur','customerprovince','customerpostcode','dealernm','dealeraddr1','dealeramphur','dealerprovince','dealerpostcode','dealertel' ))
#                     tmp_ai_WOInput = list(ai_warrantyOnline.objects.using('ai').filter(warrantyno=wNumber,customerfirstname__gt='').annotate(cust_name=Concat( F('customerfirstname'),  Value(' '), F('customerlastname'))).values('cust_name','cartypeid','carbrandid','carmodelid','itemcd','installfilmcode','installdate','carchasis','carlicenseno','customersex','customermb','email','customeraddress','customertambol','customeramphur','customerprovince','customerpostcode','dealernm','dealeraddr1','dealeramphur','dealerprovince','dealerpostcode','dealertel','birthday' ))
#             ########################################################################   
#                     if len(tmp_ai_CSInput) > 0:
#                         datas['register']="registed"
#                         datas['w_data']['product_code'] = ai_checkNull_productInstall(tmp_ai_CSInput[0]['itemcd'],tmp_ai_CSInput[0]['installfilmcode'])
#                         datas['w_data']['cust_install_date'] = tmp_ai_CSInput[0]['installdate']
#                         datas['w_data']['cust_cartype'] = get_ai_carType_byID(tmp_ai_CSInput[0]['cartypeid'])
#                         datas['w_data']['cust_carbrand'] = get_ai_carBrand_byID(tmp_ai_CSInput[0]['carbrandid'])
#                         datas['w_data']['cust_carmodel'] = get_ai_carModel_byID(tmp_ai_CSInput[0]['carmodelid'])
#                         datas['w_data']['cust_liceseplateblack'] = tmp_ai_CSInput[0]['carchasis']
#                         datas['w_data']['cust_vin'] = tmp_ai_CSInput[0]['carlicenseno']
#                         datas['w_data']['cust_name'] = tmp_ai_CSInput[0]['cust_name']
#                         datas['w_data']['cust_birthday'] = "" ### DB have not this field
#                         datas['w_data']['cust_gender'] = ai_tranform_gender(tmp_ai_CSInput[0]['customersex'])
#                         datas['w_data']['cust_phone'] = tmp_ai_CSInput[0]['customermb']
#                         datas['w_data']['cust_mail'] = tmp_ai_CSInput[0]['email']
#                         datas['w_data']['cust_warrant_exdate'] = ""
#                         datas['w_data']['cust_address'] = tmp_ai_CSInput[0]['customeraddress']
#                         datas['w_data']['cust_district'] = tmp_ai_CSInput[0]['customeramphur']
#                         datas['w_data']['cust_subdistrict'] = tmp_ai_CSInput[0]['customertambol']
#                         datas['w_data']['cust_province'] = tmp_ai_CSInput[0]['customerprovince']
#                         datas['w_data']['cust_postalcode'] = tmp_ai_CSInput[0]['customerpostcode']
#                         datas['w_data']['cust_address_full'] = get_fullAddress(tmp_ai_CSInput[0]['customeraddress'],
#                                                                             tmp_ai_CSInput[0]['customertambol'],
#                                                                             tmp_ai_CSInput[0]['customeramphur'],
#                                                                             tmp_ai_CSInput[0]['customerprovince'],
#                                                                             tmp_ai_CSInput[0]['customerpostcode']) 
#                         datas['w_data']['showroominstall_name'] = tmp_ai_CSInput[0]['dealernm']
#                         datas['w_data']['showroominstall_address'] =  tmp_ai_CSInput[0]['dealeraddr1'] + " "+  tmp_ai_CSInput[0]['dealeramphur'] + " " + tmp_ai_CSInput[0]['dealerprovince'] + " " + tmp_ai_CSInput[0]['dealerpostcode'] #+ ai_check_phone( tmp_ai_CSInput[0]['dealertel'])
#                         datas['w_data']['showroominstall_phone'] = tmp_ai_CSInput[0]['dealertel']
#                         datas['w_data']['another_position'] = "รอบคัน รหัสฟิล์ม "+ ai_check_nullProduct_returnHyphen(tmp_ai_CSInput[0]['itemcd']) + " บานหน้า รหัสฟิล์ม "+ai_check_nullProduct_returnHyphen(tmp_ai_CSInput[0]['installfilmcode'])
#                         print('----CS')
#                     # #### Check in table tbt_invt_warrantyow [Online Input]    ,'dealeraddr1','dealeramphur','dealerprovince','dealerpostcode','dealertel' 
#                     elif len(tmp_ai_WOInput) > 0:
#                         datas['register']="registed"
#                         datas['w_data']['product_code'] = ai_checkNull_productInstall(tmp_ai_WOInput[0]['itemcd'],tmp_ai_WOInput[0]['installfilmcode'])
#                         datas['w_data']['cust_install_date'] = tmp_ai_WOInput[0]['installdate']
#                         datas['w_data']['cust_cartype'] = get_ai_carType_byID(tmp_ai_WOInput[0]['cartypeid'])
#                         datas['w_data']['cust_carbrand'] = get_ai_carBrand_byID(tmp_ai_WOInput[0]['carbrandid'])
#                         datas['w_data']['cust_carmodel'] = get_ai_carBrand_byID(tmp_ai_WOInput[0]['carbrandid'])
#                         datas['w_data']['cust_liceseplateblack'] = tmp_ai_WOInput[0]['carchasis']
#                         datas['w_data']['cust_vin'] = tmp_ai_WOInput[0]['carlicenseno']
#                         datas['w_data']['cust_name'] = tmp_ai_WOInput[0]['cust_name']
#                         datas['w_data']['cust_birthday'] =tmp_ai_WOInput[0]['birthday']
#                         datas['w_data']['cust_gender'] = ai_tranform_gender(tmp_ai_WOInput[0]['customersex'])
#                         datas['w_data']['cust_phone'] = tmp_ai_WOInput[0]['customermb']
#                         datas['w_data']['cust_mail'] = tmp_ai_WOInput[0]['email']
#                         datas['w_data']['cust_warrant_exdate'] = ""
#                         datas['w_data']['cust_address'] = tmp_ai_WOInput[0]['customeraddress']
#                         datas['w_data']['cust_district'] = tmp_ai_WOInput[0]['customeramphur']
#                         datas['w_data']['cust_subdistrict'] = tmp_ai_WOInput[0]['customertambol']
#                         datas['w_data']['cust_province'] = tmp_ai_WOInput[0]['customerprovince']
#                         datas['w_data']['cust_postalcode'] = tmp_ai_WOInput[0]['customerpostcode']
#                         datas['w_data']['cust_address_full'] = get_fullAddress(tmp_ai_WOInput[0]['customeraddress'],
#                                                                             tmp_ai_WOInput[0]['customertambol'],
#                                                                             tmp_ai_WOInput[0]['customeramphur'],
#                                                                             tmp_ai_WOInput[0]['customerprovince'],
#                                                                             tmp_ai_WOInput[0]['customerpostcode']) 
#                         datas['w_data']['showroominstall_name'] = tmp_ai_WOInput[0]['dealernm']
#                         datas['w_data']['showroominstall_address'] =  tmp_ai_WOInput[0]['dealeraddr1'] + " "+  tmp_ai_WOInput[0]['dealeramphur'] + " " + tmp_ai_WOInput[0]['dealerprovince'] + " " + tmp_ai_WOInput[0]['dealerpostcode'] #+ ai_check_phone( tmp_ai_CSInput[0]['dealertel'])
#                         datas['w_data']['showroominstall_phone'] = tmp_ai_WOInput[0]['dealertel']
#                         datas['w_data']['another_position'] = "รอบคัน รหัสฟิล์ม "+ ai_check_nullProduct_returnHyphen(tmp_ai_WOInput[0]['itemcd']) + " บานหน้า รหัสฟิล์ม "+ai_check_nullProduct_returnHyphen(tmp_ai_WOInput[0]['installfilmcode'])
#                         print('----WO')
#                 else :    
#                     datas['state']="notFound"
#                     datas['register']="unRegisted"
#                     datas['sys_db']= "ai"
                    
#             else:
#                 datas['state'] = "notFound"
#                 datas['register'] = ''

     
#             # else:
#             #     return JsonResponse(True ,safe=False)


#     elif find_method == 'cus_name':
#         cus_name_input = request.POST.get('cust_name') 
#         tmp_erpWarranty = list(erp_warranty.objects.filter(number = wNumber,product__brand__in=productBrand).exclude(state='voided').values('id',
#             'state',
#             'product',
#             'product__code',
#             'product__name',
#             'contact',
#             'contact__name',
#             'contact__branch',
#             'cust_name',
#             'area_film_0',
#             'cust_date',
#             'warranty_exp_date',
#             # 'cust_birthday',
#             'cust_sex_0',
#             'cust_sex_0__name',
#             'cust_phone', 
#             'cust_address',
#             'cust_subdistrict',
#             'cust_district',
#             'cust_province',
#             'cust_country',                                                                                                                                            
#             'cust_subdistrict__name',
#             'cust_district__name',
#             'cust_province__name',
#             'cust_postal_code',
#             'cust_country__name',
#             'cust_license_plate_bk',
#             'cust_vin',
#             'cust_car_type_0',
#             'cust_car_brand_0',
#             'cust_car_model_0',
#             'cust_car_type_0__name',
#             'cust_car_brand_0__name',
#             'cust_car_model_0__name',
#             'cust_showroom',
#             'cust_showroom_0',
#             'cust_showroom_0__name',
#             'cust_showroom_0__branch',
#             'remark',
#             'cust_license_plate',
#             'front_license_plate',
#             'remark'
#             ))
#     ### Check in AI:
#         tmp_aiWarranty = list(ai_warrantyDealer.objects.using('ai').filter(warrantydealerno = wNumber).values('warrantydealerno','invrqsno','warrantydealerstt'))

#         if len(tmp_erpWarranty) > 0:
#             datas['state'] = "found"
#             datas['sys_db'] = "erp"
#             tmp_erp_showroomAddress = list(erp_address.objects.filter(contact=tmp_erpWarranty[0]['contact'],type='billing').values('address','province_0__name','phone'))
            
#             # tmp_erp = erp_warranty.objects.using('erp').filter(number=wNumber).values('id','name')
#             # datas = {'warranty_id': tmp_erpWarranty[0]['number']}
#             if tmp_erpWarranty[0]['cust_name'] is not None and tmp_erpWarranty[0]['cust_car_brand_0'] is not None and tmp_erpWarranty[0]['cust_car_model_0'] is not None :
#                 datas['register'] = "registed"
#                 datas['w_data']['product_id'] = tmp_erpWarranty[0]['product']
#                 datas['w_data']['product_code'] = tmp_erpWarranty[0]['product__code']
#                 datas['w_data']['contact_id'] = tmp_erpWarranty[0]['contact']
#                 datas['w_data']['contact_name'] = tmp_erpWarranty[0]['contact__name']
#                 datas['w_data']['contact_branch'] = tmp_erpWarranty[0]['contact__branch']
#                 datas['w_data']['contact_namebranch'] = tmp_erpWarranty[0]['contact__name']+" "+tmp_erpWarranty[0]['contact__branch']
            
#                 datas['w_data']['cust_name'] = tmp_erpWarranty[0]['cust_name']
#                 datas['w_data']['cust_gender'] = tmp_erpWarranty[0]['cust_sex_0__name']
#                 # datas['w_data']['cust_birthday'] = tmp_erpWarranty[0]['cust_birthday']
#                 datas['w_data']['cust_address_full'] = get_fullAddress(tmp_erpWarranty[0]['cust_address'],tmp_erpWarranty[0]['cust_subdistrict__name'],tmp_erpWarranty[0]['cust_district__name'],tmp_erpWarranty[0]['cust_province__name'],tmp_erpWarranty[0]['cust_postal_code']) 
#                 datas['w_data']['cust_address'] = tmp_erpWarranty[0]['cust_address']
#                 datas['w_data']['cust_subdistrict_id'] = tmp_erpWarranty[0]['cust_subdistrict']
#                 datas['w_data']['cust_subdistrict'] =tmp_erpWarranty[0]['cust_subdistrict__name']
#                 datas['w_data']['cust_district_id'] = tmp_erpWarranty[0]['cust_district']
#                 datas['w_data']['cust_district'] = tmp_erpWarranty[0]['cust_district__name']
#                 datas['w_data']['cust_province_id'] = tmp_erpWarranty[0]['cust_province']
#                 datas['w_data']['cust_province'] = tmp_erpWarranty[0]['cust_province__name']
#                 datas['w_data']['cust_postalcode'] = tmp_erpWarranty[0]['cust_postal_code']
#                 datas['w_data']['cust_phone'] = tmp_erpWarranty[0]['cust_phone']
                
#                 datas['w_data']['cust_cartype_id'] = tmp_erpWarranty[0]['cust_car_type_0']
#                 datas['w_data']['cust_cartype'] = tmp_erpWarranty[0]['cust_car_type_0__name']
#                 datas['w_data']['cust_carbrand_id'] = tmp_erpWarranty[0]['cust_car_brand_0']
#                 datas['w_data']['cust_carbrand'] = tmp_erpWarranty[0]['cust_car_brand_0__name']
#                 datas['w_data']['cust_carmodel_id'] = tmp_erpWarranty[0]['cust_car_model_0']
#                 datas['w_data']['cust_carmodel'] = tmp_erpWarranty[0]['cust_car_model_0__name']
#                 datas['w_data']['cust_liceseplateblack'] = tmp_erpWarranty[0]['cust_license_plate_bk']
#                 datas['w_data']['cust_vin'] = tmp_erpWarranty[0]['cust_vin']
#                 datas['w_data']['cust_install_date'] =tmp_erpWarranty[0]['cust_date']
#                 datas['w_data']['cust_warrant_exdate'] = tmp_erpWarranty[0]['warranty_exp_date']
        
#                 datas['w_data']['showroominstall_id'] = tmp_erpWarranty[0]['cust_showroom_0']
#                 # datas['w_data']['showroominstall_name'] = tmp_erpWarranty[0]['cust_showroom_0__name']
#                 # datas['w_data']['showroominstall_branch'] = tmp_erpWarranty[0]['cust_showroom_0__branch']
#                 datas['w_data']['showroominstall_name'] = tmp_erpWarranty[0]['cust_showroom_0__name']+" "+tmp_erpWarranty[0]['cust_showroom_0__branch']
#                 datas['w_data']['showroominstall_address'] =  tmp_erp_showroomAddress[0]['address']
#                 datas['w_data']['showroominstall_phone'] = tmp_erp_showroomAddress[0]['phone']
#                 datas['w_data']['another_position'] = tmp_erpWarranty[0]['remark']
#                 print ('OK')
#             elif tmp_erpWarranty[0]['cust_name'] is None and tmp_erpWarranty[0]['cust_car_brand_0'] is None and tmp_erpWarranty[0]['cust_car_model_0'] is None :
#                 datas['register'] = "unRegisted"
#                 datas['w_data']['product_id'] = tmp_erpWarranty[0]['product']
#                 datas['w_data']['product_code'] = tmp_erpWarranty[0]['product__code']
#                 datas['w_data']['contact_id'] = tmp_erpWarranty[0]['contact']
#                 datas['w_data']['contact_name'] = tmp_erpWarranty[0]['contact__name']
#                 datas['w_data']['contact_branch'] = tmp_erpWarranty[0]['contact__branch']
#                 datas['w_data']['contact_namebranch'] = tmp_erpWarranty[0]['contact__name']+" "+tmp_erpWarranty[0]['contact__branch']
            
#             else:
#                 datas['state'] = "unCompleted"
#                 datas['register'] = "registed"
#                 datas['w_data']['product_id'] = tmp_erpWarranty[0]['product']
#                 datas['w_data']['product_code'] = tmp_erpWarranty[0]['product__code']
#                 datas['w_data']['contact_id'] = tmp_erpWarranty[0]['contact']
#                 datas['w_data']['contact_name'] = tmp_erpWarranty[0]['contact__name']
#                 datas['w_data']['contact_branch'] = tmp_erpWarranty[0]['contact__branch']
#                 datas['w_data']['contact_namebranch'] = tmp_erpWarranty[0]['contact__name']+" "+tmp_erpWarranty[0]['contact__branch']
            
#                 datas['w_data']['cust_name'] = tmp_erpWarranty[0]['cust_name']
#                 datas['w_data']['cust_gender'] = tmp_erpWarranty[0]['cust_sex_0__name']
#                 # datas['w_data']['cust_birthday'] = tmp_erpWarranty[0]['cust_birthday']
#                 datas['w_data']['cust_address_full'] = get_fullAddress(tmp_erpWarranty[0]['cust_address'],tmp_erpWarranty[0]['cust_subdistrict__name'],tmp_erpWarranty[0]['cust_district__name'],tmp_erpWarranty[0]['cust_province__name'],tmp_erpWarranty[0]['cust_postal_code']) 
#                 datas['w_data']['cust_address'] = tmp_erpWarranty[0]['cust_address']
#                 datas['w_data']['cust_subdistrict_id'] = tmp_erpWarranty[0]['cust_subdistrict']
#                 datas['w_data']['cust_subdistrict'] =tmp_erpWarranty[0]['cust_subdistrict__name']
#                 datas['w_data']['cust_district_id'] = tmp_erpWarranty[0]['cust_district']
#                 datas['w_data']['cust_district'] = tmp_erpWarranty[0]['cust_district__name']
#                 datas['w_data']['cust_province_id'] = tmp_erpWarranty[0]['cust_province']
#                 datas['w_data']['cust_province'] = tmp_erpWarranty[0]['cust_province__name']
#                 datas['w_data']['cust_postalcode'] = tmp_erpWarranty[0]['cust_postal_code']
#                 datas['w_data']['cust_phone'] = tmp_erpWarranty[0]['cust_phone']
                
#                 datas['w_data']['cust_cartype_id'] = tmp_erpWarranty[0]['cust_car_type_0']
#                 datas['w_data']['cust_cartype'] = tmp_erpWarranty[0]['cust_car_type_0__name']
#                 datas['w_data']['cust_carbrand_id'] = tmp_erpWarranty[0]['cust_car_brand_0']
#                 datas['w_data']['cust_carbrand'] = tmp_erpWarranty[0]['cust_car_brand_0__name']
#                 datas['w_data']['cust_carmodel_id'] = tmp_erpWarranty[0]['cust_car_model_0']
#                 datas['w_data']['cust_carmodel'] = tmp_erpWarranty[0]['cust_car_model_0__name']
#                 datas['w_data']['cust_liceseplateblack'] = tmp_erpWarranty[0]['cust_license_plate_bk']
#                 datas['w_data']['cust_vin'] = tmp_erpWarranty[0]['cust_vin']
#                 datas['w_data']['cust_install_date'] =tmp_erpWarranty[0]['cust_date']
#                 datas['w_data']['cust_warrant_exdate'] = tmp_erpWarranty[0]['warranty_exp_date']
        
#                 datas['w_data']['showroominstall_id'] = tmp_erpWarranty[0]['cust_showroom_0']
#                 # datas['w_data']['showroominstall_name'] = tmp_erpWarranty[0]['cust_showroom_0__name']
#                 # datas['w_data']['showroominstall_branch'] = tmp_erpWarranty[0]['cust_showroom_0__branch']
#                 datas['w_data']['showroominstall_name'] = tmp_erpWarranty[0]['cust_showroom_0__name']+" "+tmp_erpWarranty[0]['cust_showroom_0__branch']
#                 datas['w_data']['showroominstall_address'] =  tmp_erp_showroomAddress[0]['address']
#                 datas['w_data']['showroominstall_phone'] = tmp_erp_showroomAddress[0]['phone']
#                 datas['w_data']['another_position'] = tmp_erpWarranty[0]['remark']
#         elif len(tmp_aiWarranty) > 0  :
#             aiProduct_Brand = get_ai_match_brand()
#             productCodeInAI = list(ai_gi.objects.using('ai').filter(invrqsno=tmp_aiWarranty[0]['invrqsno']).values('invrqsno','itemcd'))
#             ## check brand of product == brand input ?
            
#             if aiProduct_Brand[productCodeInAI[0]['itemcd']] in productBrand:
#                 datas['state']="found"
#                 datas['sys_db']="ai"
            
#         ###### check wNumber Registed ?
#         ########################################################################
#         ######### Get Data To PrintingData  -----> Add column More Here
#                 tmp_ai_CSInput = list(ai_warranty.objects.using('ai').filter(warrantyno=wNumber,customerfirstname__gt='').annotate(cust_name=Concat( F('customerfirstname'),  Value(' '), F('customerlastname'))).values('cust_name','cartypeid','carbrandid','carmodelid','itemcd','installfilmcode','installdate','carchasis','carlicenseno','customersex','customermb','email','customeraddress','customertambol','customeramphur','customerprovince','customerpostcode','dealernm','dealeraddr1','dealeramphur','dealerprovince','dealerpostcode','dealertel' ))
#                 tmp_ai_WOInput = list(ai_warrantyOnline.objects.using('ai').filter(warrantyno=wNumber,customerfirstname__gt='').annotate(cust_name=Concat( F('customerfirstname'),  Value(' '), F('customerlastname'))).values('cust_name','cartypeid','carbrandid','carmodelid','itemcd','installfilmcode','installdate','carchasis','carlicenseno','customersex','customermb','email','customeraddress','customertambol','customeramphur','customerprovince','customerpostcode','dealernm','dealeraddr1','dealeramphur','dealerprovince','dealerpostcode','dealertel','birthday' ))
#         ########################################################################   
#                 if len(tmp_ai_CSInput) > 0:
#                     datas['register']="registed"
#                     datas['w_data']['product_code'] = ai_checkNull_productInstall(tmp_ai_CSInput[0]['itemcd'],tmp_ai_CSInput[0]['installfilmcode'])
#                     datas['w_data']['cust_install_date'] = tmp_ai_CSInput[0]['installdate']
#                     datas['w_data']['cust_cartype'] = get_ai_carType_byID(tmp_ai_CSInput[0]['cartypeid'])
#                     datas['w_data']['cust_carbrand'] = get_ai_carBrand_byID(tmp_ai_CSInput[0]['carbrandid'])
#                     datas['w_data']['cust_carmodel'] = get_ai_carModel_byID(tmp_ai_CSInput[0]['carmodelid'])
#                     datas['w_data']['cust_liceseplateblack'] = tmp_ai_CSInput[0]['carchasis']
#                     datas['w_data']['cust_vin'] = tmp_ai_CSInput[0]['carlicenseno']
#                     datas['w_data']['cust_name'] = tmp_ai_CSInput[0]['cust_name']
#                     datas['w_data']['cust_birthday'] = "" ### DB have not this field
#                     datas['w_data']['cust_gender'] = ai_tranform_gender(tmp_ai_CSInput[0]['customersex'])
#                     datas['w_data']['cust_phone'] = tmp_ai_CSInput[0]['customermb']
#                     datas['w_data']['cust_mail'] = tmp_ai_CSInput[0]['email']
#                     datas['w_data']['cust_warrant_exdate'] = ""
#                     datas['w_data']['cust_address'] = tmp_ai_CSInput[0]['customeraddress']
#                     datas['w_data']['cust_district'] = tmp_ai_CSInput[0]['customeramphur']
#                     datas['w_data']['cust_subdistrict'] = tmp_ai_CSInput[0]['customertambol']
#                     datas['w_data']['cust_province'] = tmp_ai_CSInput[0]['customerprovince']
#                     datas['w_data']['cust_postalcode'] = tmp_ai_CSInput[0]['customerpostcode']
#                     datas['w_data']['cust_address_full'] = get_fullAddress(tmp_ai_CSInput[0]['customeraddress'],
#                                                                         tmp_ai_CSInput[0]['customertambol'],
#                                                                         tmp_ai_CSInput[0]['customeramphur'],
#                                                                         tmp_ai_CSInput[0]['customerprovince'],
#                                                                         tmp_ai_CSInput[0]['customerpostcode']) 
#                     datas['w_data']['showroominstall_name'] = tmp_ai_CSInput[0]['dealernm']
#                     datas['w_data']['showroominstall_address'] =  tmp_ai_CSInput[0]['dealeraddr1'] + " "+  tmp_ai_CSInput[0]['dealeramphur'] + " " + tmp_ai_CSInput[0]['dealerprovince'] + " " + tmp_ai_CSInput[0]['dealerpostcode'] #+ ai_check_phone( tmp_ai_CSInput[0]['dealertel'])
#                     datas['w_data']['showroominstall_phone'] = tmp_ai_CSInput[0]['dealertel']
#                     datas['w_data']['another_position'] = "รอบคัน รหัสฟิล์ม "+ ai_check_nullProduct_returnHyphen(tmp_ai_CSInput[0]['itemcd']) + " บานหน้า รหัสฟิล์ม "+ai_check_nullProduct_returnHyphen(tmp_ai_CSInput[0]['installfilmcode'])
#                     print('----CS')
#                 # #### Check in table tbt_invt_warrantyow [Online Input]    ,'dealeraddr1','dealeramphur','dealerprovince','dealerpostcode','dealertel' 
#                 elif len(tmp_ai_WOInput) > 0:
#                     datas['register']="registed"
#                     datas['w_data']['product_code'] = ai_checkNull_productInstall(tmp_ai_WOInput[0]['itemcd'],tmp_ai_WOInput[0]['installfilmcode'])
#                     datas['w_data']['cust_install_date'] = tmp_ai_WOInput[0]['installdate']
#                     datas['w_data']['cust_cartype'] = get_ai_carType_byID(tmp_ai_WOInput[0]['cartypeid'])
#                     datas['w_data']['cust_carbrand'] = get_ai_carBrand_byID(tmp_ai_WOInput[0]['carbrandid'])
#                     datas['w_data']['cust_carmodel'] = get_ai_carBrand_byID(tmp_ai_WOInput[0]['carbrandid'])
#                     datas['w_data']['cust_liceseplateblack'] = tmp_ai_WOInput[0]['carchasis']
#                     datas['w_data']['cust_vin'] = tmp_ai_WOInput[0]['carlicenseno']
#                     datas['w_data']['cust_name'] = tmp_ai_WOInput[0]['cust_name']
#                     datas['w_data']['cust_birthday'] =tmp_ai_WOInput[0]['birthday']
#                     datas['w_data']['cust_gender'] = ai_tranform_gender(tmp_ai_WOInput[0]['customersex'])
#                     datas['w_data']['cust_phone'] = tmp_ai_WOInput[0]['customermb']
#                     datas['w_data']['cust_mail'] = tmp_ai_WOInput[0]['email']
#                     datas['w_data']['cust_warrant_exdate'] = ""
#                     datas['w_data']['cust_address'] = tmp_ai_WOInput[0]['customeraddress']
#                     datas['w_data']['cust_district'] = tmp_ai_WOInput[0]['customeramphur']
#                     datas['w_data']['cust_subdistrict'] = tmp_ai_WOInput[0]['customertambol']
#                     datas['w_data']['cust_province'] = tmp_ai_WOInput[0]['customerprovince']
#                     datas['w_data']['cust_postalcode'] = tmp_ai_WOInput[0]['customerpostcode']
#                     datas['w_data']['cust_address_full'] = get_fullAddress(tmp_ai_WOInput[0]['customeraddress'],
#                                                                         tmp_ai_WOInput[0]['customertambol'],
#                                                                         tmp_ai_WOInput[0]['customeramphur'],
#                                                                         tmp_ai_WOInput[0]['customerprovince'],
#                                                                         tmp_ai_WOInput[0]['customerpostcode']) 
#                     datas['w_data']['showroominstall_name'] = tmp_ai_WOInput[0]['dealernm']
#                     datas['w_data']['showroominstall_address'] =  tmp_ai_WOInput[0]['dealeraddr1'] + " "+  tmp_ai_WOInput[0]['dealeramphur'] + " " + tmp_ai_WOInput[0]['dealerprovince'] + " " + tmp_ai_WOInput[0]['dealerpostcode'] #+ ai_check_phone( tmp_ai_CSInput[0]['dealertel'])
#                     datas['w_data']['showroominstall_phone'] = tmp_ai_WOInput[0]['dealertel']
#                     datas['w_data']['another_position'] = "รอบคัน รหัสฟิล์ม "+ ai_check_nullProduct_returnHyphen(tmp_ai_WOInput[0]['itemcd']) + " บานหน้า รหัสฟิล์ม "+ai_check_nullProduct_returnHyphen(tmp_ai_WOInput[0]['installfilmcode'])
#                     print('----WO')
#             else :    
#                 datas['state']="notFound"
#                 datas['register']="unRegisted"
#                 datas['sys_db']= "ai"
                
#         else:
#             datas['state'] = "notFound"
#             datas['register'] = ''

#     return datas
#         # else:
#         #     return JsonResponse(True ,safe=False)

        





# @csrf_exempt
# def warrantyNumber_checker_old(request):
#     wNumber = request.POST.get('warranty_number')
#     if  request.method == 'POST':
#     ### Check in ERP:
#         tmp_erpWarranty = list(erp_warranty.objects.filter(number = wNumber).exclude(state='voided').values('id','number','state','cust_name','cust_car_brand_0','cust_car_model_0'))
#     ### Check in AI:
       
#         tmp_aiWarranty = list(ai_warrantyNumber.objects.using('ai').filter(warrantydealerno = wNumber).values('warrantydealerno','invrqsno','warrantydealerstt'))
        
#         if len(tmp_erpWarranty) > 0:
#             datas = {'warranty_id': tmp_erpWarranty[0]['number']}
#             if tmp_erpWarranty[0]['cust_name'] is not None and tmp_erpWarranty[0]['cust_car_brand_0'] is not None and tmp_erpWarranty[0]['cust_car_model_0'] is not None :
#                 datas['state'] = "inERP-registed"
#             elif tmp_erpWarranty[0]['cust_name'] is None and tmp_erpWarranty[0]['cust_car_brand_0'] is None and tmp_erpWarranty[0]['cust_car_model_0'] is None :
#                 datas['state'] = "inERP_nonRegister"
#             else:
#                 datas['state'] = "inERP_uncomplete"
#         elif len(tmp_aiWarranty) > 0:
#             datas = {'warranty_id': tmp_aiWarranty[0]['warrantydealerno']}
#             tmp_aiWarranty_normal = list(ai_warranty.objects.using('ai').filter(warrantyno = wNumber))
#             tmp_aiWarranty_online = list(ai_warrantyOnline.objects.using('ai').filter(warrantyno = wNumber))
#             if len(tmp_aiWarranty_normal) > 0:
#                 datas['state'] = "inAI_normal"
#             elif len(tmp_aiWarranty_online) > 0:
#                 datas['state'] = "inAI_online"
#             else:
#                 datas['state'] = "inAI_nonRegister"
#         else: 
#             datas = {'warranty_id': '',
#                     'state':'notFound',
#                     'regis_state': 'nonRegister'}
#         return JsonResponse(datas , json_dumps_params={'ensure_ascii': False} ,safe=False)

#     else:
#         return JsonResponse(True ,safe=False)
        
    
# @csrf_exempt
# def get_AI_warrantyData(request):
   
#     if  request.method == 'POST':
#         wNumber = request.POST.get('warranty_number')

# @csrf_exempt
# def get_ERP_warrantyData_withNumber(request):
#     if  request.method == 'POST':
#         wNumber = request.POST.get('warranty_number')
#         datas = erp_warranty.objects.filter(number = wNumber).exclude(state='voided').order_by('id').first()
#         print (datas)
#         if datas:
#             container = [{
#                 'state':'haveDatas',
#                 'datas':{
#                     'id_wrt':datas.id,
#                     'number_wrt':datas.number,
#                     'cust_name':datas.cust_name,
#                     # 'cust_dob':datas.cust_dob,
#                     'cust_sex':datas.cust_sex_0,
#                     'cust_mail':datas.notes,
#                     'cust_phone':datas.cust_phone,
#                     'cust_address':datas.cust_address,
#                     'cust_province_id':orm_noneChecker(datas.cust_province,'id'),
#                     'cust_province_name':orm_noneChecker(datas.cust_province,'name'),
#                     'cust_district_id':orm_noneChecker(datas.cust_district,'id'),
#                     'cust_district_name':orm_noneChecker(datas.cust_district,'name'),
#                     'cust_subdistrict_id':orm_noneChecker(datas.cust_subdistrict,'id'),
#                     'cust_subdistrict_name':orm_noneChecker(datas.cust_subdistrict,'name'),
#                     'cust_postalcode':datas.cust_postal_code,
#                     'cust_carbrand_id':orm_noneChecker(datas.cust_car_brand_0,'id'),
#                     'cust_carbrand_name':orm_noneChecker(datas.cust_car_brand_0,'name'),
#                     'cust_carmodel_id':orm_noneChecker(datas.cust_car_model_0,'id'),
#                     'cust_carmodel_name':orm_noneChecker(datas.cust_car_model_0,'name'),
#                     'cust_liceseplateblack':datas.cust_license_plate_bk ,
#                     'cust_vin':datas.cust_vin,
#                     'showroominstall_id':orm_noneChecker(datas.cust_showroom_0,'id'),
#                     'showroominstall_code':orm_noneChecker(datas.cust_showroom_0,'code'),
#                     'showroominstall_name_branch':orm_noneChecker(datas.cust_showroom_0,'name')+' '+orm_noneChecker(datas.cust_showroom_0,'branch'),
#                     'cust_dateinstall':datas.cust_date,
#                     'locationinstall_id':datas.area_film_0.id,
#                     'locationinstall_name':datas.area_film_0.name,
#                     'another_position':datas.remark,
#                     'cust_checknumber':datas.ref,
#                     'cust_status':datas.state
#                 }
#             }]
#             print (container)
#             return JsonResponse(container , json_dumps_params={'ensure_ascii': False} ,safe=False)
#     else:
#         return JsonResponse(True ,safe=False)
    
# @csrf_exempt
# def get_warrantyData_withCUSdata(request):
#     if request.method =='POST':
#         if request.POST.get('searchMethod') == 'withCusName':
#             pass
#         elif request.POST.get('searchMethod') == 'withWarrntyNumber':
#             pass

# @csrf_exempt
# def get_ERP_warrantyData_withID(request):
#     if  request.method == 'POST':
#         wID = request.POST.get('id_wrt')
#         datas = list(erp_warranty.objects.filter(id = wID).exclude(state='voided'))
#         print (datas)
#         if datas:
#             container = {
#                 'state':'haveDatas',
#                 'datas':{
#                     'id_wrt':datas[0]['id'],
#                     'number_wrt':datas[0]['number'],
#                     'cust_name':datas[0]['cust_name'],
#                     'cust_dob':datas[0]['cust_dob'],
#                     'cust_sex':datas[0]['cust_sex_id'],
#                     'cust_mail':datas[0]['notes'],
#                     'cust_phone':datas[0]['cust_phone'],
#                     'cust_address':datas[0]['cust_address'],
#                     'cust_province_id':datas[0]['cust_province_id'],
#                     # 'cust_province':datas[0][''],
#                     'cust_district_id':datas[0]['cust_district_id'],
#                     # 'cust_district':datas[0]['cust_district'],
#                     'cust_subdistrict_id':datas[0]['cust_subdistrict_id'],
#                     # 'cust_subdistrict':datas[0]['cust_subdistrict'],
#                     'cust_postalcode':datas[0]['cust_postal_code'],
#                     # 'cust_carbrand':datas[0][''],
#                     'cust_carbrand_id':datas[0]['cust_carbrand_id'],
#                     # 'cust_carmodel':datas[0]['cust_carmodel'],
#                     'cust_carmodel_id':datas[0]['cust_carmodel_id'],
#                     # 'cust_carmodel':datas[0]['cust_carmodel'],
#                     'cust_liceseplateblack':datas[0]['cust_liceseplateblack'],
#                     'cust_vin':datas[0]['cust_vin'],
#                     'showroominstall_id':datas[0]['cust_showroom_id'],
#                     # 'showroominstall':datas[0][''],
#                     'cust_dateinstall':datas[0]['cust_date'],
#                     'locationinstall':datas[0]['area_film_id'],
#                     'another_position':datas[0]['remark'],
#                     'cust_checknumber':datas[0]['ref'],
#                     'cust_status':datas[0]['state']
#                 }
#             }
      
#             return JsonResponse(container , json_dumps_params={'ensure_ascii': False} ,safe=False)
#     else:
#         return JsonResponse(True ,safe=False)
