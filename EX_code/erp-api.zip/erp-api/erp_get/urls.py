from django.urls import path,include
from . import views



app_name = 'erp_get'
urlpatterns = [
    path('provinceAll/',views.province_all, name='provinceAll'),
    path('districtAll/',views.district_all, name='districtAll'),
    path('districtWithProvince',views.district_withProvince, name='districtWithProvince'),
    path('subdistrictAll/',views.district_all, name='districtAll'),
    path('subdistrictWithDistrict',views.subdistrict_withProvince, name='subdistrictWithDistrict'),
    path('zipCodeWithDistrict',views.zipCode_withProvince, name='zipCodeWithSubdistrict'),
    path('carBrand/',views.car_brand, name='carBrand'),
    path('carModel/',views.car_model, name='carModel'),
    path('carModelWithCarModel',views.carModel_withCarModel, name='carModelWithCarModel'),
    path('gender/',views.gender, name='gender'),
    path('cusContact/',views.customerContact, name='cusContact'),
    path('cusContactWithProvice',views.customerContact_withProvince, name='cusContactWithProvice'),
    path('product_lamina',views.productLamina, name='product_lamina'),
    path('product_xtraCole',views.productXtraCole, name='product_xtraCole'),
    path('product_glasia',views.productGlasia, name='product_glasia'),
    
    path('wNumberChecker',views.warrantyNumber_checker, name='wNumberChecker'),
    
    path('wNumberFinder',views.warrantyNumber_Finder, name='wNumberFinder'),
    path('get_warrantyAI',views.get_AI_warrantyData, name='getWarrantyAI'),
    
    path('productGroup',views.productGroup, name='productGroup'),
    path('productWithGroup',views.productWithGroup, name='productWithGroup'),
    # path('get_warrantyERPwithNumber',views.get_ERP_warrantyData_withNumber, name='getWarrantyERPwithNumber'),
    # path('get_warrantyERPwithID',views.get_ERP_warrantyData_withID, name='get_warrantyERPwithID'),
]
