from django.http import JsonResponse
from django.db.models import F, Value
from django.db.models.functions import Concat
from django.shortcuts import render
from django.views.decorators.csrf import csrf_exempt

from erp_models.ai_models import TbtInvtWarrantydealer as ai_warrantyDealer
from erp_models.ai_models import TbtInvtWarranty as ai_warranty
from erp_models.ai_models import TbtInvtWarrantyow as ai_warrantyOnline
from erp_models.ai_models import TbtInvtInvrqs as ai_gi
from erp_models.ai_models import TbmLgstCartype as ai_carType
from erp_models.ai_models import TbmLgstCarbrand as ai_carBrand
from erp_models.ai_models import TbmLgstCarmodel as ai_carModel
from erp_models.erp_models import Address as erp_address
from erp_models.erp_models import Province as erp_province
from erp_models.erp_models import District as erp_district
from erp_models.erp_models import Subdistrict as erp_subdistrict
from erp_models.erp_models import PostalCode as erp_zipCode
from erp_models.erp_models import CarBrand as erp_carBrand
from erp_models.erp_models import CarModel as erp_carModel
from erp_models.erp_models import Contact as erp_contact
from erp_models.erp_models import Product as erp_product
from erp_models.erp_models import Sex as erp_gender
from erp_models.erp_models import ServiceItem as erp_warranty
from erp_models.WOnline_models import MatchmakerAiProduct as erp_ai_brandmatch


# , District, Subdistrict, Contact


laminaPage_brand = [36,52]
xtraColePage_brand = [38]
glasiaPage_brand = [37]

# Create your views here.
def orm_noneChecker(data,conditionKey):
    if data is not None:
        return getattr(data,conditionKey, None)
    else:
        return None
def get_ai_match_brand():
    aiProductBrand = {}
    tmpDatas = list(erp_ai_brandmatch.objects.using('WOnline').values('ai_product','erp_brand_id'))
    for data in tmpDatas:
        aiProductBrand[data['ai_product']]=data['erp_brand_id']
    return aiProductBrand
def get_ai_carBrand():
    aiCarBrand = {}
    tmpDatas = list(ai_carBrand.objects.using('ai').values('carbrandid','carbrandnm'))
    for data in tmpDatas:
        aiCarBrand[data['carbrandid']]=data['carbrandnm']
    return aiCarBrand
def get_ai_carModel():
    aiCarBrand = {}
    tmpDatas = list(ai_carModel.objects.using('ai').values('carmodelid','carmodelnm'))
    for data in tmpDatas:
        aiCarBrand[data['carmodelid']]=data['carmodelnm']
    return aiCarBrand

def get_ai_carType_byID(id):
    tmpDatas = list(ai_carType.objects.using('ai').filter(cartypeid=id).values('cartypenm'))[0]['cartypenm']
    return tmpDatas
def get_ai_carBrand_byID(id):
    tmpDatas = list(ai_carBrand.objects.using('ai').filter(carbrandid=id).values('carbrandnm'))[0]['carbrandnm']
    return tmpDatas
def get_ai_carModel_byID(id):
    tmpDatas = list(ai_carModel.objects.using('ai').filter(carmodelid=id).values('carmodelnm'))[0]['carmodelnm']
    return tmpDatas
def ai_checkNull_productInstall (itemcd,intstallfilmscode):
    if intstallfilmscode != '':
        return intstallfilmscode
    else:
        return itemcd
def ai_check_nullProduct_returnHyphen(data):
    if data =='':
        return "-"
    else:
        return data
def ai_tranform_gender(data):
    if data == "M":
        return "Male"
    elif data == "F":
        return "Female"
    else:
        return "Unknow"
def ai_check_phone(data):
    if data != "":
        return "โทร "+ data
    else:
        return ""
def get_erp_carBrand():
    erpCarBrand = {}
    tmpDatas = list (erp_carBrand.objects.using('erp').values('id','name'))
    for data in tmpDatas:
        erpCarBrand[data['id']]=data['name']
    return erpCarBrand
def get_erp_carModel():
    erpCarModel = {}
    tmpDatas = list (erp_carModel.objects.using('erp').values('id','name'))
    for data in tmpDatas:
        erpCarModel[data['id']]=data['name']
    return erpCarModel
def get_erp_province():
    erpProvice = {}
    tmpDatas = list (erp_province.objects.using('erp').values('id','name'))
    for data in tmpDatas:
        erpProvice[data['id']]=data['name']
    return erpProvice
def get_erp_district():
    erpDistrict = {}
    tmpDatas = list (erp_district.objects.using('erp').values('id','name'))
    for data in tmpDatas:
        erpDistrict[data['id']]=data['name']
    return erpDistrict
def get_erp_subDistrict():
    erpSubDistrict = {}
    tmpDatas = list (erp_subdistrict.objects.using('erp').values('id','name'))
    for data in tmpDatas:
        erpSubDistrict[data['id']]=data['name']
    return erpSubDistrict
def get_erp_postCode():
    erpPostCode = {}
    tmpDatas = list (erp_zipCode.objects.using('erp').values('id','name'))
    for data in tmpDatas:
        erpPostCode[data['id']]=data['name']
    return erpPostCode
def get_fullAddress(address,subdistrict,district,province,postcode):
    if province == "กรุงเทพมหานคร":
        tmpTXT = address + " แขวง" + subdistrict + " เขต" + district + " " + province + " " +postcode
    else:
        tmpTXT = address + " ตำบล" + subdistrict + " อำเภอ" + district + " จังหวัด" + province + " " +postcode
    return tmpTXT

@csrf_exempt
def province_all (request):
    datas  = list (erp_province.objects.filter(country=1).order_by('name').values('id','name'))
    datas = sorted(datas, key=lambda x: x['name'])
    return JsonResponse(datas , json_dumps_params={'ensure_ascii': False} ,safe=False)

@csrf_exempt
def district_all (request):
    datas  = list (erp_district.objects.values('id','name'))
    datas = sorted(datas, key=lambda x: x['name'])
    return JsonResponse(datas , json_dumps_params={'ensure_ascii': False} ,safe=False)

@csrf_exempt
def district_withProvince (request):
    if  request.method == 'POST':
        province_id = request.POST.get('province_id')
        datas  = list (erp_district.objects.filter(province = province_id).values('id','name'))
        datas = sorted(datas, key=lambda x: x['name'])
        return JsonResponse(datas , json_dumps_params={'ensure_ascii': False} ,safe=False)
    else:
       return JsonResponse(True ,safe=False)
   
@csrf_exempt   
def subdistrict_all (request):
    datas  = list (erp_subdistrict.objects.values('id','name'))
    datas = sorted(datas, key=lambda x: x['name'])
    return JsonResponse(datas , json_dumps_params={'ensure_ascii': False} ,safe=False)

@csrf_exempt
def subdistrict_withProvince (request):
    if  request.method == 'POST':
        district_id = request.POST.get('district_id')
        datas  = list (erp_subdistrict.objects.filter(district = district_id).values('id','name'))
        datas = sorted(datas, key=lambda x: x['name'])
        return JsonResponse(datas , json_dumps_params={'ensure_ascii': False} ,safe=False)
    else:
       return JsonResponse(True ,safe=False)
    
@csrf_exempt
def zipCode_withProvince (request):
    if  request.method == 'POST':
        district_id = request.POST.get('subdistrict_id')
        datas  = list (erp_zipCode.objects.filter(subdistrict = district_id).values('id','code'))
        datas = sorted(datas, key=lambda x: x['code'])
        return JsonResponse(datas , json_dumps_params={'ensure_ascii': False} ,safe=False)
    else:
        return JsonResponse(True ,safe=False)
    
@csrf_exempt
def car_brand (request):
    datas  = list (erp_carBrand.objects.order_by('name').values('id','name'))
    datas = sorted(datas, key=lambda x: x['name'])
    return JsonResponse(datas , json_dumps_params={'ensure_ascii': False} ,safe=False)

@csrf_exempt
def car_model (request):
    datas  = list (erp_carModel.objects.order_by('name').values('id','name'))
    datas = sorted(datas, key=lambda x: x['name'])
    return JsonResponse(datas , json_dumps_params={'ensure_ascii': False} ,safe=False)

@csrf_exempt
def carModel_withCarModel (request):
    if  request.method == 'POST':
        carBrand_id = request.POST.get('carBrand_id')
        datas  = list(erp_carModel.objects.filter(brand=carBrand_id).exclude(code__contains='[CLOSE]').values('id','name'))
        datas = sorted(datas, key=lambda x: x['name'])
        return JsonResponse(datas , json_dumps_params={'ensure_ascii': False} ,safe=False)
    else:
        return JsonResponse(True ,safe=False)

@csrf_exempt
def customerContact (request):
    datas  = list (erp_contact.objects.filter(active=True,customer=True,type='org').annotate(name_branch=Concat(F('name'), Value(''), F('branch'))).values('id','name_branch'))
    datas = sorted(datas, key=lambda x: x['name_branch'])
    return JsonResponse(datas , json_dumps_params={'ensure_ascii': False} ,safe=False)

@csrf_exempt
def customerContact_withProvince (request):
    if  request.method == 'POST':
        province_id = request.POST.get('province_id')
        datas  = list (erp_contact.objects.filter(active=True,customer=True,type='org', address__type='shipping',categ__in=[29, 31, 98, 32, 34, 97],address__province_0=province_id).annotate(name_branch=Concat( F('name'),  Value(''), F('branch'))).values('id','name_branch'))
        datas = sorted(datas, key=lambda x: x['name_branch'])
        return JsonResponse(datas , json_dumps_params={'ensure_ascii': False} ,safe=False)
    else:
        return JsonResponse(True ,safe=False)
    
@csrf_exempt
def productLamina (request):
    datas  = list (erp_product.objects.filter(active=True,type='stock',brand__in=laminaPage_brand).values('id','code','name'))
    datas = sorted(datas, key=lambda x: x['code'])
    return JsonResponse(datas , json_dumps_params={'ensure_ascii': False} ,safe=False)

    
@csrf_exempt
def productXtraCole (request):

    datas  = list (erp_product.objects.filter(active=True,type='stock',brand__in=xtraColePage_brand).values('id','code','name'))
    datas = sorted(datas, key=lambda x: x['code'])
    return JsonResponse(datas , json_dumps_params={'ensure_ascii': False} ,safe=False)

@csrf_exempt
def productGlasia (request):
    datas  = list (erp_product.objects.filter(active=True,type='stock',brand__in=glasiaPage_brand).values('id','code','name'))
    datas = sorted(datas, key=lambda x: x['code'])
    return JsonResponse(datas , json_dumps_params={'ensure_ascii': False} ,safe=False)


@csrf_exempt
def gender (request):
    datas  = list (erp_gender.objects.order_by('name').values('id','name'))
    datas = sorted(datas, key=lambda x: x['name'])
    return JsonResponse(datas , json_dumps_params={'ensure_ascii': False} ,safe=False)

@csrf_exempt
def warrantyNumber_checker(request):
    ################################################################################################################################
    # datas = {
    #     'state':'found/notFound',
    #     'sys_db':'erp/ai',
    #     'register':'registed/registed',
    #     'w_data':{
    #         'cust_name':'',
    #         'cust_address':'',
    #         'selected_province_name':'',
    #         'selected_district_name':'',
    #         'selected_subdistrict_name':'',
    #         'cust_postalcode':'',
    #         'selected_carbrand_name':'',
    #         'selected_carmodel_name':'',
    #         'cust_vin':'',
    #         'selected_cust_provin_install':'',
    #         'selected_cust_showroom_install':'',
    #         'cust_dateinstall':'',
    #         'selected_cust_location':'',
    #         'another_position':''
    #         }
    # }
    
    ################################################################################################################################
    
    
    if request.method == 'POST':
        wNumber = request.POST.get('warranty_number')
        pageBrand =  request.POST.get('brand')
        productBrand = []
        
        ####data MarkUP
        # result_datas = {'input_wNumber': wNumber}
        datas = {
                'state':'',#'found/notFound',
                'sys_db':'',#'erp/ai',
                'register':'',#'registed/unRegisted',
                'brand':pageBrand,#'lamina/xtra-cole/glasia',
                'number_wrt':wNumber,
                'w_data':{
                    'id_wrt':'',
                    'cust_name':'',
                    'cust_dob':'',
                    'cust_sex':'',
                    'cust_mail':'',
                    'cust_phone':'',
                    'cust_address':'',
                    'cust_province':'',
                    'cust_district':'',
                    'cust_postalcode':'',
                    'cust_carbrand':'',
                    'cust_carmodel':'',
                    'cust_liceseplateblack':'',
                    'cust_vin':'',
                    'showroominstall':'',
                    'cust_dateinstall':'',
                    'locationinstall':'',
                    'another_position':''
                    }
            }
        ########
        if pageBrand == 'lamina':
            productBrand = laminaPage_brand
        elif pageBrand == 'xtra-cole':
            productBrand = xtraColePage_brand
        elif pageBrand == 'glasia':
            productBrand = glasiaPage_brand
        else:
            datas['state'] = "notFound"
            return JsonResponse(datas , json_dumps_params={'ensure_ascii': False} ,safe=False)
        
    ### Check in ERP:
        tmp_erpWarranty = list(erp_warranty.objects.filter(number = wNumber,product__brand__in=productBrand).exclude(state='voided').values('id',
                'state',
                'product',
                'product__code',
                'product__name',
                'contact',
                'contact__name',
                'contact__branch',
                'cust_name',
                'area_film_0',
                'cust_date',
                'warranty_exp_date',
                # 'cust_birthday',
                'cust_sex_0',
                'cust_sex_0__name',
                'cust_phone', 
                'cust_address',
                'cust_subdistrict',
                'cust_district',
                'cust_province',
                'cust_country',                                                                                                                                            
                'cust_subdistrict__name',
                'cust_district__name',
                'cust_province__name',
                'cust_postal_code',
                'cust_country__name',
                'cust_license_plate_bk',
                'cust_vin',
                'cust_car_type_0',
                'cust_car_brand_0',
                'cust_car_model_0',
                'cust_car_type_0__name',
                'cust_car_brand_0__name',
                'cust_car_model_0__name',
                'cust_showroom',
                'cust_showroom_0',
                'cust_showroom_0__name',
                'cust_showroom_0__branch',
                'remark',
                'cust_license_plate',
                'front_license_plate',
                'remark'
                ))
    ### Check in AI:
        tmp_aiWarranty = list(ai_warrantyDealer.objects.using('ai').filter(warrantydealerno = wNumber).values('warrantydealerno','invrqsno','warrantydealerstt'))

        if len(tmp_erpWarranty) > 0:
            datas['state'] = "found"
            datas['sys_db'] = "erp"
            tmp_erp_showroomAddress = list(erp_address.objects.filter(contact=tmp_erpWarranty[0]['contact'],type='billing').values('address','province_0__name','phone'))
            
            # tmp_erp = erp_warranty.objects.using('erp').filter(number=wNumber).values('id','name')
            # datas = {'warranty_id': tmp_erpWarranty[0]['number']}
            if tmp_erpWarranty[0]['cust_name'] is not None and tmp_erpWarranty[0]['cust_car_brand_0'] is not None and tmp_erpWarranty[0]['cust_car_model_0'] is not None :
                datas['register'] = "registed"
                datas['w_data']['product'] = tmp_erpWarranty[0]['product']
                datas['w_data']['product_code'] = tmp_erpWarranty[0]['product__code']
                datas['w_data']['contact'] = tmp_erpWarranty[0]['contact']
                datas['w_data']['contact_name'] = tmp_erpWarranty[0]['contact__name']
                datas['w_data']['contact_branch'] = tmp_erpWarranty[0]['contact__branch']
                datas['w_data']['contact_namebranch'] = tmp_erpWarranty[0]['contact__name']+" "+tmp_erpWarranty[0]['contact__branch']
                datas['w_data']['cust_install_date'] =tmp_erpWarranty[0]['cust_date']
                datas['w_data']['cust_cartype'] = tmp_erpWarranty[0]['cust_car_type_0']
                datas['w_data']['cust_carbrand'] = tmp_erpWarranty[0]['cust_car_brand_0']
                datas['w_data']['cust_carmodel'] = tmp_erpWarranty[0]['cust_car_model_0']
                datas['w_data']['cust_liceseplateblack'] = tmp_erpWarranty[0]['cust_license_plate_bk']
                datas['w_data']['cust_vin'] = tmp_erpWarranty[0]['cust_vin']
                datas['w_data']['cust_name'] = tmp_erpWarranty[0]['cust_name']
                # datas['w_data']['cust_birthday'] = tmp_erpWarranty[0]['cust_birthday']
                datas['w_data']['cust_gender'] = tmp_erpWarranty[0]['cust_name']
                datas['w_data']['cust_phone'] = tmp_erpWarranty[0]['cust_phone']
                datas['w_data']['cust_mail'] = tmp_erpWarranty[0]['cust_name']
                datas['w_data']['cust_warrant_exdate'] = tmp_erpWarranty[0]['warranty_exp_date']
                datas['w_data']['cust_address'] = tmp_erpWarranty[0]['cust_address']
        
                datas['w_data']['cust_district_id'] = tmp_erpWarranty[0]['cust_district']
                datas['w_data']['cust_subdistrict_id'] = tmp_erpWarranty[0]['cust_subdistrict']
                datas['w_data']['cust_province_id'] = tmp_erpWarranty[0]['cust_province']
                datas['w_data']['cust_country_id'] = tmp_erpWarranty[0]['cust_country']
                
                datas['w_data']['cust_district'] = tmp_erpWarranty[0]['cust_district__name']
                datas['w_data']['cust_subdistrict'] =tmp_erpWarranty[0]['cust_subdistrict__name']
                datas['w_data']['cust_province'] = tmp_erpWarranty[0]['cust_province__name']
                datas['w_data']['cust_postalcode'] = tmp_erpWarranty[0]['cust_postal_code']
                datas['w_data']['cust_address_full'] = get_fullAddress(tmp_erpWarranty[0]['cust_address'],tmp_erpWarranty[0]['cust_subdistrict__name'],tmp_erpWarranty[0]['cust_district__name'],tmp_erpWarranty[0]['cust_province__name'],tmp_erpWarranty[0]['cust_postal_code']) 
                
                datas['w_data']['showroominstall_id'] = tmp_erpWarranty[0]['cust_showroom_0']
                # datas['w_data']['showroominstall_name'] = tmp_erpWarranty[0]['cust_showroom_0__name']
                # datas['w_data']['showroominstall_branch'] = tmp_erpWarranty[0]['cust_showroom_0__branch']
                datas['w_data']['showroominstall_name'] = tmp_erpWarranty[0]['cust_showroom_0__name']+" "+tmp_erpWarranty[0]['cust_showroom_0__branch']
                datas['w_data']['showroominstall_address'] =  tmp_erp_showroomAddress[0]['address']
                datas['w_data']['showroominstall_phone'] = tmp_erp_showroomAddress[0]['phone']
                datas['w_data']['another_position'] = tmp_erpWarranty[0]['remark']
                print ('OK')
            elif tmp_erpWarranty[0]['cust_name'] is None and tmp_erpWarranty[0]['cust_car_brand_0'] is None and tmp_erpWarranty[0]['cust_car_model_0'] is None :
                datas['register'] = "unRegisted"
            else:
                datas['state'] = "unCompleted"
                datas['register'] = "registed"
                datas['w_data']['product'] = tmp_erpWarranty[0]['product']
                datas['w_data']['product_code'] = tmp_erpWarranty[0]['product__code']
                datas['w_data']['contact'] = tmp_erpWarranty[0]['contact']
                datas['w_data']['contact_name'] = tmp_erpWarranty[0]['contact__name']
                datas['w_data']['contact_branch'] = tmp_erpWarranty[0]['contact__branch']
                datas['w_data']['contact_namebranch'] = tmp_erpWarranty[0]['contact__name']+" "+tmp_erpWarranty[0]['contact__branch']
                datas['w_data']['cust_install_date'] =tmp_erpWarranty[0]['cust_date']
                datas['w_data']['cust_cartype'] = tmp_erpWarranty[0]['cust_car_type_0']
                datas['w_data']['cust_carbrand'] = tmp_erpWarranty[0]['cust_car_brand_0']
                datas['w_data']['cust_carmodel'] = tmp_erpWarranty[0]['cust_car_model_0']
                datas['w_data']['cust_liceseplateblack'] = tmp_erpWarranty[0]['cust_license_plate_bk']
                datas['w_data']['cust_vin'] = tmp_erpWarranty[0]['cust_vin']
                datas['w_data']['cust_name'] = tmp_erpWarranty[0]['cust_name']
                # datas['w_data']['cust_birthday'] = tmp_erpWarranty[0]['cust_birthday']
                datas['w_data']['cust_gender'] = tmp_erpWarranty[0]['cust_name']
                datas['w_data']['cust_phone'] = tmp_erpWarranty[0]['cust_phone']
                datas['w_data']['cust_mail'] = tmp_erpWarranty[0]['cust_name']
                datas['w_data']['cust_warrant_exdate'] = tmp_erpWarranty[0]['warranty_exp_date']
                datas['w_data']['cust_address'] = tmp_erpWarranty[0]['cust_address']
        
                datas['w_data']['cust_district_id'] = tmp_erpWarranty[0]['cust_district']
                datas['w_data']['cust_subdistrict_id'] = tmp_erpWarranty[0]['cust_subdistrict']
                datas['w_data']['cust_province_id'] = tmp_erpWarranty[0]['cust_province']
                datas['w_data']['cust_country_id'] = tmp_erpWarranty[0]['cust_country']
                
                datas['w_data']['cust_district'] = tmp_erpWarranty[0]['cust_district__name']
                datas['w_data']['cust_subdistrict'] =tmp_erpWarranty[0]['cust_subdistrict__name']
                datas['w_data']['cust_province'] = tmp_erpWarranty[0]['cust_province__name']
                datas['w_data']['cust_postalcode'] = tmp_erpWarranty[0]['cust_postal_code']
                datas['w_data']['cust_address_full'] = get_fullAddress(tmp_erpWarranty[0]['cust_address'],tmp_erpWarranty[0]['cust_subdistrict__name'],tmp_erpWarranty[0]['cust_district__name'],tmp_erpWarranty[0]['cust_province__name'],tmp_erpWarranty[0]['cust_postal_code']) 
                
                datas['w_data']['showroominstall_id'] = tmp_erpWarranty[0]['cust_showroom_0']
                # datas['w_data']['showroominstall_name'] = tmp_erpWarranty[0]['cust_showroom_0__name']
                # datas['w_data']['showroominstall_branch'] = tmp_erpWarranty[0]['cust_showroom_0__branch']
                datas['w_data']['showroominstall_name'] = tmp_erpWarranty[0]['cust_showroom_0__name']+" "+tmp_erpWarranty[0]['cust_showroom_0__branch']
                datas['w_data']['showroominstall_address'] =  tmp_erp_showroomAddress[0]['address']
                datas['w_data']['showroominstall_phone'] = tmp_erp_showroomAddress[0]['phone']
                datas['w_data']['another_position'] = tmp_erpWarranty[0]['remark']
        elif len(tmp_aiWarranty) > 0  :
            aiProduct_Brand = get_ai_match_brand()
            productCodeInAI = list(ai_gi.objects.using('ai').filter(invrqsno=tmp_aiWarranty[0]['invrqsno']).values('invrqsno','itemcd'))
            ## check brand of product == brand input ?
         
            if aiProduct_Brand[productCodeInAI[0]['itemcd']] in productBrand:
                datas['state']="found"
                datas['sys_db']="ai"
                
            ###### check wNumber Registed ?
                #### Check in table tbt_invt_warranty [CS Input]  
    ########################################################################
    ######### Get Data To PrintingData  -----> Add column More Here
                tmp_ai_CSInput = list(ai_warranty.objects.using('ai').filter(warrantyno=wNumber,customerfirstname__gt='',carmodelid__gt=0).annotate(cust_name=Concat( F('customerfirstname'),  Value(' '), F('customerlastname'))).values('cust_name','cartype','carbrandid','carmodelid','itemcd','installfilmcode','installdate','carchasis','carlicenseno','customersex','customermb','email','customeraddress','customertambol','customeramphur','customerprovince','customerpostcode','dealernm','dealeraddr1','dealeramphur','dealerprovince','dealerpostcode','dealertel' ))
                tmp_ai_WOInput = list(ai_warrantyOnline.objects.using('ai').filter(warrantyno=wNumber,customerfirstname__gt='',carmodelid__gt=0).annotate(cust_name=Concat( F('customerfirstname'),  Value(' '), F('customerlastname'))).values('cust_name','cartype','carbrandid','carmodelid','itemcd','installfilmcode','installdate','carchasis','carlicenseno','customersex','customermb','email','customeraddress','customertambol','customeramphur','customerprovince','customerpostcode','dealernm','dealeraddr1','dealeramphur','dealerprovince','dealerpostcode','dealertel','birthday' ))
    ########################################################################   
                if len(tmp_ai_CSInput) > 0:
                    datas['register']="registed"
                    datas['w_data']['product_code'] = ai_checkNull_productInstall(tmp_ai_CSInput[0]['itemcd'],tmp_ai_CSInput[0]['installfilmcode'])
                    datas['w_data']['cust_install_date'] = tmp_ai_CSInput[0]['installdate']
                    datas['w_data']['cust_cartype'] = get_ai_carType_byID(tmp_ai_CSInput[0]['cartypeid'])
                    datas['w_data']['cust_carbrand'] = get_ai_carBrand_byID(tmp_ai_CSInput[0]['carbrandid'])
                    datas['w_data']['cust_carmodel'] = get_ai_carModel_byID(tmp_ai_CSInput[0]['carmodelid'])
                    datas['w_data']['cust_liceseplateblack'] = tmp_ai_CSInput[0]['carchasis']
                    datas['w_data']['cust_vin'] = tmp_ai_CSInput[0]['carlicenseno']
                    datas['w_data']['cust_name'] = tmp_ai_CSInput[0]['cust_name']
                    datas['w_data']['cust_birthday'] = "" ### DB have not this field
                    datas['w_data']['cust_gender'] = ai_tranform_gender(tmp_ai_CSInput[0]['customersex'])
                    datas['w_data']['cust_phone'] = tmp_ai_CSInput[0]['customermb']
                    datas['w_data']['cust_mail'] = tmp_ai_CSInput[0]['email']
                    datas['w_data']['cust_warrant_exdate'] = ""
                    datas['w_data']['cust_address'] = tmp_ai_CSInput[0]['customeraddress']
                    datas['w_data']['cust_district'] = tmp_ai_CSInput[0]['customeramphur']
                    datas['w_data']['cust_subdistrict'] = tmp_ai_CSInput[0]['customertambol']
                    datas['w_data']['cust_province'] = tmp_ai_CSInput[0]['customerprovince']
                    datas['w_data']['cust_postalcode'] = tmp_ai_CSInput[0]['customerpostcode']
                    datas['w_data']['cust_address_full'] = get_fullAddress(tmp_ai_CSInput[0]['customeraddress'],tmp_ai_CSInput[0]['customertambol'],tmp_ai_CSInput[0]['customeramphur'],tmp_ai_CSInput[0]['customerprovince'],tmp_ai_CSInput[0]['customerpostcode']) 
                    datas['w_data']['showroominstall_name'] = tmp_ai_CSInput[0]['dealernm']
                    datas['w_data']['showroominstall_address'] =  tmp_ai_CSInput[0]['dealeraddr1'] + " "+  tmp_ai_CSInput[0]['dealeramphur'] + " " + tmp_ai_CSInput[0]['dealerprovince'] + " " + tmp_ai_CSInput[0]['dealerpostcode'] #+ ai_check_phone( tmp_ai_CSInput[0]['dealertel'])
                    datas['w_data']['showroominstall_phone'] = tmp_ai_CSInput[0]['dealertel']
                    datas['w_data']['another_position'] = "รอบคัน รหัสฟิล์ม "+ ai_check_nullProduct_returnHyphen(tmp_ai_CSInput[0]['itemcd']) + " บานหน้า รหัสฟิล์ม "+ai_check_nullProduct_returnHyphen(tmp_ai_CSInput[0]['installfilmcode'])
                    print('----CS')
                # #### Check in table tbt_invt_warrantyow [Online Input]    ,'dealeraddr1','dealeramphur','dealerprovince','dealerpostcode','dealertel' 
                elif len(tmp_ai_WOInput) > 0:
                    datas['register']="registed"
                    datas['w_data']['product_code'] = ai_checkNull_productInstall(tmp_ai_WOInput[0]['itemcd'],tmp_ai_WOInput[0]['installfilmcode'])
                    datas['w_data']['cust_install_date'] = tmp_ai_WOInput[0]['installdate']
                    datas['w_data']['cust_cartype'] = get_ai_carType_byID(tmp_ai_WOInput[0]['cartypeid'])
                    datas['w_data']['cust_carbrand'] = get_ai_carBrand_byID(tmp_ai_WOInput[0]['carbrandid'])
                    datas['w_data']['cust_carmodel'] = get_ai_carBrand_byID(tmp_ai_WOInput[0]['carbrandid'])
                    datas['w_data']['cust_liceseplateblack'] = tmp_ai_WOInput[0]['carchasis']
                    datas['w_data']['cust_vin'] = tmp_ai_WOInput[0]['carlicenseno']
                    datas['w_data']['cust_name'] = tmp_ai_WOInput[0]['cust_name']
                    datas['w_data']['cust_birthday'] =tmp_ai_WOInput[0]['birthday']
                    datas['w_data']['cust_gender'] = ai_tranform_gender(tmp_ai_WOInput[0]['customersex'])
                    datas['w_data']['cust_phone'] = tmp_ai_WOInput[0]['customermb']
                    datas['w_data']['cust_mail'] = tmp_ai_WOInput[0]['email']
                    datas['w_data']['cust_warrant_exdate'] = ""
                    datas['w_data']['cust_address'] = tmp_ai_WOInput[0]['customeraddress']
                    datas['w_data']['cust_district'] = tmp_ai_WOInput[0]['customeramphur']
                    datas['w_data']['cust_subdistrict'] = tmp_ai_WOInput[0]['customertambol']
                    datas['w_data']['cust_province'] = tmp_ai_WOInput[0]['customerprovince']
                    datas['w_data']['cust_postalcode'] = tmp_ai_WOInput[0]['customerpostcode']
                    datas['w_data']['cust_address_full'] = get_fullAddress(tmp_ai_WOInput[0]['customeraddress'],tmp_ai_WOInput[0]['customertambol'],tmp_ai_CSInput[0]['customeramphur'],tmp_ai_WOInput[0]['customerprovince'],tmp_ai_WOInput[0]['customerpostcode']) 
                    datas['w_data']['showroominstall_name'] = tmp_ai_WOInput[0]['dealernm']
                    datas['w_data']['showroominstall_address'] =  tmp_ai_WOInput[0]['dealeraddr1'] + " "+  tmp_ai_WOInput[0]['dealeramphur'] + " " + tmp_ai_WOInput[0]['dealerprovince'] + " " + tmp_ai_WOInput[0]['dealerpostcode'] #+ ai_check_phone( tmp_ai_CSInput[0]['dealertel'])
                    datas['w_data']['showroominstall_phone'] = tmp_ai_WOInput[0]['dealertel']
                    datas['w_data']['another_position'] = "รอบคัน รหัสฟิล์ม "+ ai_check_nullProduct_returnHyphen(tmp_ai_WOInput[0]['itemcd']) + " บานหน้า รหัสฟิล์ม "+ai_check_nullProduct_returnHyphen(tmp_ai_WOInput[0]['installfilmcode'])
                    print('----WO')
                else :    
                    datas['register']="unRegisted"
                    print ('OK')
                
            else:
                datas['state'] = "notFound"
                datas['register'] = ''
                # return JsonResponse(datas , json_dumps_params={'ensure_ascii': False} ,safe=False)
            
            
            
        #     datas = {'warranty_id': tmp_aiWarranty[0]['warrantydealerno']}
        #     tmp_aiWarranty_normal = list(ai_warranty.objects.using('ai').filter(warrantyno = wNumber))
        #     tmp_aiWarranty_online = list(ai_warrantyOnline.objects.using('ai').filter(warrantyno = wNumber))
        #     if len(tmp_aiWarranty_normal) > 0:
        #         datas['state'] = "inAI_normal"
        #     elif len(tmp_aiWarranty_online) > 0:
        #         datas['state'] = "inAI_online"
        #     else:
        #         datas['state'] = "inAI_nonRegister"
        # else: 
        #     datas = {'warranty_id': '',
        #             'state':'notFound',
        #             'regis_state': 'nonRegister'}
        return JsonResponse(datas , json_dumps_params={'ensure_ascii': False} ,safe=False)

    else:
        return JsonResponse(True ,safe=False)
    
    
# @csrf_exempt
# def warrantyNumber_checker_old(request):
#     wNumber = request.POST.get('warranty_number')
#     if  request.method == 'POST':
#     ### Check in ERP:
#         tmp_erpWarranty = list(erp_warranty.objects.filter(number = wNumber).exclude(state='voided').values('id','number','state','cust_name','cust_car_brand_0','cust_car_model_0'))
#     ### Check in AI:
       
#         tmp_aiWarranty = list(ai_warrantyNumber.objects.using('ai').filter(warrantydealerno = wNumber).values('warrantydealerno','invrqsno','warrantydealerstt'))
        
#         if len(tmp_erpWarranty) > 0:
#             datas = {'warranty_id': tmp_erpWarranty[0]['number']}
#             if tmp_erpWarranty[0]['cust_name'] is not None and tmp_erpWarranty[0]['cust_car_brand_0'] is not None and tmp_erpWarranty[0]['cust_car_model_0'] is not None :
#                 datas['state'] = "inERP-registed"
#             elif tmp_erpWarranty[0]['cust_name'] is None and tmp_erpWarranty[0]['cust_car_brand_0'] is None and tmp_erpWarranty[0]['cust_car_model_0'] is None :
#                 datas['state'] = "inERP_nonRegister"
#             else:
#                 datas['state'] = "inERP_uncomplete"
#         elif len(tmp_aiWarranty) > 0:
#             datas = {'warranty_id': tmp_aiWarranty[0]['warrantydealerno']}
#             tmp_aiWarranty_normal = list(ai_warranty.objects.using('ai').filter(warrantyno = wNumber))
#             tmp_aiWarranty_online = list(ai_warrantyOnline.objects.using('ai').filter(warrantyno = wNumber))
#             if len(tmp_aiWarranty_normal) > 0:
#                 datas['state'] = "inAI_normal"
#             elif len(tmp_aiWarranty_online) > 0:
#                 datas['state'] = "inAI_online"
#             else:
#                 datas['state'] = "inAI_nonRegister"
#         else: 
#             datas = {'warranty_id': '',
#                     'state':'notFound',
#                     'regis_state': 'nonRegister'}
#         return JsonResponse(datas , json_dumps_params={'ensure_ascii': False} ,safe=False)

#     else:
#         return JsonResponse(True ,safe=False)
        
    
@csrf_exempt
def get_AI_warrantyData(request):
   
    if  request.method == 'POST':
        wNumber = request.POST.get('warranty_number')

@csrf_exempt
def get_ERP_warrantyData_withNumber(request):
    if  request.method == 'POST':
        wNumber = request.POST.get('warranty_number')
        datas = erp_warranty.objects.filter(number = wNumber).exclude(state='voided').order_by('id').first()
        print (datas)
        if datas:
            container = [{
                'state':'haveDatas',
                'datas':{
                    'id_wrt':datas.id,
                    'number_wrt':datas.number,
                    'cust_name':datas.cust_name,
                    # 'cust_dob':datas.cust_dob,
                    'cust_sex':datas.cust_sex_0,
                    'cust_mail':datas.notes,
                    'cust_phone':datas.cust_phone,
                    'cust_address':datas.cust_address,
                    'cust_province_id':orm_noneChecker(datas.cust_province,'id'),
                    'cust_province_name':orm_noneChecker(datas.cust_province,'name'),
                    'cust_district_id':orm_noneChecker(datas.cust_district,'id'),
                    'cust_district_name':orm_noneChecker(datas.cust_district,'name'),
                    'cust_subdistrict_id':orm_noneChecker(datas.cust_subdistrict,'id'),
                    'cust_subdistrict_name':orm_noneChecker(datas.cust_subdistrict,'name'),
                    'cust_postalcode':datas.cust_postal_code,
                    'cust_carbrand_id':orm_noneChecker(datas.cust_car_brand_0,'id'),
                    'cust_carbrand_name':orm_noneChecker(datas.cust_car_brand_0,'name'),
                    'cust_carmodel_id':orm_noneChecker(datas.cust_car_model_0,'id'),
                    'cust_carmodel_name':orm_noneChecker(datas.cust_car_model_0,'name'),
                    'cust_liceseplateblack':datas.cust_license_plate_bk ,
                    'cust_vin':datas.cust_vin,
                    'showroominstall_id':orm_noneChecker(datas.cust_showroom_0,'id'),
                    'showroominstall_code':orm_noneChecker(datas.cust_showroom_0,'code'),
                    'showroominstall_name_branch':orm_noneChecker(datas.cust_showroom_0,'name')+' '+orm_noneChecker(datas.cust_showroom_0,'branch'),
                    'cust_dateinstall':datas.cust_date,
                    'locationinstall_id':datas.area_film_0.id,
                    'locationinstall_name':datas.area_film_0.name,
                    'another_position':datas.remark,
                    'cust_checknumber':datas.ref,
                    'cust_status':datas.state
                }
            }]
            print (container)
            return JsonResponse(container , json_dumps_params={'ensure_ascii': False} ,safe=False)
    else:
        return JsonResponse(True ,safe=False)
    
@csrf_exempt
def get_warrantyData_withCUSdata(request):
    if request.method =='POST':
        if request.POST.get('searchMethod') == 'withCusName':
            pass
        elif request.POST.get('searchMethod') == 'withWarrntyNumber':
            pass

@csrf_exempt
def get_ERP_warrantyData_withID(request):
    if  request.method == 'POST':
        wID = request.POST.get('id_wrt')
        datas = list(erp_warranty.objects.filter(id = wID).exclude(state='voided'))
        print (datas)
        if datas:
            container = {
                'state':'haveDatas',
                'datas':{
                    'id_wrt':datas[0]['id'],
                    'number_wrt':datas[0]['number'],
                    'cust_name':datas[0]['cust_name'],
                    'cust_dob':datas[0]['cust_dob'],
                    'cust_sex':datas[0]['cust_sex_id'],
                    'cust_mail':datas[0]['notes'],
                    'cust_phone':datas[0]['cust_phone'],
                    'cust_address':datas[0]['cust_address'],
                    'cust_province_id':datas[0]['cust_province_id'],
                    # 'cust_province':datas[0][''],
                    'cust_district_id':datas[0]['cust_district_id'],
                    # 'cust_district':datas[0]['cust_district'],
                    'cust_subdistrict_id':datas[0]['cust_subdistrict_id'],
                    # 'cust_subdistrict':datas[0]['cust_subdistrict'],
                    'cust_postalcode':datas[0]['cust_postal_code'],
                    # 'cust_carbrand':datas[0][''],
                    'cust_carbrand_id':datas[0]['cust_carbrand_id'],
                    # 'cust_carmodel':datas[0]['cust_carmodel'],
                    'cust_carmodel_id':datas[0]['cust_carmodel_id'],
                    # 'cust_carmodel':datas[0]['cust_carmodel'],
                    'cust_liceseplateblack':datas[0]['cust_liceseplateblack'],
                    'cust_vin':datas[0]['cust_vin'],
                    'showroominstall_id':datas[0]['cust_showroom_id'],
                    # 'showroominstall':datas[0][''],
                    'cust_dateinstall':datas[0]['cust_date'],
                    'locationinstall':datas[0]['area_film_id'],
                    'another_position':datas[0]['remark'],
                    'cust_checknumber':datas[0]['ref'],
                    'cust_status':datas[0]['state']
                }
            }
      
            return JsonResponse(container , json_dumps_params={'ensure_ascii': False} ,safe=False)
    else:
        return JsonResponse(True ,safe=False)
