from django.http import JsonResponse
from django.db.models import F, Value
from django.db.models.functions import Concat
from django.shortcuts import render
from django.views.decorators.csrf import csrf_exempt

# from erp_models.ai_models import TbtInvtWarrantydealer as ai_warrantyDealer
# from erp_models.ai_models import TbtInvtWarranty as ai_warranty
# from erp_models.ai_models import TbtInvtWarrantyow as ai_warrantyOnline
# from erp_models.ai_models import TbtInvtInvrqs as ai_gi
# from erp_models.ai_models import TbmLgstCartype as ai_carType
# from erp_models.ai_models import TbmLgstCarbrand as ai_carBrand
# from erp_models.ai_models import TbmLgstCarmodel as ai_carModel
from erp_models.erp_models import Address as erp_address
from erp_models.erp_models import Province as erp_province
from erp_models.erp_models import District as erp_district
from erp_models.erp_models import Subdistrict as erp_subdistrict
from erp_models.erp_models import PostalCode as erp_zipCode
from erp_models.erp_models import CarBrand as erp_carBrand
from erp_models.erp_models import CarModel as erp_carModel

from erp_models.erp_models import Contact as erp_contact
from erp_models.erp_models import Product as erp_product
from erp_models.erp_models import Sex as erp_gender
from erp_get.fn_warrantyChecker import wNumberChecker,warrantyFinder,wFinder_cusName

from erp_models.WOnline_models import WoProductGroup as wo_productGroup
from erp_models.WOnline_models import WoProduct as wo_product
from core.my_config import laminaPage_brand,xtraColePage_brand,glasiaPage_brand


# from erp_models.erp_models import ServiceItem as erp_warranty
# from erp_models.WOnline_models import MatchmakerAiProduct as erp_ai_brandmatch

contactCateg = [29,32]
@csrf_exempt
def province_all (request):
    datas  = list (erp_province.objects.filter(country=1).order_by('name').values('id','name'))
    datas = sorted(datas, key=lambda x: x['name'])
    return JsonResponse(datas , json_dumps_params={'ensure_ascii': False} ,safe=False)

@csrf_exempt
def district_all (request):
    datas  = list (erp_district.objects.values('id','name'))
    datas = sorted(datas, key=lambda x: x['name'])
    return JsonResponse(datas , json_dumps_params={'ensure_ascii': False} ,safe=False)

@csrf_exempt
def district_withProvince (request):
    if  request.method == 'POST':
        province_id = request.POST.get('province_id')
        datas  = list (erp_district.objects.filter(province = province_id).values('id','name'))
        datas = sorted(datas, key=lambda x: x['name'])
        return JsonResponse(datas , json_dumps_params={'ensure_ascii': False} ,safe=False)
    else:
       return JsonResponse(True ,safe=False)
   
@csrf_exempt   
def subdistrict_all (request):
    datas  = list (erp_subdistrict.objects.values('id','name'))
    datas = sorted(datas, key=lambda x: x['name'])
    return JsonResponse(datas , json_dumps_params={'ensure_ascii': False} ,safe=False)

@csrf_exempt
def subdistrict_withProvince (request):
    if  request.method == 'POST':
        district_id = request.POST.get('district_id')
        datas  = list (erp_subdistrict.objects.filter(district = district_id).values('id','name'))
        datas = sorted(datas, key=lambda x: x['name'])
        return JsonResponse(datas , json_dumps_params={'ensure_ascii': False} ,safe=False)
    else:
       return JsonResponse(True ,safe=False)
    
@csrf_exempt
def zipCode_withProvince (request):
    if  request.method == 'POST':
        district_id = request.POST.get('subdistrict_id')
        datas  = list (erp_zipCode.objects.filter(subdistrict = district_id).values('id','code'))
        datas = sorted(datas, key=lambda x: x['code'])
        return JsonResponse(datas , json_dumps_params={'ensure_ascii': False} ,safe=False)
    else:
        return JsonResponse(True ,safe=False)
    
@csrf_exempt
def car_brand (request):
    datas  = list (erp_carBrand.objects.order_by('name').values('id','name'))
    datas = sorted(datas, key=lambda x: x['name'])
    return JsonResponse(datas , json_dumps_params={'ensure_ascii': False} ,safe=False)

@csrf_exempt
def car_model (request):
    datas  = list (erp_carModel.objects.order_by('name').values('id','name'))
    datas = sorted(datas, key=lambda x: x['name'])
    return JsonResponse(datas , json_dumps_params={'ensure_ascii': False} ,safe=False)

@csrf_exempt
def carModel_withCarModel (request):
    if  request.method == 'POST':
        carBrand_id = request.POST.get('carBrand_id')
        datas  = list(erp_carModel.objects.filter(brand=carBrand_id).exclude(code__contains='[CLOSE]').values('id','name'))
        datas = sorted(datas, key=lambda x: x['name'])
        return JsonResponse(datas , json_dumps_params={'ensure_ascii': False} ,safe=False)
    else:
        return JsonResponse(True ,safe=False)

@csrf_exempt
def customerContact (request):
    datas  = list (erp_contact.objects.filter(active=True,customer=True,categ__in=[29, 31, 32]).annotate(name_branch=Concat(F('name'), Value(''), F('branch'))).values('id','name_branch'))
    datas = sorted(datas, key=lambda x: x['name_branch'])
    return JsonResponse(datas , json_dumps_params={'ensure_ascii': False} ,safe=False)

@csrf_exempt
def customerContact_withProvince (request):
    if  request.method == 'POST':
        province_id = request.POST.get('province_id')
        datas  = list (erp_contact.objects.filter(active=True,customer=True, address__type='shipping',categ__in=[29, 31, 98, 32, 34, 97],address__province_0=province_id).annotate(name_branch=Concat( F('name'),  Value(''), F('branch'))).values('id','name_branch'))
        datas = sorted(datas, key=lambda x: x['name_branch'])
        return JsonResponse(datas , json_dumps_params={'ensure_ascii': False} ,safe=False)
    else:
        return JsonResponse(True ,safe=False)
    
@csrf_exempt
def productLamina (request):
    datas  = list (erp_product.objects.filter(active=True,type='stock',brand__in=laminaPage_brand).values('id','code','name'))
    datas = sorted(datas, key=lambda x: x['code'])
    return JsonResponse(datas , json_dumps_params={'ensure_ascii': False} ,safe=False)

    
@csrf_exempt
def productXtraCole (request):

    datas  = list (erp_product.objects.filter(active=True,type='stock',brand__in=xtraColePage_brand).values('id','code','name'))
    datas = sorted(datas, key=lambda x: x['code'])
    return JsonResponse(datas , json_dumps_params={'ensure_ascii': False} ,safe=False)

@csrf_exempt
def productGlasia (request):
    datas  = list (erp_product.objects.filter(active=True,type='stock',brand__in=glasiaPage_brand).values('id','code','name'))
    datas = sorted(datas, key=lambda x: x['code'])
    return JsonResponse(datas , json_dumps_params={'ensure_ascii': False} ,safe=False)


@csrf_exempt
def productGroup (request):
    if request.method == 'POST':
        brand = request.POST.get('brand')
        b =wo_productGroup.objects.using('WOnline').filter(active=True,brand=brand).values('id','name')
        print(b.query)
        datas  = list (wo_productGroup.objects.using('WOnline').filter(active=True,brand=brand).values('id','name'))
        datas = sorted(datas, key=lambda x: x['name'])
        return JsonResponse(datas , json_dumps_params={'ensure_ascii': False} ,safe=False)

@csrf_exempt
def productWithGroup (request):
    if request.method == 'POST':
        productGroup = request.POST.get('group')
        list_productId = list(wo_product.objects.using('WOnline').filter(active=True,group__name=productGroup).values('erp_id'))
        productIDs = [pID['erp_id'] for pID in list_productId]
        
        # group_id = list(erp_ai_productGroup.objects.filter(active=True,name__in=productGroup).values('id','name'))
        # if len(group_id) > 0 : 
            # list_productId  = 
            
        datas  = list (erp_product.objects.filter(active=True,type='stock',id__in=productIDs).values('id','code','name'))
        datas = sorted(datas, key=lambda x: x['code'])
        return JsonResponse(datas , json_dumps_params={'ensure_ascii': False} ,safe=False)
    # return 



@csrf_exempt
def gender (request):
    datas  = list (erp_gender.objects.order_by('name').values('id','name'))
    datas = sorted(datas, key=lambda x: x['name'])
    return JsonResponse(datas , json_dumps_params={'ensure_ascii': False} ,safe=False)

@csrf_exempt
def warrantyNumber_checker(request):
    if request.method == 'POST':
        datas = wNumberChecker(request.POST.get('number_wrt'),request.POST.get('brand_wrt'))
    
        return JsonResponse(datas , json_dumps_params={'ensure_ascii': False} ,safe=False)

    else:
        datas = {   'state':'notFound',#'found/notFound',
                    'sys_db':'',#'erp/ai',
                    'register':'',#'registed/unRegisted',
                    'brand_wrt':request.POST.get('brand_wrt'),#'lamina/xtra-cole/glasia',
                    'number_wrt':request.POST.get('number_wrt')
        }
        return JsonResponse(datas ,json_dumps_params={'ensure_ascii': False} ,safe=False)

@csrf_exempt
def warrantyNumber_Finder(request):
    if request.method == 'POST':
        find_method = request.POST.get('find_method')
        # pageBrand = request.POST.get('brand_wrt')
        # if pageBrand in 
        
        if find_method == 'wNum':
            # fn_warrantyFinder = warrantyFinder(request.POST.get('brand_wrt'))
            # fn_warrantyFinder.wFinder_cusName(request)
            tmp_datas = wNumberChecker(request.POST.get('number_wrt'),request.POST.get('brand_wrt'))
            datas = {
                    'state':tmp_datas['state'],
                    'brand':tmp_datas['brand'],
                    'w_data':[{'number_wrt':tmp_datas['number_wrt'],
                            'brand_wrt':tmp_datas['brand'],
                            'sys_db':tmp_datas['sys_db'],
                            'cust_name':tmp_datas['w_data']['cust_name'],
                            'cust_install_date':tmp_datas['w_data']['cust_install_date'],
                            'cust_carbrand':tmp_datas['w_data']['cust_carbrand'],
                            'cust_carmodel':tmp_datas['w_data']['cust_carmodel']}]
                 }
            # print (datas)
            pass
        elif find_method == 'cust':
            datas = wFinder_cusName(request)
            # datas = fn_warrantyFinder = warrantyFinder(request)
            # fn_warrantyFinder.wFinder_cusName(request)
            pass
        else:
            datas = {
                'state':'notFound',#'found/notFound',
                'sys_db':'',#'erp/ai',
                'register':'',#'registed/unRegisted',
                'brand':request.POST.get('brand_wrt'),#'lamina/xtra-cole/glasia',
                'number_wrt':request.POST.get('numer_wrt'),
                'w_data':{}
                
            }
            pass
        
        # datas = wNumberChecker(request.POST.get('number_wrt'),request.POST.get('brand_wrt'))
    
        return JsonResponse(datas , json_dumps_params={'ensure_ascii': False} ,safe=False)

    else:
        datas = {   'state':'notFound',#'found/notFound',
                    'sys_db':'',#'erp/ai',
                    'register':'',#'registed/unRegisted',
                    'brand_wrt':request.POST.get('brand_wrt'),#'lamina/xtra-cole/glasia',
                    'number_wrt':request.POST.get('number_wrt')
        }
        return JsonResponse(datas ,json_dumps_params={'ensure_ascii': False} ,safe=False)
   
@csrf_exempt
def get_AI_warrantyData(request):
   
    if  request.method == 'POST':
        wNumber = request.POST.get('number_wrt')

# @csrf_exempt
# def get_ERP_warrantyData_withNumber(request):
#     if  request.method == 'POST':
#         wNumber = request.POST.get('warranty_number')
#         datas = erp_warranty.objects.filter(number = wNumber).exclude(state='voided').order_by('id').first()
#         print (datas)
#         if datas:
#             container = [{
#                 'state':'haveDatas',
#                 'datas':{
#                     'id_wrt':datas.id,
#                     'number_wrt':datas.number,
#                     'cust_name':datas.cust_name,
#                     # 'cust_dob':datas.cust_dob,
#                     'cust_sex':datas.cust_sex_0,
#                     'cust_mail':datas.notes,
#                     'cust_phone':datas.cust_phone,
#                     'cust_address':datas.cust_address,
#                     'cust_province_id':orm_noneChecker(datas.cust_province,'id'),
#                     'cust_province_name':orm_noneChecker(datas.cust_province,'name'),
#                     'cust_district_id':orm_noneChecker(datas.cust_district,'id'),
#                     'cust_district_name':orm_noneChecker(datas.cust_district,'name'),
#                     'cust_subdistrict_id':orm_noneChecker(datas.cust_subdistrict,'id'),
#                     'cust_subdistrict_name':orm_noneChecker(datas.cust_subdistrict,'name'),
#                     'cust_postalcode':datas.cust_postal_code,
#                     'cust_carbrand_id':orm_noneChecker(datas.cust_car_brand_0,'id'),
#                     'cust_carbrand_name':orm_noneChecker(datas.cust_car_brand_0,'name'),
#                     'cust_carmodel_id':orm_noneChecker(datas.cust_car_model_0,'id'),
#                     'cust_carmodel_name':orm_noneChecker(datas.cust_car_model_0,'name'),
#                     'cust_liceseplateblack':datas.cust_license_plate_bk ,
#                     'cust_vin':datas.cust_vin,
#                     'showroominstall_id':orm_noneChecker(datas.cust_showroom_0,'id'),
#                     'showroominstall_code':orm_noneChecker(datas.cust_showroom_0,'code'),
#                     'showroominstall_name_branch':orm_noneChecker(datas.cust_showroom_0,'name')+' '+orm_noneChecker(datas.cust_showroom_0,'branch'),
#                     'cust_dateinstall':datas.cust_date,
#                     'locationinstall_id':datas.area_film_0.id,
#                     'locationinstall_name':datas.area_film_0.name,
#                     'another_position':datas.remark,
#                     'cust_checknumber':datas.ref,
#                     'cust_status':datas.state
#                 }
#             }]
#             print (container)
#             return JsonResponse(container , json_dumps_params={'ensure_ascii': False} ,safe=False)
#     else:
#         return JsonResponse(True ,safe=False)
    
@csrf_exempt
def get_warrantyData_withCUSdata(request):
    if request.method =='POST':
        if request.POST.get('searchMethod') == 'withCusName':
            pass
        elif request.POST.get('searchMethod') == 'withWarrntyNumber':
            pass

# @csrf_exempt
# def get_ERP_warrantyData_withID(request):
#     if  request.method == 'POST':
#         wID = request.POST.get('id_wrt')
#         datas = list(erp_warranty.objects.filter(id = wID).exclude(state='voided'))
#         print (datas)
#         if datas:
#             container = {
#                 'state':'haveDatas',
#                 'datas':{
#                     'id_wrt':datas[0]['id'],
#                     'number_wrt':datas[0]['number'],
#                     'cust_name':datas[0]['cust_name'],
#                     'cust_dob':datas[0]['cust_dob'],
#                     'cust_sex':datas[0]['cust_sex_id'],
#                     'cust_mail':datas[0]['notes'],
#                     'cust_phone':datas[0]['cust_phone'],
#                     'cust_address':datas[0]['cust_address'],
#                     'cust_province_id':datas[0]['cust_province_id'],
#                     # 'cust_province':datas[0][''],
#                     'cust_district_id':datas[0]['cust_district_id'],
#                     # 'cust_district':datas[0]['cust_district'],
#                     'cust_subdistrict_id':datas[0]['cust_subdistrict_id'],
#                     # 'cust_subdistrict':datas[0]['cust_subdistrict'],
#                     'cust_postalcode':datas[0]['cust_postal_code'],
#                     # 'cust_carbrand':datas[0][''],
#                     'cust_carbrand_id':datas[0]['cust_carbrand_id'],
#                     # 'cust_carmodel':datas[0]['cust_carmodel'],
#                     'cust_carmodel_id':datas[0]['cust_carmodel_id'],
#                     # 'cust_carmodel':datas[0]['cust_carmodel'],
#                     'cust_liceseplateblack':datas[0]['cust_liceseplateblack'],
#                     'cust_vin':datas[0]['cust_vin'],
#                     'showroominstall_id':datas[0]['cust_showroom_id'],
#                     # 'showroominstall':datas[0][''],
#                     'cust_dateinstall':datas[0]['cust_date'],
#                     'locationinstall':datas[0]['area_film_id'],
#                     'another_position':datas[0]['remark'],
#                     'cust_checknumber':datas[0]['ref'],
#                     'cust_status':datas[0]['state']
#                 }
#             }
      
#             return JsonResponse(container , json_dumps_params={'ensure_ascii': False} ,safe=False)
#     else:
#         return JsonResponse(True ,safe=False)

@csrf_exempt
def test (request):

    datas_t  = list(erp_product.objects.filter(active=True,type='stock',brand__in=glasiaPage_brand).values('id'))
    # product
    datas = list(datas_t)
    return JsonResponse(datas ,json_dumps_params={'ensure_ascii': False} ,safe=False)