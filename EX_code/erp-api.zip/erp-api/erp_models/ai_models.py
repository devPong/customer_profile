# This is an auto-generated Django model module.
# You'll have to do the following manually to clean this up:
#   * Rearrange models' order
#   * Make sure each model has one field with primary_key=True
#   * Make sure each ForeignKey and OneToOneField has `on_delete` set to the desired behavior
#   * Remove `managed = False` lines if you wish to allow Django to create, modify, and delete the table
# Feel free to rename the models, but don't rename db_table values or field names.
from django.db import models


class AddrType(models.Model):
    tumbon1 = models.CharField(max_length=30, blank=True, null=True)
    tumbon2 = models.CharField(max_length=30, blank=True, null=True)
    ampher1 = models.CharField(max_length=30, blank=True, null=True)
    ampher2 = models.CharField(max_length=30, blank=True, null=True)
    province = models.CharField(max_length=30, blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'addr_type'


class TbmAmphur(models.Model):
    amphur_id = models.AutoField(primary_key=True)
    amphur_code = models.CharField(max_length=4)
    amphur_name = models.CharField(max_length=150)
    province_id = models.IntegerField()

    class Meta:
        managed = False
        db_table = 'tbm_amphur'


class TbmDistrict(models.Model):
    district_id = models.AutoField(primary_key=True)
    district_code = models.CharField(max_length=6)
    district_name = models.CharField(max_length=150)
    amphur_id = models.IntegerField()
    province_id = models.IntegerField()

    class Meta:
        managed = False
        db_table = 'tbm_district'


class TbmInvtItem(models.Model):
    plantcd = models.CharField(max_length=20)
    itemcd = models.CharField(max_length=20)
    itemnm = models.CharField(max_length=255, blank=True, null=True)
    itemnm2 = models.CharField(max_length=255, blank=True, null=True)
    size = models.DecimalField(max_digits=13, decimal_places=5, blank=True, null=True)  # max_digits and decimal_places have been guessed, as this database handles decimal fields as float
    dimension_width = models.IntegerField()
    dimension_long = models.IntegerField()
    metric_width = models.DecimalField(max_digits=10, decimal_places=2)
    metric_long = models.DecimalField(max_digits=10, decimal_places=2)
    uomcd = models.CharField(max_length=20, blank=True, null=True)
    itemcdext = models.CharField(max_length=100)
    itemcdint = models.CharField(max_length=100, blank=True, null=True)
    filmcd = models.CharField(max_length=100, blank=True, null=True)
    itemsttcd = models.CharField(max_length=1)
    itemrmk = models.TextField(blank=True, null=True)
    addempcd = models.CharField(max_length=50, blank=True, null=True)
    addpcnm = models.CharField(max_length=50, blank=True, null=True)
    adddt = models.DateTimeField(blank=True, null=True)
    updempcd = models.CharField(max_length=50, blank=True, null=True)
    updpcnm = models.CharField(max_length=50, blank=True, null=True)
    upddt = models.DateTimeField(blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'tbm_invt_item'
        unique_together = (('plantcd', 'itemcd', 'itemcdext'),)


class TbmInvtItemTmp(models.Model):
    plantcd = models.CharField(max_length=20)
    itemcd = models.CharField(max_length=20)
    itemnm = models.CharField(max_length=255, blank=True, null=True)
    itemnm2 = models.CharField(max_length=255, blank=True, null=True)
    size = models.DecimalField(max_digits=13, decimal_places=5, blank=True, null=True)  # max_digits and decimal_places have been guessed, as this database handles decimal fields as float
    dimension_width = models.IntegerField()
    dimension_long = models.IntegerField()
    metric_width = models.DecimalField(max_digits=10, decimal_places=2)
    metric_long = models.DecimalField(max_digits=10, decimal_places=2)
    uomcd = models.CharField(max_length=20, blank=True, null=True)
    itemcdext = models.CharField(max_length=100)
    itemcdint = models.CharField(max_length=100, blank=True, null=True)
    filmcd = models.CharField(max_length=100, blank=True, null=True)
    itemsttcd = models.CharField(max_length=1)
    itemrmk = models.TextField(blank=True, null=True)
    addempcd = models.CharField(max_length=50, blank=True, null=True)
    addpcnm = models.CharField(max_length=50, blank=True, null=True)
    adddt = models.DateTimeField(blank=True, null=True)
    updempcd = models.CharField(max_length=50, blank=True, null=True)
    updpcnm = models.CharField(max_length=50, blank=True, null=True)
    upddt = models.DateTimeField(blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'tbm_invt_item_tmp'


class TbmInvtItemext(models.Model):
    itemextcd = models.CharField(primary_key=True, max_length=100, db_collation='tis620_thai_ci')
    itemextnm = models.CharField(max_length=200, db_collation='tis620_thai_ci', blank=True, null=True)
    itemextstt = models.CharField(max_length=1, db_collation='tis620_thai_ci')
    size = models.DecimalField(max_digits=13, decimal_places=5)  # max_digits and decimal_places have been guessed, as this database handles decimal fields as float
    dimension_width = models.IntegerField()
    dimension_long = models.IntegerField()
    metric_width = models.DecimalField(max_digits=10, decimal_places=2)
    metric_long = models.DecimalField(max_digits=10, decimal_places=2)
    addempcd = models.CharField(max_length=50, db_collation='tis620_thai_ci', blank=True, null=True)
    addpcnm = models.CharField(max_length=200, db_collation='tis620_thai_ci', blank=True, null=True)
    adddt = models.DateTimeField(blank=True, null=True)
    updempcd = models.CharField(max_length=50, db_collation='tis620_thai_ci', blank=True, null=True)
    updpcnm = models.CharField(max_length=200, db_collation='tis620_thai_ci', blank=True, null=True)
    upddt = models.DateTimeField(blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'tbm_invt_itemext'


class TbmInvtItemint(models.Model):
    itemintcd = models.CharField(primary_key=True, max_length=100, db_collation='tis620_thai_ci')
    itemintnm = models.CharField(max_length=200, db_collation='tis620_thai_ci', blank=True, null=True)
    itemintstt = models.CharField(max_length=1, db_collation='tis620_thai_ci')
    itemonlinestt = models.CharField(max_length=1, blank=True, null=True)
    year_warranty = models.FloatField(blank=True, null=True)
    addempcd = models.CharField(max_length=50, db_collation='tis620_thai_ci', blank=True, null=True)
    addpcnm = models.CharField(max_length=200, db_collation='tis620_thai_ci', blank=True, null=True)
    adddt = models.DateTimeField(blank=True, null=True)
    updempcd = models.CharField(max_length=50, db_collation='tis620_thai_ci', blank=True, null=True)
    updpcnm = models.CharField(max_length=200, db_collation='tis620_thai_ci', blank=True, null=True)
    upddt = models.DateTimeField(blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'tbm_invt_itemint'


class TbmInvtItempair(models.Model):
    itemextcd = models.CharField(max_length=100, db_collation='tis620_thai_ci')
    itemintcd = models.CharField(max_length=100, db_collation='tis620_thai_ci')
    itemcd = models.CharField(max_length=100, db_collation='tis620_thai_ci')
    filmcd = models.CharField(max_length=100, db_collation='tis620_thai_ci', blank=True, null=True)
    addempcd = models.CharField(max_length=50, db_collation='tis620_thai_ci', blank=True, null=True)
    addpcnm = models.CharField(max_length=200, db_collation='tis620_thai_ci', blank=True, null=True)
    adddt = models.DateTimeField(blank=True, null=True)
    updempcd = models.CharField(max_length=50, db_collation='tis620_thai_ci', blank=True, null=True)
    updpcnm = models.CharField(max_length=200, db_collation='tis620_thai_ci', blank=True, null=True)
    upddt = models.DateTimeField(blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'tbm_invt_itempair'
        unique_together = (('itemextcd', 'itemintcd', 'itemcd'),)


class TbmInvtLoc(models.Model):
    plantcd = models.CharField(max_length=20)
    whcd = models.CharField(max_length=20)
    loccd = models.CharField(max_length=20)
    locnm = models.CharField(max_length=255, blank=True, null=True)
    loctpcd = models.CharField(max_length=20, blank=True, null=True)
    locstt = models.CharField(max_length=1)
    addempcd = models.CharField(max_length=50, blank=True, null=True)
    addpcnm = models.CharField(max_length=50, blank=True, null=True)
    adddt = models.DateTimeField(blank=True, null=True)
    updempcd = models.CharField(max_length=50, blank=True, null=True)
    updpcnm = models.CharField(max_length=50, blank=True, null=True)
    upddt = models.DateTimeField(blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'tbm_invt_loc'
        unique_together = (('plantcd', 'whcd', 'loccd'),)


class TbmInvtProduct(models.Model):
    productnm = models.CharField(max_length=256, blank=True, null=True)
    productgp = models.CharField(max_length=100, blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'tbm_invt_product'


class TbmInvtPromotion(models.Model):
    id = models.IntegerField(primary_key=True)
    promotionnm = models.CharField(max_length=200, blank=True, null=True)
    promotionstt = models.CharField(max_length=1, blank=True, null=True)
    effectdt = models.DateField(blank=True, null=True)
    expiredt = models.DateField(blank=True, null=True)
    addempcd = models.CharField(max_length=50, db_collation='tis620_thai_ci', blank=True, null=True)
    addpcnm = models.CharField(max_length=50, db_collation='tis620_thai_ci', blank=True, null=True)
    adddt = models.DateTimeField(blank=True, null=True)
    updempcd = models.CharField(max_length=50, db_collation='tis620_thai_ci', blank=True, null=True)
    updpcnm = models.CharField(max_length=50, db_collation='tis620_thai_ci', blank=True, null=True)
    upddt = models.DateTimeField(blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'tbm_invt_promotion'


class TbmInvtUom(models.Model):
    uomcd = models.CharField(primary_key=True, max_length=20)
    uomnm = models.CharField(max_length=255, blank=True, null=True)
    addempcd = models.CharField(max_length=50, blank=True, null=True)
    addpcnm = models.CharField(max_length=50, blank=True, null=True)
    adddt = models.DateTimeField(blank=True, null=True)
    updempcd = models.CharField(max_length=50, blank=True, null=True)
    updpcnm = models.CharField(max_length=50, blank=True, null=True)
    upddt = models.DateTimeField(blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'tbm_invt_uom'


class TbmInvtWarrantybook(models.Model):
    warrantybookprefix = models.CharField(primary_key=True, max_length=100)
    refno = models.CharField(max_length=255, blank=True, null=True)
    plantcd = models.CharField(max_length=50)
    empcd = models.CharField(max_length=50)
    inuse = models.CharField(max_length=1)
    addempcd = models.CharField(max_length=100, blank=True, null=True)
    addpcnm = models.CharField(max_length=100, blank=True, null=True)
    adddt = models.DateField(blank=True, null=True)
    updempcd = models.CharField(max_length=100, blank=True, null=True)
    updpcnm = models.CharField(max_length=100, blank=True, null=True)
    upddt = models.DateField(blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'tbm_invt_warrantybook'


class TbmInvtWh(models.Model):
    plantcd = models.CharField(max_length=20)
    whcd = models.CharField(max_length=20)
    whnm = models.CharField(max_length=255, blank=True, null=True)
    whtpcd = models.CharField(max_length=20, blank=True, null=True)
    whstt = models.CharField(max_length=1)
    addempcd = models.CharField(max_length=50, blank=True, null=True)
    addpcnm = models.CharField(max_length=50, blank=True, null=True)
    adddt = models.DateTimeField(blank=True, null=True)
    updempcd = models.CharField(max_length=50, blank=True, null=True)
    updpcnm = models.CharField(max_length=50, blank=True, null=True)
    upddt = models.DateTimeField(blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'tbm_invt_wh'
        unique_together = (('plantcd', 'whcd'),)


class TbmLgstCarbrand(models.Model):
    carbrandid = models.AutoField(primary_key=True)
    carbrandcd = models.CharField(max_length=50, blank=True, null=True)
    carbrandnm = models.CharField(max_length=50, blank=True, null=True)
    carbrandstt = models.CharField(max_length=1)
    cartypeid = models.IntegerField(blank=True, null=True)
    addempcd = models.CharField(max_length=50, blank=True, null=True)
    addpcnm = models.CharField(max_length=50, blank=True, null=True)
    adddt = models.DateField(blank=True, null=True)
    updempcd = models.CharField(max_length=50, blank=True, null=True)
    updpcnm = models.CharField(max_length=50, blank=True, null=True)
    upddt = models.DateField(blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'tbm_lgst_carbrand'


class TbmLgstCarmodel(models.Model):
    carmodelid = models.AutoField(primary_key=True)
    carmodelcd = models.CharField(max_length=50, blank=True, null=True)
    carmodelnm = models.CharField(max_length=50, blank=True, null=True)
    carmodelstt = models.CharField(max_length=1)
    carbrandid = models.IntegerField(blank=True, null=True)
    cartypeid = models.IntegerField(blank=True, null=True)
    onlinestt = models.CharField(max_length=1, blank=True, null=True)
    carmodelnm_en = models.CharField(max_length=50, blank=True, null=True)
    addempcd = models.CharField(max_length=50, blank=True, null=True)
    addpcnm = models.CharField(max_length=50, blank=True, null=True)
    adddt = models.DateField(blank=True, null=True)
    updempcd = models.CharField(max_length=50, blank=True, null=True)
    updpcnm = models.CharField(max_length=50, blank=True, null=True)
    upddt = models.DateField(blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'tbm_lgst_carmodel'


class TbmLgstCartype(models.Model):
    cartypeid = models.AutoField(primary_key=True)
    cartypecd = models.CharField(max_length=20, blank=True, null=True)
    cartypenm = models.CharField(max_length=255, blank=True, null=True)
    orderno = models.IntegerField(blank=True, null=True)
    cartypestt = models.CharField(max_length=1)
    addempcd = models.CharField(max_length=50, blank=True, null=True)
    addpcnm = models.CharField(max_length=50, blank=True, null=True)
    adddt = models.DateField(blank=True, null=True)
    updempcd = models.CharField(max_length=50, blank=True, null=True)
    updpcnm = models.CharField(max_length=50, blank=True, null=True)
    upddt = models.DateField(blank=True, null=True)
    warrantystt = models.CharField(max_length=1, blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'tbm_lgst_cartype'


class TbmPostcode(models.Model):
    district_id = models.PositiveIntegerField()
    post_code = models.PositiveIntegerField()

    class Meta:
        managed = False
        db_table = 'tbm_postcode'


class TbmProcSup(models.Model):
    supcd = models.CharField(primary_key=True, max_length=20)
    supnm = models.CharField(max_length=255, blank=True, null=True)
    supaddr = models.CharField(max_length=255, blank=True, null=True)
    supstatus = models.CharField(max_length=1, blank=True, null=True)
    suptpcd = models.CharField(max_length=20, blank=True, null=True)
    crcycd = models.CharField(max_length=20, blank=True, null=True)
    excrtstt = models.CharField(max_length=1, blank=True, null=True)
    taxcd = models.CharField(max_length=20, blank=True, null=True)
    posupaddrcd = models.CharField(max_length=20, blank=True, null=True)
    shiploccd = models.CharField(max_length=20, blank=True, null=True)
    paytermcd = models.CharField(max_length=20, blank=True, null=True)
    paymethcd = models.CharField(max_length=20, blank=True, null=True)
    empcd = models.CharField(max_length=20, blank=True, null=True)
    apacctcd = models.CharField(max_length=20, blank=True, null=True)
    puracctcd = models.CharField(max_length=20, blank=True, null=True)
    addempcd = models.CharField(max_length=50, blank=True, null=True)
    addpcnm = models.CharField(max_length=50, blank=True, null=True)
    adddt = models.DateTimeField(blank=True, null=True)
    updempcd = models.CharField(max_length=50, blank=True, null=True)
    updpcnm = models.CharField(max_length=50, blank=True, null=True)
    upddt = models.DateTimeField(blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'tbm_proc_sup'


class TbmProcSupitem(models.Model):
    itemcd = models.CharField(max_length=20)
    supcd = models.CharField(max_length=20)
    supitemnm = models.CharField(max_length=255)
    supuomcd = models.CharField(max_length=20)
    supleadtm = models.IntegerField(blank=True, null=True)
    supquotedt = models.DateField(blank=True, null=True)
    supquoteqty = models.DecimalField(max_digits=10, decimal_places=5, blank=True, null=True)  # max_digits and decimal_places have been guessed, as this database handles decimal fields as float
    supunitprc = models.DecimalField(max_digits=10, decimal_places=5, blank=True, null=True)  # max_digits and decimal_places have been guessed, as this database handles decimal fields as float
    prclistcd = models.CharField(max_length=20, blank=True, null=True)
    mfger = models.CharField(max_length=50, blank=True, null=True)
    mfgitemnm = models.CharField(max_length=50, blank=True, null=True)
    remark = models.CharField(max_length=255, blank=True, null=True)
    addempcd = models.CharField(max_length=50, blank=True, null=True)
    addpcnm = models.CharField(max_length=50, blank=True, null=True)
    adddt = models.DateField(blank=True, null=True)
    updempcd = models.CharField(max_length=50, blank=True, null=True)
    updtpcnm = models.CharField(max_length=50, blank=True, null=True)
    upddt = models.DateField(blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'tbm_proc_supitem'
        unique_together = (('itemcd', 'supcd'),)


class TbmProvince(models.Model):
    province_id = models.AutoField(primary_key=True)
    province_code = models.CharField(max_length=2)
    province_name = models.CharField(max_length=150)

    class Meta:
        managed = False
        db_table = 'tbm_province'


class TbmSaleCus(models.Model):
    cuscd = models.CharField(primary_key=True, max_length=20)
    cusnm = models.CharField(max_length=255, blank=True, null=True)
    cusstatus = models.CharField(max_length=1, blank=True, null=True)
    cusaddr1 = models.CharField(max_length=255, blank=True, null=True)
    cusaddr2 = models.CharField(max_length=255, blank=True, null=True)
    custpcd = models.CharField(max_length=20, blank=True, null=True)
    crcycd = models.CharField(max_length=20, blank=True, null=True)
    excrtstt = models.CharField(max_length=1, blank=True, null=True)
    taxcd = models.CharField(max_length=20, blank=True, null=True)
    socusaddrcd = models.CharField(max_length=20, blank=True, null=True)
    paytermcd = models.CharField(max_length=20, blank=True, null=True)
    paymethcd = models.CharField(max_length=20, blank=True, null=True)
    empcd = models.CharField(max_length=20, blank=True, null=True)
    aracctcd = models.CharField(max_length=20, blank=True, null=True)
    salesacctcd = models.CharField(max_length=20, blank=True, null=True)
    taxid = models.CharField(max_length=20, blank=True, null=True)
    shiptermcd = models.CharField(max_length=20, blank=True, null=True)
    trnscd = models.CharField(max_length=20, blank=True, null=True)
    addempcd = models.CharField(max_length=50, blank=True, null=True)
    addpcnm = models.CharField(max_length=50, blank=True, null=True)
    adddt = models.DateTimeField(blank=True, null=True)
    updempcd = models.CharField(max_length=50, blank=True, null=True)
    updpcnm = models.CharField(max_length=50, blank=True, null=True)
    upddt = models.DateTimeField(blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'tbm_sale_cus'


class TbmSaleDealer(models.Model):
    dealercd = models.AutoField(primary_key=True)
    dealernm = models.CharField(max_length=255, blank=True, null=True)
    dealerstatus = models.CharField(max_length=1, blank=True, null=True)
    dealertpcd = models.CharField(max_length=20, blank=True, null=True)
    dealeraddr1 = models.CharField(max_length=255, blank=True, null=True)
    dealeraddr2 = models.CharField(max_length=255, blank=True, null=True)
    ampher = models.CharField(max_length=200, blank=True, null=True)
    province = models.CharField(max_length=200, blank=True, null=True)
    postcode = models.CharField(max_length=20, blank=True, null=True)
    tel = models.CharField(max_length=50, blank=True, null=True)
    salecd = models.CharField(max_length=100, blank=True, null=True)
    addempcd = models.CharField(max_length=50, blank=True, null=True)
    addpcnm = models.CharField(max_length=50, blank=True, null=True)
    adddt = models.DateTimeField(blank=True, null=True)
    updempcd = models.CharField(max_length=50, blank=True, null=True)
    updpcnm = models.CharField(max_length=50, blank=True, null=True)
    upddt = models.DateTimeField(blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'tbm_sale_dealer'


class TbmSaleDealershowroom(models.Model):
    dealershowroomcd = models.AutoField(primary_key=True)
    dealercd = models.IntegerField(blank=True, null=True)
    salecd = models.CharField(max_length=50, blank=True, null=True)
    dealershowroomnm = models.CharField(max_length=255, blank=True, null=True)
    dealershowroomtpcd = models.CharField(max_length=1, db_collation='tis620_thai_ci', blank=True, null=True)
    dealershowroomstt = models.CharField(max_length=1, blank=True, null=True)
    addempcd = models.CharField(max_length=50, blank=True, null=True)
    addpcnm = models.CharField(max_length=50, blank=True, null=True)
    adddt = models.DateField(blank=True, null=True)
    updempcd = models.CharField(max_length=50, blank=True, null=True)
    updpcnm = models.CharField(max_length=50, blank=True, null=True)
    upddt = models.DateField(blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'tbm_sale_dealershowroom'


class TbmSaleDealershowroomTemp(models.Model):
    dealershowroomcd = models.CharField(primary_key=True, max_length=50)
    dealershowroomnm = models.CharField(max_length=255, blank=True, null=True)
    dealershowroomtpcd = models.CharField(max_length=1, blank=True, null=True)
    dealershowroomstt = models.CharField(max_length=1, blank=True, null=True)
    addempcd = models.CharField(max_length=50, blank=True, null=True)
    addpcnm = models.CharField(max_length=50, blank=True, null=True)
    adddt = models.DateField(blank=True, null=True)
    updempcd = models.CharField(max_length=50, blank=True, null=True)
    updpcnm = models.CharField(max_length=50, blank=True, null=True)
    upddt = models.DateField(blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'tbm_sale_dealershowroom_temp'


class TbmSystConfig(models.Model):
    warrantyurl = models.CharField(max_length=50, blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'tbm_syst_config'


class TbmSystEmp(models.Model):
    plantcd = models.CharField(max_length=10)
    empcd = models.CharField(max_length=20)
    empnm = models.CharField(max_length=50)
    password = models.CharField(max_length=20)
    empemail = models.CharField(max_length=100, blank=True, null=True)
    rolecd = models.CharField(max_length=20, blank=True, null=True)
    empstt = models.CharField(max_length=1, blank=True, null=True)
    addempcd = models.CharField(max_length=10, blank=True, null=True)
    addpcnm = models.CharField(max_length=20, blank=True, null=True)
    adddt = models.DateTimeField(blank=True, null=True)
    updempcd = models.CharField(max_length=10, blank=True, null=True)
    updpcnm = models.CharField(max_length=20, blank=True, null=True)
    upddt = models.DateTimeField(blank=True, null=True)
    field1 = models.CharField(max_length=100, blank=True, null=True)
    field2 = models.CharField(max_length=100, blank=True, null=True)
    field3 = models.CharField(max_length=100, blank=True, null=True)
    field4 = models.CharField(max_length=100, blank=True, null=True)
    field5 = models.CharField(max_length=100, blank=True, null=True)
    field6 = models.CharField(max_length=100, blank=True, null=True)
    field7 = models.CharField(max_length=100, blank=True, null=True)
    field8 = models.CharField(max_length=100, blank=True, null=True)
    field9 = models.CharField(max_length=100, blank=True, null=True)
    field10 = models.CharField(max_length=100, blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'tbm_syst_emp'
        unique_together = (('plantcd', 'empcd'),)


class TbmSystForm(models.Model):
    formcd = models.CharField(primary_key=True, max_length=50)
    formnm = models.CharField(max_length=50)
    formstt = models.CharField(max_length=1, blank=True, null=True)
    addempcd = models.CharField(max_length=10, blank=True, null=True)
    addpcnm = models.CharField(max_length=20, blank=True, null=True)
    adddt = models.DateTimeField(blank=True, null=True)
    updempcd = models.CharField(max_length=10, blank=True, null=True)
    updpcnm = models.CharField(max_length=20, blank=True, null=True)
    upddt = models.DateTimeField(blank=True, null=True)
    field1 = models.CharField(max_length=100, blank=True, null=True)
    field2 = models.CharField(max_length=100, blank=True, null=True)
    field3 = models.CharField(max_length=100, blank=True, null=True)
    field4 = models.CharField(max_length=100, blank=True, null=True)
    field5 = models.CharField(max_length=100, blank=True, null=True)
    field6 = models.CharField(max_length=100, blank=True, null=True)
    field7 = models.CharField(max_length=100, blank=True, null=True)
    field8 = models.CharField(max_length=100, blank=True, null=True)
    field9 = models.CharField(max_length=100, blank=True, null=True)
    field10 = models.CharField(max_length=100, blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'tbm_syst_form'


class TbmSystOrdno(models.Model):
    ordnocd = models.CharField(primary_key=True, max_length=10)
    ordnonm = models.CharField(max_length=100, blank=True, null=True)
    prefix = models.CharField(max_length=10, blank=True, null=True)
    suffix = models.CharField(max_length=10, blank=True, null=True)
    digit = models.IntegerField(blank=True, null=True)
    startno = models.IntegerField(blank=True, null=True)
    endno = models.IntegerField(blank=True, null=True)
    nextno = models.IntegerField(blank=True, null=True)
    addempcd = models.CharField(max_length=45, blank=True, null=True)
    addpcnm = models.CharField(max_length=45, blank=True, null=True)
    adddt = models.DateTimeField(blank=True, null=True)
    updempcd = models.CharField(max_length=45, blank=True, null=True)
    updpcnm = models.CharField(max_length=45, blank=True, null=True)
    upddt = models.DateTimeField(blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'tbm_syst_ordno'


class TbmSystPlant(models.Model):
    plantcd = models.CharField(primary_key=True, max_length=20)
    plantnm = models.CharField(max_length=255, blank=True, null=True)
    cmpcd = models.CharField(max_length=20)
    addempcd = models.CharField(max_length=50, blank=True, null=True)
    addpcnm = models.CharField(max_length=50, blank=True, null=True)
    adddt = models.DateTimeField(blank=True, null=True)
    updempcd = models.CharField(max_length=50, blank=True, null=True)
    updpcnm = models.CharField(max_length=50, blank=True, null=True)
    upddt = models.DateTimeField(blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'tbm_syst_plant'


class TbmSystRole(models.Model):
    rolecd = models.CharField(primary_key=True, max_length=20)
    rolenm = models.CharField(max_length=50, blank=True, null=True)
    rolestt = models.CharField(max_length=1, blank=True, null=True)
    addempcd = models.CharField(max_length=20, blank=True, null=True)
    addpcnm = models.CharField(max_length=50, blank=True, null=True)
    adddt = models.DateTimeField(blank=True, null=True)
    updempcd = models.CharField(max_length=20, blank=True, null=True)
    updpcnm = models.CharField(max_length=50, blank=True, null=True)
    upddt = models.DateTimeField(blank=True, null=True)
    field1 = models.CharField(max_length=100, blank=True, null=True)
    field2 = models.CharField(max_length=100, blank=True, null=True)
    field3 = models.CharField(max_length=100, blank=True, null=True)
    field4 = models.CharField(max_length=100, blank=True, null=True)
    field5 = models.CharField(max_length=100, blank=True, null=True)
    field6 = models.CharField(max_length=100, blank=True, null=True)
    field7 = models.CharField(max_length=100, blank=True, null=True)
    field8 = models.CharField(max_length=100, blank=True, null=True)
    field9 = models.CharField(max_length=100, blank=True, null=True)
    field10 = models.CharField(max_length=100, blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'tbm_syst_role'


class TbmSystRoleform(models.Model):
    roleformid = models.AutoField(primary_key=True)
    rolecd = models.CharField(max_length=20, blank=True, null=True)
    formcd = models.CharField(max_length=50, blank=True, null=True)
    viewflg = models.CharField(max_length=1, blank=True, null=True)
    addflg = models.CharField(max_length=1, blank=True, null=True)
    saveflg = models.CharField(max_length=1, blank=True, null=True)
    updflg = models.CharField(max_length=1, blank=True, null=True)
    delflg = models.CharField(max_length=1, blank=True, null=True)
    apvflg = models.CharField(max_length=1, blank=True, null=True)
    printflg = models.CharField(max_length=1, blank=True, null=True)
    impflg = models.CharField(max_length=1, blank=True, null=True)
    expflg = models.CharField(max_length=1, blank=True, null=True)
    cancelflg = models.CharField(max_length=1, blank=True, null=True)
    addempcd = models.CharField(max_length=20, blank=True, null=True)
    addpcnm = models.CharField(max_length=50, blank=True, null=True)
    adddt = models.DateTimeField(blank=True, null=True)
    updempcd = models.CharField(max_length=20, blank=True, null=True)
    updpcnm = models.CharField(max_length=50, blank=True, null=True)
    upddt = models.DateTimeField(blank=True, null=True)
    field1 = models.CharField(max_length=255, blank=True, null=True)
    field2 = models.CharField(max_length=255, blank=True, null=True)
    field3 = models.CharField(max_length=255, blank=True, null=True)
    field4 = models.CharField(max_length=255, blank=True, null=True)
    field5 = models.CharField(max_length=255, blank=True, null=True)
    field6 = models.CharField(max_length=255, blank=True, null=True)
    field7 = models.CharField(max_length=255, blank=True, null=True)
    field8 = models.CharField(max_length=255, blank=True, null=True)
    field9 = models.CharField(max_length=255, blank=True, null=True)
    filed10 = models.CharField(max_length=255, blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'tbm_syst_roleform'
        unique_together = (('rolecd', 'formcd'),)


class TbpFacebook(models.Model):
    id = models.BigAutoField(primary_key=True)
    first_name = models.CharField(max_length=255, blank=True, null=True)
    last_name = models.CharField(max_length=255, blank=True, null=True)
    gender = models.CharField(max_length=255, blank=True, null=True)
    links = models.CharField(max_length=255, blank=True, null=True)
    facebook_email = models.CharField(max_length=255, blank=True, null=True)
    id_facebook = models.CharField(max_length=255)
    adddt = models.DateTimeField()

    class Meta:
        managed = False
        db_table = 'tbp_facebook'
        unique_together = (('facebook_email', 'id_facebook'),)


class TbpInvtInvrqs(models.Model):
    vendorno = models.CharField(max_length=1, blank=True, null=True)
    invrqsno = models.CharField(max_length=40)
    invrqsdt = models.DateTimeField()
    duedt = models.DateTimeField()
    plantcd = models.CharField(max_length=50)
    itemcd = models.CharField(max_length=50)
    invtrntpcd = models.CharField(max_length=10, blank=True, null=True)
    invrqsqty = models.DecimalField(max_digits=10, decimal_places=2)
    invwhcd = models.CharField(max_length=20)
    invloccd = models.CharField(max_length=50)
    dealercd = models.CharField(max_length=20, db_collation='utf8_general_ci', blank=True, null=True)
    docno = models.CharField(max_length=50, blank=True, null=True)
    refno = models.CharField(max_length=255, blank=True, null=True)
    rltnordno1 = models.CharField(max_length=50, blank=True, null=True)
    rltnordno2 = models.CharField(max_length=50, blank=True, null=True)
    rltnordno3 = models.CharField(max_length=50, blank=True, null=True)
    lotno = models.CharField(max_length=50, blank=True, null=True)
    rqstt = models.CharField(max_length=1, blank=True, null=True)
    addpcnm = models.CharField(max_length=50, blank=True, null=True)
    adddt = models.DateTimeField(blank=True, null=True)
    filmno = models.CharField(max_length=20, blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'tbp_invt_invrqs'


class TbpInvtInvrqsNovat(models.Model):
    vendorno = models.CharField(max_length=1, blank=True, null=True)
    invrqsno = models.CharField(max_length=40)
    invrqsdt = models.DateTimeField()
    duedt = models.DateTimeField()
    plantcd = models.CharField(max_length=50)
    itemcd = models.CharField(max_length=50)
    invtrntpcd = models.CharField(max_length=10, blank=True, null=True)
    invrqsqty = models.DecimalField(max_digits=10, decimal_places=2)
    invwhcd = models.CharField(max_length=20)
    invloccd = models.CharField(max_length=50)
    dealercd = models.CharField(max_length=20, db_collation='utf8_general_ci', blank=True, null=True)
    docno = models.CharField(max_length=50, blank=True, null=True)
    refno = models.CharField(max_length=255, blank=True, null=True)
    rltnordno1 = models.CharField(max_length=50, blank=True, null=True)
    rltnordno2 = models.CharField(max_length=50, blank=True, null=True)
    rltnordno3 = models.CharField(max_length=50, blank=True, null=True)
    lotno = models.CharField(max_length=50, blank=True, null=True)
    rqstt = models.CharField(max_length=1, blank=True, null=True)
    addpcnm = models.CharField(max_length=50, blank=True, null=True)
    adddt = models.DateTimeField(blank=True, null=True)
    filmno = models.CharField(max_length=20, blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'tbp_invt_invrqs_novat'


class TbpInvtInvrqsVat(models.Model):
    vendorno = models.CharField(max_length=1, blank=True, null=True)
    invrqsno = models.CharField(max_length=40)
    invrqsdt = models.DateTimeField()
    duedt = models.DateTimeField()
    plantcd = models.CharField(max_length=50)
    itemcd = models.CharField(max_length=50)
    invtrntpcd = models.CharField(max_length=10, blank=True, null=True)
    invrqsqty = models.DecimalField(max_digits=10, decimal_places=2)
    invwhcd = models.CharField(max_length=20)
    invloccd = models.CharField(max_length=50)
    dealercd = models.CharField(max_length=20, db_collation='utf8_general_ci', blank=True, null=True)
    docno = models.CharField(max_length=50, blank=True, null=True)
    refno = models.CharField(max_length=255, blank=True, null=True)
    rltnordno1 = models.CharField(max_length=50, blank=True, null=True)
    rltnordno2 = models.CharField(max_length=50, blank=True, null=True)
    rltnordno3 = models.CharField(max_length=50, blank=True, null=True)
    lotno = models.CharField(max_length=50, blank=True, null=True)
    rqstt = models.CharField(max_length=1, blank=True, null=True)
    addpcnm = models.CharField(max_length=50, blank=True, null=True)
    adddt = models.DateTimeField(blank=True, null=True)
    filmno = models.CharField(max_length=20, blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'tbp_invt_invrqs_vat'


class TbpInvtWarrantydealer(models.Model):
    vendorno = models.CharField(max_length=20)
    wrcno = models.CharField(max_length=20)
    wrccode = models.CharField(max_length=20)
    wrcdate = models.DateField()
    dealerno = models.CharField(max_length=50)
    orderno = models.CharField(max_length=50)
    filmno = models.CharField(max_length=50)
    deleteflag = models.CharField(max_length=1)
    filmcode = models.CharField(max_length=50)
    lotno = models.CharField(max_length=50)
    boxno = models.CharField(max_length=50)
    invrqsno = models.CharField(max_length=40)

    class Meta:
        managed = False
        db_table = 'tbp_invt_warrantydealer'


class TbpOnlineSendmail(models.Model):
    warrantyno = models.CharField(max_length=255)
    email = models.CharField(max_length=255)
    logdt = models.DateTimeField()
    completedt = models.DateTimeField()
    sendflg = models.CharField(max_length=255, blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'tbp_online_sendmail'


class TbtInvtInvclm(models.Model):
    invclmno = models.CharField(primary_key=True, max_length=50)
    invclmdt = models.DateTimeField()
    plantcd = models.CharField(max_length=20)
    itemcd = models.CharField(max_length=20)
    uomcd = models.CharField(max_length=20, blank=True, null=True)
    invtrntpcd = models.CharField(max_length=20, blank=True, null=True)
    invclmqty = models.DecimalField(max_digits=10, decimal_places=2)
    invclmsize = models.DecimalField(max_digits=13, decimal_places=2)
    invwhcd = models.CharField(max_length=20)
    invloccd = models.CharField(max_length=20)
    docno = models.CharField(max_length=50, blank=True, null=True)
    refno = models.CharField(max_length=255, blank=True, null=True)
    dealercd = models.CharField(max_length=20, blank=True, null=True)
    invtitemext = models.CharField(max_length=30, blank=True, null=True)
    invtitemint = models.CharField(db_column='invtItemint', max_length=50, blank=True, null=True)  # Field name made lowercase.
    rltnordno1 = models.CharField(max_length=50, blank=True, null=True)
    rltnordno2 = models.CharField(max_length=50, blank=True, null=True)
    rltnordno3 = models.CharField(max_length=50, blank=True, null=True)
    inunitcst = models.DecimalField(max_digits=13, decimal_places=5, blank=True, null=True)
    crcycd = models.CharField(max_length=5, blank=True, null=True)
    crcyrate = models.DecimalField(max_digits=10, decimal_places=5, blank=True, null=True)
    remark = models.CharField(max_length=255, blank=True, null=True)
    clmstt = models.CharField(max_length=1, db_collation='utf8_general_ci', blank=True, null=True)
    lotno = models.CharField(max_length=50, blank=True, null=True)
    ltctrlno = models.CharField(max_length=20, blank=True, null=True)
    rqsdate = models.DateTimeField(blank=True, null=True)
    rqsduedate = models.DateTimeField(blank=True, null=True)
    printed = models.IntegerField(blank=True, null=True)
    addempcd = models.CharField(max_length=50, blank=True, null=True)
    addpcnm = models.CharField(max_length=50, blank=True, null=True)
    adddt = models.DateTimeField(blank=True, null=True)
    updempcd = models.CharField(max_length=50, blank=True, null=True)
    updpcnm = models.CharField(max_length=50, blank=True, null=True)
    upddt = models.DateTimeField(blank=True, null=True)
    cmltempcd = models.CharField(max_length=50, blank=True, null=True)
    cmltpcnm = models.CharField(max_length=50, blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'tbt_invt_invclm'


class TbtInvtInvrct(models.Model):
    invrctno = models.CharField(primary_key=True, max_length=50)
    invrcdt = models.DateTimeField()
    plantcd = models.CharField(max_length=20)
    itemcd = models.CharField(max_length=20)
    uomcd = models.CharField(max_length=20, blank=True, null=True)
    invtrntpcd = models.CharField(max_length=20, blank=True, null=True)
    invrctqty = models.DecimalField(max_digits=10, decimal_places=2)
    invrctsize = models.DecimalField(max_digits=13, decimal_places=2)
    invwhcd = models.CharField(max_length=20)
    invloccd = models.CharField(max_length=20)
    docno = models.CharField(max_length=50, blank=True, null=True)
    refno = models.CharField(max_length=255, blank=True, null=True)
    supcd = models.CharField(max_length=20, blank=True, null=True)
    invtitemext = models.CharField(max_length=30, blank=True, null=True)
    invtitemint = models.CharField(db_column='invtItemint', max_length=50, blank=True, null=True)  # Field name made lowercase.
    rltnordno1 = models.CharField(max_length=50, blank=True, null=True)
    rltnordno2 = models.CharField(max_length=50, blank=True, null=True)
    rltnordno3 = models.CharField(max_length=50, blank=True, null=True)
    inunitcst = models.DecimalField(max_digits=13, decimal_places=5, blank=True, null=True)
    crcycd = models.CharField(max_length=5, blank=True, null=True)
    crcyrate = models.DecimalField(max_digits=10, decimal_places=5, blank=True, null=True)
    remark = models.CharField(max_length=255, blank=True, null=True)
    rctstt = models.CharField(max_length=1, blank=True, null=True)
    lotno = models.CharField(max_length=50, blank=True, null=True)
    ltctrlno = models.CharField(max_length=20, blank=True, null=True)
    printed = models.IntegerField(blank=True, null=True)
    addempcd = models.CharField(max_length=50, blank=True, null=True)
    addpcnm = models.CharField(max_length=50, blank=True, null=True)
    adddt = models.DateTimeField(blank=True, null=True)
    updempcd = models.CharField(max_length=50, blank=True, null=True)
    updpcnm = models.CharField(max_length=50, blank=True, null=True)
    upddt = models.DateTimeField(blank=True, null=True)
    cmltempcd = models.CharField(max_length=50, blank=True, null=True)
    cmltpcnm = models.CharField(max_length=50, blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'tbt_invt_invrct'


class TbtInvtInvrqs(models.Model):
    invrqsno = models.CharField(primary_key=True, max_length=20)
    invrqsdt = models.DateTimeField()
    duedt = models.DateTimeField()
    plantcd = models.CharField(max_length=50)
    itemcd = models.CharField(max_length=50)
    uomcd = models.CharField(max_length=50, blank=True, null=True)
    invtrntpcd = models.CharField(max_length=10, blank=True, null=True)
    invrqsqty = models.DecimalField(max_digits=10, decimal_places=2)
    invwhcd = models.CharField(max_length=20)
    invloccd = models.CharField(max_length=50)
    dealercd = models.CharField(max_length=20, db_collation='utf8_general_ci', blank=True, null=True)
    docno = models.CharField(max_length=50, blank=True, null=True)
    refno = models.CharField(max_length=255, blank=True, null=True)
    invtitemext = models.CharField(max_length=30, blank=True, null=True)
    invtitemint = models.CharField(db_column='invtItemint', max_length=50, blank=True, null=True)  # Field name made lowercase.
    rltnordno1 = models.CharField(max_length=50, blank=True, null=True)
    rltnordno2 = models.CharField(max_length=50, blank=True, null=True)
    rltnordno3 = models.CharField(max_length=50, blank=True, null=True)
    remark = models.CharField(max_length=255, blank=True, null=True)
    lotno = models.CharField(max_length=50, blank=True, null=True)
    ltctrlno = models.CharField(max_length=50, blank=True, null=True)
    warrantyno = models.IntegerField(blank=True, null=True)
    rqstt = models.CharField(max_length=1, blank=True, null=True)
    rqstype = models.CharField(max_length=1)
    addempcd = models.CharField(max_length=50, blank=True, null=True)
    addpcnm = models.CharField(max_length=50, blank=True, null=True)
    adddt = models.DateTimeField(blank=True, null=True)
    updempcd = models.CharField(max_length=50, blank=True, null=True)
    updtpcnm = models.CharField(max_length=50, blank=True, null=True)
    upddt = models.DateTimeField(blank=True, null=True)
    cmltempcd = models.CharField(max_length=50, blank=True, null=True)
    cmltpcnm = models.CharField(max_length=50, blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'tbt_invt_invrqs'


class TbtInvtInvtrf(models.Model):
    invtrfno = models.CharField(primary_key=True, max_length=20)
    invtrfdt = models.DateTimeField()
    plantcd = models.CharField(max_length=50)
    itemcd = models.CharField(max_length=50)
    uomcd = models.CharField(max_length=50, blank=True, null=True)
    invtrntpcd = models.CharField(max_length=10)
    invtrfqty = models.DecimalField(max_digits=10, decimal_places=2)
    invunitcst = models.DecimalField(max_digits=10, decimal_places=2, blank=True, null=True)
    fromwhcd = models.CharField(max_length=20)
    fromloccd = models.CharField(max_length=20)
    towhcd = models.CharField(max_length=20)
    toloccd = models.CharField(max_length=20)
    docno = models.CharField(max_length=50, blank=True, null=True)
    refno = models.CharField(max_length=255, blank=True, null=True)
    invtitemext = models.CharField(max_length=30, blank=True, null=True)
    invtitemint = models.CharField(db_column='invtItemint', max_length=50, blank=True, null=True)  # Field name made lowercase.
    rltnordno1 = models.CharField(max_length=50, blank=True, null=True)
    rltnordno2 = models.CharField(max_length=50, blank=True, null=True)
    rltnordno3 = models.CharField(max_length=50, blank=True, null=True)
    remark = models.CharField(max_length=255, blank=True, null=True)
    invtrfstt = models.CharField(max_length=1)
    lotno = models.CharField(max_length=50, blank=True, null=True)
    ltctrlno = models.CharField(max_length=20, blank=True, null=True)
    addempcd = models.CharField(max_length=50, blank=True, null=True)
    addpcnm = models.CharField(max_length=50, blank=True, null=True)
    adddt = models.DateTimeField(blank=True, null=True)
    updempcd = models.CharField(max_length=50, blank=True, null=True)
    updpcnm = models.CharField(max_length=50, blank=True, null=True)
    upddt = models.DateTimeField(blank=True, null=True)
    cmltempcd = models.CharField(max_length=50, blank=True, null=True)
    cmltpcnm = models.CharField(max_length=50, blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'tbt_invt_invtrf'


class TbtInvtInvtrnrslt(models.Model):
    invtno = models.BigAutoField(primary_key=True)
    invtdt = models.DateTimeField()
    plantcd = models.CharField(max_length=20)
    invtrntpcd = models.CharField(max_length=10)
    invwhcd = models.CharField(max_length=20)
    invloccd = models.CharField(max_length=20)
    itemcd = models.CharField(max_length=20)
    inbsup = models.DecimalField(max_digits=13, decimal_places=5, blank=True, null=True)
    inqty = models.DecimalField(max_digits=10, decimal_places=2, blank=True, null=True)
    inup = models.DecimalField(max_digits=13, decimal_places=5, blank=True, null=True)
    crcycd = models.CharField(max_length=10, blank=True, null=True)
    excrt = models.DecimalField(max_digits=10, decimal_places=5, blank=True, null=True)
    outqty = models.DecimalField(max_digits=10, decimal_places=2, blank=True, null=True)
    blcqty = models.DecimalField(max_digits=10, decimal_places=2, blank=True, null=True)
    blcup = models.DecimalField(max_digits=13, decimal_places=5, blank=True, null=True)
    docno = models.CharField(max_length=50, blank=True, null=True)
    refno = models.CharField(max_length=255, blank=True, null=True)
    invtitemext = models.CharField(max_length=30, blank=True, null=True)
    invtitemint = models.CharField(db_column='invtItemint', max_length=50, blank=True, null=True)  # Field name made lowercase.
    rltnordno1 = models.CharField(max_length=50, blank=True, null=True)
    rltnordno2 = models.CharField(max_length=50, blank=True, null=True)
    rltnordno3 = models.CharField(max_length=50, blank=True, null=True)
    rltnordno4 = models.CharField(max_length=50, blank=True, null=True)
    lotno = models.CharField(max_length=50, blank=True, null=True)
    ltctrlno = models.CharField(max_length=20, blank=True, null=True)
    remark = models.CharField(max_length=255, blank=True, null=True)
    addempcd = models.CharField(max_length=50, blank=True, null=True)
    addpcnm = models.CharField(max_length=50, blank=True, null=True)
    adddt = models.DateTimeField(blank=True, null=True)
    updempcd = models.CharField(max_length=50, blank=True, null=True)
    updpcnm = models.CharField(max_length=50, blank=True, null=True)
    upddt = models.DateTimeField(blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'tbt_invt_invtrnrslt'


class TbtInvtItemctrl(models.Model):
    plantcd = models.CharField(max_length=20)
    itemcd = models.CharField(max_length=20)
    whcd = models.CharField(max_length=20)
    loccd = models.CharField(max_length=20)
    qty = models.DecimalField(max_digits=10, decimal_places=2)
    usedqty = models.DecimalField(max_digits=10, decimal_places=2, blank=True, null=True)
    addempcd = models.CharField(max_length=50, blank=True, null=True)
    addpcnm = models.CharField(max_length=50, blank=True, null=True)
    adddt = models.DateTimeField(blank=True, null=True)
    updempcd = models.CharField(max_length=50, blank=True, null=True)
    updpcnm = models.CharField(max_length=50, blank=True, null=True)
    upddt = models.DateTimeField(blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'tbt_invt_itemctrl'
        unique_together = (('plantcd', 'itemcd', 'whcd', 'loccd'),)


class TbtInvtLtctrl(models.Model):
    ltctrlno = models.CharField(max_length=30)
    receiptdt = models.DateTimeField(blank=True, null=True)
    lotno = models.CharField(max_length=50, blank=True, null=True)
    docno = models.CharField(max_length=50, blank=True, null=True)
    refno = models.CharField(max_length=50, blank=True, null=True)
    invtitemext = models.CharField(max_length=30)
    invtitemint = models.CharField(db_column='invtItemint', max_length=50)  # Field name made lowercase.
    rltnordno1 = models.CharField(max_length=50)
    rltnordno2 = models.CharField(max_length=50)
    rltnordno3 = models.CharField(max_length=50)
    plantcd = models.CharField(max_length=20)
    whcd = models.CharField(max_length=20)
    loccd = models.CharField(max_length=20)
    itemcd = models.CharField(max_length=20)
    qty = models.DecimalField(max_digits=10, decimal_places=2)
    printed = models.IntegerField(blank=True, null=True)
    usedqty = models.DecimalField(max_digits=10, decimal_places=2, blank=True, null=True)
    addempcd = models.CharField(max_length=50, blank=True, null=True)
    addpcnm = models.CharField(max_length=50, blank=True, null=True)
    adddt = models.DateTimeField(blank=True, null=True)
    updempcd = models.CharField(max_length=50, blank=True, null=True)
    updpcnm = models.CharField(max_length=50, blank=True, null=True)
    upddt = models.DateTimeField(blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'tbt_invt_ltctrl'
        unique_together = (('rltnordno1', 'rltnordno2', 'rltnordno3', 'loccd', 'invtitemext', 'invtitemint'), ('ltctrlno', 'plantcd', 'loccd', 'itemcd', 'whcd', 'rltnordno1', 'rltnordno2', 'rltnordno3', 'invtitemext', 'invtitemint'),)


class TbtInvtPetition(models.Model):
    petitionid = models.BigAutoField(primary_key=True)
    receivedate = models.DateField(blank=True, null=True)
    status = models.CharField(max_length=1)
    description = models.TextField(blank=True, null=True)
    dealershowroomcd = models.CharField(max_length=50, blank=True, null=True)
    dealershowroomnm = models.CharField(max_length=255, blank=True, null=True)
    solution = models.TextField(blank=True, null=True)
    closingdate = models.DateField(blank=True, null=True)
    petitiontype = models.CharField(max_length=2, blank=True, null=True)
    doctype = models.CharField(max_length=50, blank=True, null=True)
    warrantyno = models.CharField(max_length=100, blank=True, null=True)
    remark = models.TextField(blank=True, null=True)
    addempcd = models.CharField(max_length=100, blank=True, null=True)
    addpcnm = models.CharField(max_length=100, blank=True, null=True)
    adddt = models.DateField(blank=True, null=True)
    updempcd = models.CharField(max_length=100, blank=True, null=True)
    updpcnm = models.CharField(max_length=100, blank=True, null=True)
    upddt = models.DateField(blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'tbt_invt_petition'


class TbtInvtWarranty(models.Model):
    id = models.BigAutoField(primary_key=True)
    warrantyno = models.CharField(unique=True, max_length=20)
    customerfirstname = models.CharField(max_length=50, blank=True, null=True)
    customerlastname = models.CharField(max_length=50, blank=True, null=True)
    customerage = models.IntegerField(blank=True, null=True)
    customersex = models.CharField(max_length=10, blank=True, null=True)
    customeraddress = models.CharField(max_length=100, blank=True, null=True)
    customertambol = models.CharField(max_length=50, blank=True, null=True)
    customeramphur = models.CharField(max_length=50, blank=True, null=True)
    customerprovince = models.CharField(max_length=50, blank=True, null=True)
    customerpostcode = models.CharField(max_length=10, blank=True, null=True)
    customertel = models.CharField(max_length=50, blank=True, null=True)
    customermb = models.CharField(max_length=50, blank=True, null=True)
    cartype = models.CharField(max_length=20, blank=True, null=True)
    carbrand = models.CharField(max_length=20, blank=True, null=True)
    carmodel = models.CharField(max_length=20, blank=True, null=True)
    cartypeid = models.IntegerField(blank=True, null=True)
    carmodelid = models.IntegerField(blank=True, null=True)
    carbrandid = models.IntegerField(blank=True, null=True)
    customerdistrictid = models.IntegerField(blank=True, null=True)
    customeramphurid = models.IntegerField(blank=True, null=True)
    customerprovinceid = models.CharField(max_length=5, blank=True, null=True)
    carlicenseno = models.CharField(max_length=20, blank=True, null=True)
    carchasis = models.CharField(max_length=20, blank=True, null=True)
    carlicensecolor = models.CharField(max_length=20, blank=True, null=True)
    carregisteryear = models.CharField(max_length=4, blank=True, null=True)
    installdate = models.DateField(blank=True, null=True)
    registerno = models.CharField(max_length=20, blank=True, null=True)
    itemcd = models.CharField(max_length=20, blank=True, null=True)
    dealercd = models.CharField(max_length=20, blank=True, null=True)
    dealernm = models.CharField(max_length=255, blank=True, null=True)
    dealeraddr1 = models.CharField(max_length=255, blank=True, null=True)
    dealeraddr2 = models.CharField(max_length=255, blank=True, null=True)
    dealeramphur = models.CharField(max_length=200, blank=True, null=True)
    dealerprovince = models.CharField(max_length=200, blank=True, null=True)
    dealerpostcode = models.CharField(max_length=20, blank=True, null=True)
    dealertel = models.CharField(max_length=50, blank=True, null=True)
    installationtype = models.CharField(max_length=1, blank=True, null=True)
    installfilmcode = models.CharField(max_length=200, blank=True, null=True)
    installother = models.CharField(max_length=200, blank=True, null=True)
    receivedt = models.DateField(blank=True, null=True)
    dealershowroomcd = models.CharField(max_length=50, blank=True, null=True)
    salecd = models.CharField(max_length=50, db_collation='utf8_general_ci', blank=True, null=True)
    showroom = models.CharField(max_length=255, blank=True, null=True)
    memo = models.TextField(blank=True, null=True)
    printstt = models.CharField(max_length=1, blank=True, null=True)
    warrantystt = models.CharField(max_length=1, blank=True, null=True)
    warning1 = models.CharField(max_length=1, blank=True, null=True)
    warning2 = models.CharField(max_length=1, blank=True, null=True)
    warning3 = models.CharField(max_length=1, blank=True, null=True)
    warning4 = models.CharField(max_length=1, blank=True, null=True)
    warning5 = models.CharField(max_length=1, blank=True, null=True)
    warning6 = models.CharField(max_length=1, blank=True, null=True)
    warning7 = models.CharField(max_length=1, blank=True, null=True)
    warning8 = models.CharField(max_length=1, blank=True, null=True)
    warning9 = models.CharField(max_length=1, blank=True, null=True)
    warningother = models.CharField(max_length=255, blank=True, null=True)
    warrantybookprefix = models.CharField(max_length=100, blank=True, null=True)
    warrantybookrunning = models.CharField(max_length=6, blank=True, null=True)
    addempcd = models.CharField(max_length=100, blank=True, null=True)
    addpcnm = models.CharField(max_length=100, blank=True, null=True)
    adddt = models.DateField(blank=True, null=True)
    updempcd = models.CharField(max_length=100, blank=True, null=True)
    updpcnm = models.CharField(max_length=100, blank=True, null=True)
    upddt = models.DateField(blank=True, null=True)
    email = models.CharField(max_length=50, blank=True, null=True)
    personalid = models.CharField(max_length=50, blank=True, null=True)
    onlineflag = models.CharField(max_length=1)

    class Meta:
        managed = False
        db_table = 'tbt_invt_warranty'


class TbtInvtWarrantyCopy(models.Model):
    id = models.BigAutoField(primary_key=True)
    warrantyno = models.CharField(unique=True, max_length=20)
    customerfirstname = models.CharField(max_length=50, blank=True, null=True)
    customerlastname = models.CharField(max_length=50, blank=True, null=True)
    customerage = models.IntegerField(blank=True, null=True)
    customersex = models.CharField(max_length=10, blank=True, null=True)
    customeraddress = models.CharField(max_length=100, blank=True, null=True)
    customertambol = models.CharField(max_length=50, blank=True, null=True)
    customeramphur = models.CharField(max_length=50, blank=True, null=True)
    customerprovince = models.CharField(max_length=50, blank=True, null=True)
    customerpostcode = models.CharField(max_length=10, blank=True, null=True)
    customertel = models.CharField(max_length=50, blank=True, null=True)
    customermb = models.CharField(max_length=50, blank=True, null=True)
    cartype = models.CharField(max_length=20, blank=True, null=True)
    carbrand = models.CharField(max_length=20, blank=True, null=True)
    carmodel = models.CharField(max_length=20, blank=True, null=True)
    cartypeid = models.IntegerField(blank=True, null=True)
    carmodelid = models.IntegerField(blank=True, null=True)
    carbrandid = models.IntegerField(blank=True, null=True)
    customerdistrictid = models.IntegerField(blank=True, null=True)
    customeramphurid = models.IntegerField(blank=True, null=True)
    customerprovinceid = models.CharField(max_length=5, blank=True, null=True)
    carlicenseno = models.CharField(max_length=20, blank=True, null=True)
    carchasis = models.CharField(max_length=20, blank=True, null=True)
    carlicensecolor = models.CharField(max_length=20, blank=True, null=True)
    carregisteryear = models.CharField(max_length=4, blank=True, null=True)
    installdate = models.DateField(blank=True, null=True)
    registerno = models.CharField(max_length=20, blank=True, null=True)
    itemcd = models.CharField(max_length=20, blank=True, null=True)
    dealercd = models.CharField(max_length=20, blank=True, null=True)
    dealernm = models.CharField(max_length=255, blank=True, null=True)
    dealeraddr1 = models.CharField(max_length=255, blank=True, null=True)
    dealeraddr2 = models.CharField(max_length=255, blank=True, null=True)
    dealeramphur = models.CharField(max_length=200, blank=True, null=True)
    dealerprovince = models.CharField(max_length=200, blank=True, null=True)
    dealerpostcode = models.CharField(max_length=20, blank=True, null=True)
    dealertel = models.CharField(max_length=50, blank=True, null=True)
    installationtype = models.CharField(max_length=1, blank=True, null=True)
    installfilmcode = models.CharField(max_length=200, blank=True, null=True)
    installother = models.CharField(max_length=200, blank=True, null=True)
    receivedt = models.DateField(blank=True, null=True)
    dealershowroomcd = models.CharField(max_length=50, blank=True, null=True)
    salecd = models.CharField(max_length=50, db_collation='utf8_general_ci', blank=True, null=True)
    showroom = models.CharField(max_length=255, blank=True, null=True)
    memo = models.TextField(blank=True, null=True)
    printstt = models.CharField(max_length=1, blank=True, null=True)
    warrantystt = models.CharField(max_length=1, blank=True, null=True)
    warning1 = models.CharField(max_length=1, blank=True, null=True)
    warning2 = models.CharField(max_length=1, blank=True, null=True)
    warning3 = models.CharField(max_length=1, blank=True, null=True)
    warning4 = models.CharField(max_length=1, blank=True, null=True)
    warning5 = models.CharField(max_length=1, blank=True, null=True)
    warning6 = models.CharField(max_length=1, blank=True, null=True)
    warning7 = models.CharField(max_length=1, blank=True, null=True)
    warning8 = models.CharField(max_length=1, blank=True, null=True)
    warning9 = models.CharField(max_length=1, blank=True, null=True)
    warningother = models.CharField(max_length=255, blank=True, null=True)
    warrantybookprefix = models.CharField(max_length=100, blank=True, null=True)
    warrantybookrunning = models.CharField(max_length=6, blank=True, null=True)
    addempcd = models.CharField(max_length=100, blank=True, null=True)
    addpcnm = models.CharField(max_length=100, blank=True, null=True)
    adddt = models.DateField(blank=True, null=True)
    updempcd = models.CharField(max_length=100, blank=True, null=True)
    updpcnm = models.CharField(max_length=100, blank=True, null=True)
    upddt = models.DateField(blank=True, null=True)
    email = models.CharField(max_length=50, blank=True, null=True)
    personalid = models.CharField(max_length=50, blank=True, null=True)
    onlineflag = models.CharField(max_length=1)

    class Meta:
        managed = False
        db_table = 'tbt_invt_warranty_copy'


class TbtInvtWarrantyGift(models.Model):
    id = models.BigAutoField(primary_key=True)
    warrantyno = models.CharField(max_length=20, blank=True, null=True)
    customernm = models.CharField(max_length=50, db_collation='tis620_thai_ci')
    customermb = models.CharField(max_length=50, db_collation='tis620_thai_ci')
    customeraddress = models.CharField(max_length=50, db_collation='tis620_thai_ci')
    address = models.CharField(max_length=50, db_collation='tis620_thai_ci', blank=True, null=True)
    building = models.CharField(max_length=50, db_collation='tis620_thai_ci', blank=True, null=True)
    road = models.CharField(max_length=50, db_collation='tis620_thai_ci')
    customerprovince = models.CharField(max_length=50, db_collation='tis620_thai_ci')
    customeramphur = models.CharField(max_length=50, db_collation='tis620_thai_ci', blank=True, null=True)
    customertambol = models.CharField(max_length=50, db_collation='tis620_thai_ci', blank=True, null=True)
    customerpostcode = models.CharField(max_length=50, db_collation='tis620_thai_ci', blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'tbt_invt_warranty_gift'


class TbtInvtWarrantydealer(models.Model):
    warrantydealerno = models.CharField(primary_key=True, max_length=20)
    invrqsno = models.CharField(max_length=20)
    warrantydealerstt = models.CharField(max_length=1, blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'tbt_invt_warrantydealer'


class TbtInvtWarrantyow(models.Model):
    id = models.BigAutoField(primary_key=True)
    warrantyno = models.CharField(unique=True, max_length=20)
    customerfirstname = models.CharField(max_length=50, blank=True, null=True)
    customerlastname = models.CharField(max_length=50, blank=True, null=True)
    customerage = models.IntegerField(blank=True, null=True)
    customersex = models.CharField(max_length=10, blank=True, null=True)
    customeraddress = models.CharField(max_length=100, blank=True, null=True)
    address = models.CharField(max_length=50)
    building = models.CharField(max_length=50)
    road = models.CharField(max_length=50)
    soi = models.CharField(max_length=50)
    customertambol = models.CharField(max_length=50, blank=True, null=True)
    customeramphur = models.CharField(max_length=50, blank=True, null=True)
    customerprovince = models.CharField(max_length=50, blank=True, null=True)
    customerpostcode = models.CharField(max_length=10, blank=True, null=True)
    customertel = models.CharField(max_length=20, blank=True, null=True)
    customermb = models.CharField(max_length=20, blank=True, null=True)
    customeremail = models.CharField(max_length=255, blank=True, null=True)
    cartype = models.CharField(max_length=20, blank=True, null=True)
    carbrand = models.CharField(max_length=20, blank=True, null=True)
    carmodel = models.CharField(max_length=20, blank=True, null=True)
    cartypeid = models.IntegerField(blank=True, null=True)
    carmodelid = models.IntegerField(blank=True, null=True)
    carbrandid = models.IntegerField(blank=True, null=True)
    customerdistrictid = models.IntegerField(blank=True, null=True)
    customeramphurid = models.IntegerField(blank=True, null=True)
    customerprovinceid = models.CharField(max_length=5, blank=True, null=True)
    carlicenseno = models.CharField(max_length=20, blank=True, null=True)
    carchasis = models.CharField(max_length=20, blank=True, null=True)
    carlicensecolor = models.CharField(max_length=20, blank=True, null=True)
    carregisteryear = models.CharField(max_length=4, blank=True, null=True)
    installdate = models.DateField(blank=True, null=True)
    registerno = models.CharField(max_length=20, blank=True, null=True)
    itemcd = models.CharField(max_length=20, blank=True, null=True)
    dealercd = models.CharField(max_length=20, blank=True, null=True)
    dealernm = models.CharField(max_length=255, blank=True, null=True)
    dealeraddr1 = models.CharField(max_length=255, blank=True, null=True)
    dealeraddr2 = models.CharField(max_length=255, blank=True, null=True)
    dealeramphur = models.CharField(max_length=200, blank=True, null=True)
    dealerprovince = models.CharField(max_length=200, blank=True, null=True)
    dealerpostcode = models.CharField(max_length=20, blank=True, null=True)
    dealertel = models.CharField(max_length=50, blank=True, null=True)
    installationtype = models.CharField(max_length=1, blank=True, null=True)
    installfilmcode = models.CharField(max_length=200, blank=True, null=True)
    installfilmother = models.CharField(max_length=200, blank=True, null=True)
    installother = models.CharField(max_length=200, blank=True, null=True)
    receivedt = models.DateField(blank=True, null=True)
    dealershowroomcd = models.CharField(max_length=50, blank=True, null=True)
    salecd = models.CharField(max_length=50, db_collation='utf8_general_ci', blank=True, null=True)
    showroom = models.CharField(max_length=255, blank=True, null=True)
    memo = models.TextField(blank=True, null=True)
    printstt = models.CharField(max_length=1, blank=True, null=True)
    warrantystt = models.CharField(max_length=1, blank=True, null=True)
    warning1 = models.CharField(max_length=1, blank=True, null=True)
    warning2 = models.CharField(max_length=1, blank=True, null=True)
    warning3 = models.CharField(max_length=1, blank=True, null=True)
    warning4 = models.CharField(max_length=1, blank=True, null=True)
    warning5 = models.CharField(max_length=1, blank=True, null=True)
    warning6 = models.CharField(max_length=1, blank=True, null=True)
    warning7 = models.CharField(max_length=1, blank=True, null=True)
    warning8 = models.CharField(max_length=1, blank=True, null=True)
    warning9 = models.CharField(max_length=1, blank=True, null=True)
    warningother = models.CharField(max_length=255, blank=True, null=True)
    warrantybookprefix = models.CharField(max_length=100, blank=True, null=True)
    warrantybookrunning = models.CharField(max_length=6, blank=True, null=True)
    addempcd = models.CharField(max_length=100, blank=True, null=True)
    addpcnm = models.CharField(max_length=100, blank=True, null=True)
    adddt = models.DateField(blank=True, null=True)
    updempcd = models.CharField(max_length=100, blank=True, null=True)
    updpcnm = models.CharField(max_length=100, blank=True, null=True)
    upddt = models.DateField(blank=True, null=True)
    readflag = models.CharField(max_length=1)
    email = models.CharField(max_length=50, blank=True, null=True)
    hobbies = models.CharField(max_length=255, blank=True, null=True)
    hobbiesname = models.CharField(max_length=255)
    other_hobbies = models.CharField(max_length=255, blank=True, null=True)
    merchandize = models.CharField(max_length=255, blank=True, null=True)
    other_merchandize = models.CharField(max_length=255, blank=True, null=True)
    merchandizename = models.CharField(max_length=100)
    interest_activity_flag = models.CharField(max_length=255, blank=True, null=True)
    interest_activity = models.CharField(max_length=255, blank=True, null=True)
    interestname = models.CharField(max_length=255, blank=True, null=True)
    birthday = models.DateField(blank=True, null=True)
    personalid = models.CharField(max_length=50, blank=True, null=True)
    id_facebook = models.CharField(max_length=255)

    class Meta:
        managed = False
        db_table = 'tbt_invt_warrantyow'


class TbtInvtWarrantyowBk(models.Model):
    id = models.BigAutoField(primary_key=True)
    warrantyno = models.CharField(unique=True, max_length=20)
    customerfirstname = models.CharField(max_length=50, blank=True, null=True)
    customerlastname = models.CharField(max_length=50, blank=True, null=True)
    customerage = models.IntegerField(blank=True, null=True)
    customersex = models.CharField(max_length=10, blank=True, null=True)
    customeraddress = models.CharField(max_length=100, blank=True, null=True)
    address = models.CharField(max_length=50)
    building = models.CharField(max_length=50)
    road = models.CharField(max_length=50)
    soi = models.CharField(max_length=50)
    customertambol = models.CharField(max_length=50, blank=True, null=True)
    customeramphur = models.CharField(max_length=50, blank=True, null=True)
    customerprovince = models.CharField(max_length=50, blank=True, null=True)
    customerpostcode = models.CharField(max_length=10, blank=True, null=True)
    customertel = models.CharField(max_length=50, blank=True, null=True)
    customermb = models.CharField(max_length=50, blank=True, null=True)
    customeremail = models.CharField(max_length=255, blank=True, null=True)
    cartype = models.CharField(max_length=20, blank=True, null=True)
    carbrand = models.CharField(max_length=20, blank=True, null=True)
    carmodel = models.CharField(max_length=20, blank=True, null=True)
    cartypeid = models.IntegerField(blank=True, null=True)
    carmodelid = models.IntegerField(blank=True, null=True)
    carbrandid = models.IntegerField(blank=True, null=True)
    customerdistrictid = models.IntegerField(blank=True, null=True)
    customeramphurid = models.IntegerField(blank=True, null=True)
    customerprovinceid = models.CharField(max_length=5, blank=True, null=True)
    carlicenseno = models.CharField(max_length=20, blank=True, null=True)
    carchasis = models.CharField(max_length=20, blank=True, null=True)
    carlicensecolor = models.CharField(max_length=20, blank=True, null=True)
    carregisteryear = models.CharField(max_length=4, blank=True, null=True)
    installdate = models.DateField(blank=True, null=True)
    registerno = models.CharField(max_length=20, blank=True, null=True)
    itemcd = models.CharField(max_length=20, blank=True, null=True)
    dealercd = models.CharField(max_length=20, blank=True, null=True)
    dealernm = models.CharField(max_length=255, blank=True, null=True)
    dealeraddr1 = models.CharField(max_length=255, blank=True, null=True)
    dealeraddr2 = models.CharField(max_length=255, blank=True, null=True)
    dealeramphur = models.CharField(max_length=200, blank=True, null=True)
    dealerprovince = models.CharField(max_length=200, blank=True, null=True)
    dealerpostcode = models.CharField(max_length=20, blank=True, null=True)
    dealertel = models.CharField(max_length=50, blank=True, null=True)
    installationtype = models.CharField(max_length=1, blank=True, null=True)
    installfilmcode = models.CharField(max_length=200, blank=True, null=True)
    installfilmother = models.CharField(max_length=200, blank=True, null=True)
    installother = models.CharField(max_length=200, blank=True, null=True)
    receivedt = models.DateField(blank=True, null=True)
    dealershowroomcd = models.CharField(max_length=50, blank=True, null=True)
    salecd = models.CharField(max_length=50, db_collation='utf8_general_ci', blank=True, null=True)
    showroom = models.CharField(max_length=255, blank=True, null=True)
    memo = models.TextField(blank=True, null=True)
    printstt = models.CharField(max_length=1, blank=True, null=True)
    warrantystt = models.CharField(max_length=1, blank=True, null=True)
    warning1 = models.CharField(max_length=1, blank=True, null=True)
    warning2 = models.CharField(max_length=1, blank=True, null=True)
    warning3 = models.CharField(max_length=1, blank=True, null=True)
    warning4 = models.CharField(max_length=1, blank=True, null=True)
    warning5 = models.CharField(max_length=1, blank=True, null=True)
    warning6 = models.CharField(max_length=1, blank=True, null=True)
    warning7 = models.CharField(max_length=1, blank=True, null=True)
    warning8 = models.CharField(max_length=1, blank=True, null=True)
    warning9 = models.CharField(max_length=1, blank=True, null=True)
    warningother = models.CharField(max_length=255, blank=True, null=True)
    warrantybookprefix = models.CharField(max_length=100, blank=True, null=True)
    warrantybookrunning = models.CharField(max_length=6, blank=True, null=True)
    addempcd = models.CharField(max_length=100, blank=True, null=True)
    addpcnm = models.CharField(max_length=100, blank=True, null=True)
    adddt = models.DateField(blank=True, null=True)
    updempcd = models.CharField(max_length=100, blank=True, null=True)
    updpcnm = models.CharField(max_length=100, blank=True, null=True)
    upddt = models.DateField(blank=True, null=True)
    readflag = models.CharField(max_length=1)
    email = models.CharField(max_length=50, blank=True, null=True)
    hobbies = models.CharField(max_length=255, blank=True, null=True)
    hobbiesname = models.CharField(max_length=255)
    other_hobbies = models.CharField(max_length=255, blank=True, null=True)
    merchandize = models.CharField(max_length=255, blank=True, null=True)
    other_merchandize = models.CharField(max_length=255, blank=True, null=True)
    merchandizename = models.CharField(max_length=100)
    interest_activity_flag = models.CharField(max_length=255, blank=True, null=True)
    interest_activity = models.CharField(max_length=255, blank=True, null=True)
    interestname = models.CharField(max_length=255, blank=True, null=True)
    birthday = models.DateField(blank=True, null=True)
    id_facebook = models.CharField(max_length=255)

    class Meta:
        managed = False
        db_table = 'tbt_invt_warrantyow_bk'


class TbtInvtWarrantyowBk20180322(models.Model):
    id = models.BigAutoField(primary_key=True)
    warrantyno = models.CharField(unique=True, max_length=20)
    customerfirstname = models.CharField(max_length=50, blank=True, null=True)
    customerlastname = models.CharField(max_length=50, blank=True, null=True)
    customerage = models.IntegerField(blank=True, null=True)
    customersex = models.CharField(max_length=10, blank=True, null=True)
    customeraddress = models.CharField(max_length=100, blank=True, null=True)
    address = models.CharField(max_length=50)
    building = models.CharField(max_length=50)
    road = models.CharField(max_length=50)
    soi = models.CharField(max_length=50)
    customertambol = models.CharField(max_length=50, blank=True, null=True)
    customeramphur = models.CharField(max_length=50, blank=True, null=True)
    customerprovince = models.CharField(max_length=50, blank=True, null=True)
    customerpostcode = models.CharField(max_length=10, blank=True, null=True)
    customertel = models.CharField(max_length=20, blank=True, null=True)
    customermb = models.CharField(max_length=20, blank=True, null=True)
    customeremail = models.CharField(max_length=255, blank=True, null=True)
    cartype = models.CharField(max_length=20, blank=True, null=True)
    carbrand = models.CharField(max_length=20, blank=True, null=True)
    carmodel = models.CharField(max_length=20, blank=True, null=True)
    cartypeid = models.IntegerField(blank=True, null=True)
    carmodelid = models.IntegerField(blank=True, null=True)
    carbrandid = models.IntegerField(blank=True, null=True)
    customerdistrictid = models.IntegerField(blank=True, null=True)
    customeramphurid = models.IntegerField(blank=True, null=True)
    customerprovinceid = models.CharField(max_length=5, blank=True, null=True)
    carlicenseno = models.CharField(max_length=20, blank=True, null=True)
    carchasis = models.CharField(max_length=20, blank=True, null=True)
    carlicensecolor = models.CharField(max_length=20, blank=True, null=True)
    carregisteryear = models.CharField(max_length=4, blank=True, null=True)
    installdate = models.DateField(blank=True, null=True)
    registerno = models.CharField(max_length=20, blank=True, null=True)
    itemcd = models.CharField(max_length=20, blank=True, null=True)
    dealercd = models.CharField(max_length=20, blank=True, null=True)
    dealernm = models.CharField(max_length=255, blank=True, null=True)
    dealeraddr1 = models.CharField(max_length=255, blank=True, null=True)
    dealeraddr2 = models.CharField(max_length=255, blank=True, null=True)
    dealeramphur = models.CharField(max_length=200, blank=True, null=True)
    dealerprovince = models.CharField(max_length=200, blank=True, null=True)
    dealerpostcode = models.CharField(max_length=20, blank=True, null=True)
    dealertel = models.CharField(max_length=50, blank=True, null=True)
    installationtype = models.CharField(max_length=1, blank=True, null=True)
    installfilmcode = models.CharField(max_length=200, blank=True, null=True)
    installfilmother = models.CharField(max_length=200, blank=True, null=True)
    installother = models.CharField(max_length=200, blank=True, null=True)
    receivedt = models.DateField(blank=True, null=True)
    dealershowroomcd = models.CharField(max_length=50, blank=True, null=True)
    salecd = models.CharField(max_length=50, db_collation='utf8_general_ci', blank=True, null=True)
    showroom = models.CharField(max_length=255, blank=True, null=True)
    memo = models.TextField(blank=True, null=True)
    printstt = models.CharField(max_length=1, blank=True, null=True)
    warrantystt = models.CharField(max_length=1, blank=True, null=True)
    warning1 = models.CharField(max_length=1, blank=True, null=True)
    warning2 = models.CharField(max_length=1, blank=True, null=True)
    warning3 = models.CharField(max_length=1, blank=True, null=True)
    warning4 = models.CharField(max_length=1, blank=True, null=True)
    warning5 = models.CharField(max_length=1, blank=True, null=True)
    warning6 = models.CharField(max_length=1, blank=True, null=True)
    warning7 = models.CharField(max_length=1, blank=True, null=True)
    warning8 = models.CharField(max_length=1, blank=True, null=True)
    warning9 = models.CharField(max_length=1, blank=True, null=True)
    warningother = models.CharField(max_length=255, blank=True, null=True)
    warrantybookprefix = models.CharField(max_length=100, blank=True, null=True)
    warrantybookrunning = models.CharField(max_length=6, blank=True, null=True)
    addempcd = models.CharField(max_length=100, blank=True, null=True)
    addpcnm = models.CharField(max_length=100, blank=True, null=True)
    adddt = models.DateField(blank=True, null=True)
    updempcd = models.CharField(max_length=100, blank=True, null=True)
    updpcnm = models.CharField(max_length=100, blank=True, null=True)
    upddt = models.DateField(blank=True, null=True)
    readflag = models.CharField(max_length=1)
    email = models.CharField(max_length=50, blank=True, null=True)
    hobbies = models.CharField(max_length=255, blank=True, null=True)
    hobbiesname = models.CharField(max_length=255)
    other_hobbies = models.CharField(max_length=255, blank=True, null=True)
    merchandize = models.CharField(max_length=255, blank=True, null=True)
    other_merchandize = models.CharField(max_length=255, blank=True, null=True)
    merchandizename = models.CharField(max_length=100)
    interest_activity_flag = models.CharField(max_length=255, blank=True, null=True)
    interest_activity = models.CharField(max_length=255, blank=True, null=True)
    interestname = models.CharField(max_length=255, blank=True, null=True)
    birthday = models.DateField(blank=True, null=True)
    id_facebook = models.CharField(max_length=255)

    class Meta:
        managed = False
        db_table = 'tbt_invt_warrantyow_bk20180322'


class TbtInvtWarrantyowCopy20220518(models.Model):
    id = models.BigAutoField(primary_key=True)
    warrantyno = models.CharField(unique=True, max_length=20)
    customerfirstname = models.CharField(max_length=50, blank=True, null=True)
    customerlastname = models.CharField(max_length=50, blank=True, null=True)
    customerage = models.IntegerField(blank=True, null=True)
    customersex = models.CharField(max_length=10, blank=True, null=True)
    customeraddress = models.CharField(max_length=100, blank=True, null=True)
    address = models.CharField(max_length=50)
    building = models.CharField(max_length=50)
    road = models.CharField(max_length=50)
    soi = models.CharField(max_length=50)
    customertambol = models.CharField(max_length=50, blank=True, null=True)
    customeramphur = models.CharField(max_length=50, blank=True, null=True)
    customerprovince = models.CharField(max_length=50, blank=True, null=True)
    customerpostcode = models.CharField(max_length=10, blank=True, null=True)
    customertel = models.CharField(max_length=20, blank=True, null=True)
    customermb = models.CharField(max_length=20, blank=True, null=True)
    customeremail = models.CharField(max_length=255, blank=True, null=True)
    cartype = models.CharField(max_length=20, blank=True, null=True)
    carbrand = models.CharField(max_length=20, blank=True, null=True)
    carmodel = models.CharField(max_length=20, blank=True, null=True)
    cartypeid = models.IntegerField(blank=True, null=True)
    carmodelid = models.IntegerField(blank=True, null=True)
    carbrandid = models.IntegerField(blank=True, null=True)
    customerdistrictid = models.IntegerField(blank=True, null=True)
    customeramphurid = models.IntegerField(blank=True, null=True)
    customerprovinceid = models.CharField(max_length=5, blank=True, null=True)
    carlicenseno = models.CharField(max_length=20, blank=True, null=True)
    carchasis = models.CharField(max_length=20, blank=True, null=True)
    carlicensecolor = models.CharField(max_length=20, blank=True, null=True)
    carregisteryear = models.CharField(max_length=4, blank=True, null=True)
    installdate = models.DateField(blank=True, null=True)
    registerno = models.CharField(max_length=20, blank=True, null=True)
    itemcd = models.CharField(max_length=20, blank=True, null=True)
    dealercd = models.CharField(max_length=20, blank=True, null=True)
    dealernm = models.CharField(max_length=255, blank=True, null=True)
    dealeraddr1 = models.CharField(max_length=255, blank=True, null=True)
    dealeraddr2 = models.CharField(max_length=255, blank=True, null=True)
    dealeramphur = models.CharField(max_length=200, blank=True, null=True)
    dealerprovince = models.CharField(max_length=200, blank=True, null=True)
    dealerpostcode = models.CharField(max_length=20, blank=True, null=True)
    dealertel = models.CharField(max_length=50, blank=True, null=True)
    installationtype = models.CharField(max_length=1, blank=True, null=True)
    installfilmcode = models.CharField(max_length=200, blank=True, null=True)
    installfilmother = models.CharField(max_length=200, blank=True, null=True)
    installother = models.CharField(max_length=200, blank=True, null=True)
    receivedt = models.DateField(blank=True, null=True)
    dealershowroomcd = models.CharField(max_length=50, blank=True, null=True)
    salecd = models.CharField(max_length=50, db_collation='utf8_general_ci', blank=True, null=True)
    showroom = models.CharField(max_length=255, blank=True, null=True)
    memo = models.TextField(blank=True, null=True)
    printstt = models.CharField(max_length=1, blank=True, null=True)
    warrantystt = models.CharField(max_length=1, blank=True, null=True)
    warning1 = models.CharField(max_length=1, blank=True, null=True)
    warning2 = models.CharField(max_length=1, blank=True, null=True)
    warning3 = models.CharField(max_length=1, blank=True, null=True)
    warning4 = models.CharField(max_length=1, blank=True, null=True)
    warning5 = models.CharField(max_length=1, blank=True, null=True)
    warning6 = models.CharField(max_length=1, blank=True, null=True)
    warning7 = models.CharField(max_length=1, blank=True, null=True)
    warning8 = models.CharField(max_length=1, blank=True, null=True)
    warning9 = models.CharField(max_length=1, blank=True, null=True)
    warningother = models.CharField(max_length=255, blank=True, null=True)
    warrantybookprefix = models.CharField(max_length=100, blank=True, null=True)
    warrantybookrunning = models.CharField(max_length=6, blank=True, null=True)
    addempcd = models.CharField(max_length=100, blank=True, null=True)
    addpcnm = models.CharField(max_length=100, blank=True, null=True)
    adddt = models.DateField(blank=True, null=True)
    updempcd = models.CharField(max_length=100, blank=True, null=True)
    updpcnm = models.CharField(max_length=100, blank=True, null=True)
    upddt = models.DateField(blank=True, null=True)
    readflag = models.CharField(max_length=1)
    email = models.CharField(max_length=50, blank=True, null=True)
    hobbies = models.CharField(max_length=255, blank=True, null=True)
    hobbiesname = models.CharField(max_length=255)
    other_hobbies = models.CharField(max_length=255, blank=True, null=True)
    merchandize = models.CharField(max_length=255, blank=True, null=True)
    other_merchandize = models.CharField(max_length=255, blank=True, null=True)
    merchandizename = models.CharField(max_length=100)
    interest_activity_flag = models.CharField(max_length=255, blank=True, null=True)
    interest_activity = models.CharField(max_length=255, blank=True, null=True)
    interestname = models.CharField(max_length=255, blank=True, null=True)
    birthday = models.DateField(blank=True, null=True)
    personalid = models.CharField(max_length=50, blank=True, null=True)
    id_facebook = models.CharField(max_length=255)

    class Meta:
        managed = False
        db_table = 'tbt_invt_warrantyow_copy20220518'


class TbtInvtWarrantyowCopy20220606(models.Model):
    id = models.BigAutoField(primary_key=True)
    warrantyno = models.CharField(unique=True, max_length=20)
    customerfirstname = models.CharField(max_length=50, blank=True, null=True)
    customerlastname = models.CharField(max_length=50, blank=True, null=True)
    customerage = models.IntegerField(blank=True, null=True)
    customersex = models.CharField(max_length=10, blank=True, null=True)
    customeraddress = models.CharField(max_length=100, blank=True, null=True)
    address = models.CharField(max_length=50)
    building = models.CharField(max_length=50)
    road = models.CharField(max_length=50)
    soi = models.CharField(max_length=50)
    customertambol = models.CharField(max_length=50, blank=True, null=True)
    customeramphur = models.CharField(max_length=50, blank=True, null=True)
    customerprovince = models.CharField(max_length=50, blank=True, null=True)
    customerpostcode = models.CharField(max_length=10, blank=True, null=True)
    customertel = models.CharField(max_length=20, blank=True, null=True)
    customermb = models.CharField(max_length=20, blank=True, null=True)
    customeremail = models.CharField(max_length=255, blank=True, null=True)
    cartype = models.CharField(max_length=20, blank=True, null=True)
    carbrand = models.CharField(max_length=20, blank=True, null=True)
    carmodel = models.CharField(max_length=20, blank=True, null=True)
    cartypeid = models.IntegerField(blank=True, null=True)
    carmodelid = models.IntegerField(blank=True, null=True)
    carbrandid = models.IntegerField(blank=True, null=True)
    customerdistrictid = models.IntegerField(blank=True, null=True)
    customeramphurid = models.IntegerField(blank=True, null=True)
    customerprovinceid = models.CharField(max_length=5, blank=True, null=True)
    carlicenseno = models.CharField(max_length=20, blank=True, null=True)
    carchasis = models.CharField(max_length=20, blank=True, null=True)
    carlicensecolor = models.CharField(max_length=20, blank=True, null=True)
    carregisteryear = models.CharField(max_length=4, blank=True, null=True)
    installdate = models.DateField(blank=True, null=True)
    registerno = models.CharField(max_length=20, blank=True, null=True)
    itemcd = models.CharField(max_length=20, blank=True, null=True)
    dealercd = models.CharField(max_length=20, blank=True, null=True)
    dealernm = models.CharField(max_length=255, blank=True, null=True)
    dealeraddr1 = models.CharField(max_length=255, blank=True, null=True)
    dealeraddr2 = models.CharField(max_length=255, blank=True, null=True)
    dealeramphur = models.CharField(max_length=200, blank=True, null=True)
    dealerprovince = models.CharField(max_length=200, blank=True, null=True)
    dealerpostcode = models.CharField(max_length=20, blank=True, null=True)
    dealertel = models.CharField(max_length=50, blank=True, null=True)
    installationtype = models.CharField(max_length=1, blank=True, null=True)
    installfilmcode = models.CharField(max_length=200, blank=True, null=True)
    installfilmother = models.CharField(max_length=200, blank=True, null=True)
    installother = models.CharField(max_length=200, blank=True, null=True)
    receivedt = models.DateField(blank=True, null=True)
    dealershowroomcd = models.CharField(max_length=50, blank=True, null=True)
    salecd = models.CharField(max_length=50, db_collation='utf8_general_ci', blank=True, null=True)
    showroom = models.CharField(max_length=255, blank=True, null=True)
    memo = models.TextField(blank=True, null=True)
    printstt = models.CharField(max_length=1, blank=True, null=True)
    warrantystt = models.CharField(max_length=1, blank=True, null=True)
    warning1 = models.CharField(max_length=1, blank=True, null=True)
    warning2 = models.CharField(max_length=1, blank=True, null=True)
    warning3 = models.CharField(max_length=1, blank=True, null=True)
    warning4 = models.CharField(max_length=1, blank=True, null=True)
    warning5 = models.CharField(max_length=1, blank=True, null=True)
    warning6 = models.CharField(max_length=1, blank=True, null=True)
    warning7 = models.CharField(max_length=1, blank=True, null=True)
    warning8 = models.CharField(max_length=1, blank=True, null=True)
    warning9 = models.CharField(max_length=1, blank=True, null=True)
    warningother = models.CharField(max_length=255, blank=True, null=True)
    warrantybookprefix = models.CharField(max_length=100, blank=True, null=True)
    warrantybookrunning = models.CharField(max_length=6, blank=True, null=True)
    addempcd = models.CharField(max_length=100, blank=True, null=True)
    addpcnm = models.CharField(max_length=100, blank=True, null=True)
    adddt = models.DateField(blank=True, null=True)
    updempcd = models.CharField(max_length=100, blank=True, null=True)
    updpcnm = models.CharField(max_length=100, blank=True, null=True)
    upddt = models.DateField(blank=True, null=True)
    readflag = models.CharField(max_length=1)
    email = models.CharField(max_length=50, blank=True, null=True)
    hobbies = models.CharField(max_length=255, blank=True, null=True)
    hobbiesname = models.CharField(max_length=255)
    other_hobbies = models.CharField(max_length=255, blank=True, null=True)
    merchandize = models.CharField(max_length=255, blank=True, null=True)
    other_merchandize = models.CharField(max_length=255, blank=True, null=True)
    merchandizename = models.CharField(max_length=100)
    interest_activity_flag = models.CharField(max_length=255, blank=True, null=True)
    interest_activity = models.CharField(max_length=255, blank=True, null=True)
    interestname = models.CharField(max_length=255, blank=True, null=True)
    birthday = models.DateField(blank=True, null=True)
    personalid = models.CharField(max_length=50, blank=True, null=True)
    id_facebook = models.CharField(max_length=255)

    class Meta:
        managed = False
        db_table = 'tbt_invt_warrantyow_copy20220606'
