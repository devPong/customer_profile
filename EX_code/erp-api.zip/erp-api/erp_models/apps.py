from django.apps import AppConfig


class ErpModelsConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'erp_models'
