# from django.http import JsonResponse
# from django.db.models import F, Value
# from django.db.models.functions import Concat
# from django.shortcuts import render
# from django.views.decorators.csrf import csrf_exempt

from erp_models.erp_models import Address as erp_address
from erp_models.erp_models import Province as erp_province
from erp_models.erp_models import District as erp_district
from erp_models.erp_models import Subdistrict as erp_subdistrict
from erp_models.erp_models import PostalCode as erp_zipCode
from erp_models.erp_models import CarType as erp_carType
from erp_models.erp_models import CarBrand as erp_carBrand
from erp_models.erp_models import CarModel as erp_carModel
from erp_models.erp_models import Contact as erp_contact
from erp_models.erp_models import Product as erp_product
from erp_models.erp_models import Sex as erp_gender

from erp_models.erp_models import ServiceItem as erp_warranty

from datetime import datetime
from dateutil.relativedelta import relativedelta
# def checkNone (data):
#     if data == None or 
def get_checkNone(fn_model,field_nm,req_name):
    if req_name != "":
        tmp = fn_model.objects.get(**{field_nm: req_name})
    else: 
        tmp = None
    return tmp
# def get_checkGender(fn_model,field_nm,req_name):
#     if req_name != "":
#         tmp = fn_model.objects.get(**{field_nm: req_name})
#     else: 
#         tmp = None
#     return tmp
def date_checkNone(datedata):
    if len(datedata) == 0:
        return None
    # elif datedata is
    else:
        try:
            dateData = datetime.strptime(datedata, '%Y-%m-%d')
            return dateData
        except:
            return None
    

def update_warrantyOnlineData(request):
    dateTimeNow = datetime.now()
    datetimeNowTxT = dateTimeNow.strftime('%Y-%m-%d %H:%M:%S')

    ##################################################
    ##### data request
    # number_wrt
    # product_code
    # cust_install_date
    # cust_carbrand_id
    # cust_carmodel_id
    # cust_liceseplateblack
    # cust_vin
    # cust_name
    # cust_birthday
    # cust_gender
    # cust_phone
    # cust_mail
    # cust_warrant_exdate
    # cust_address
    # cust_district_id
    # cust_subdistrict_id
    # cust_province_id
    # cust_postalcode
    # showroominstall_id
    ##################################################
    datas = {
        'state':'not_update'
    }
    if request.method == 'POST':
        # datas = request.POST.get('datas')
        cus_gender = get_checkNone(erp_gender,'name', request.POST.get('cust_gender') )
        cus_province = get_checkNone(erp_province,'id',request.POST.get('cust_province_id'))
        cus_district = get_checkNone(erp_district,'id',request.POST.get('cust_district_id'))
        cus_subdistrict = get_checkNone(erp_subdistrict,'id',request.POST.get('cust_subdistrict_id'))
        
        cus_carmodel = get_checkNone(erp_carModel,'id',request.POST.get('cust_carmodel_id'))
        cus_carbrand = get_checkNone(erp_carBrand,'id',request.POST.get('cust_carbrand_id'))
        if cus_carmodel != None:
            tmp_carmodel =  erp_carModel.objects.get(id = request.POST.get('cust_carmodel_id')) 
            cus_cartype = get_checkNone(erp_carType,'id',tmp_carmodel.type_id)
        else:
            cus_cartype = None
        
        showroom_install =get_checkNone(erp_contact,'id',request.POST.get('showroominstall_id'))
        w_product =  get_checkNone(erp_product,'code',request.POST.get('product_code'))
        
        installerDetail_TxT = request.POST.get('frontInstall_position')+": "+request.POST.get('frontInstall_product')+", "+request.POST.get('aroundInstall_position')+": "+request.POST.get('aroundInstall_product')+", "+request.POST.get('anotherInstall_position')+": "+request.POST.get('anotherInstall_product')
        # cus_gender =  erp_gender.objects.get(name = request.POST.get('cust_gender'))
        # cus_province =  erp_province.objects.get(id = request.POST.get('cust_province_id'))
        # cus_district =  erp_district.objects.get(id = request.POST.get('cust_district_id'))
        # cus_subdistrict =  erp_subdistrict.objects.get(id = request.POST.get('cust_subdistrict_id')) 
        # # cus_postalcode =  erp_zipCode.objects.get(code = request.POST.get('cust_postalcode')) 
        # cus_carmodel =  erp_carModel.objects.get(id = request.POST.get('cust_carmodel_id')) 
        # cus_carbrand =  erp_carBrand.objects.get(id = request.POST.get('cust_carbrand_id')) 
        # cus_cartype =  erp_carType.objects.get(id = cus_carmodel.type_id)
        # cus_postalcode =  erp_zipCode.objects.get(id = request.POST.get('cust_postalcode')) 
        # showroom_install = erp_contact.objects.get(id = request.POST.get('showroominstall_id')) 
        # w_product = erp_product.objects.get(code = request.POST.get('product_code'))
        # # cus_postalcode =  erp_gender.objects.get(id = request.POST.get('cust_postalcode')) 
        erp_wNumber = list(erp_warranty.objects.filter(number=request.POST.get('number_wrt')))
        
        temp_installDate = datetime.strptime(request.POST.get('cust_install_date'), '%Y-%m-%d')
        temp_expiryDate = temp_installDate + relativedelta(years=w_product.warranty_duration)
        
        if temp_installDate > dateTimeNow:
            datas['state'] = "error_dateInstall"
            return datas
            
        if  request.POST.get('sys_db') == 'erp' :
            # x=list(erp_warranty.objects.filter(number=request.POST.get('number_wrt')))
            if len(erp_wNumber) > 0 :
                
                # warrantyUpdate =  erp_warranty.objects.get(id=request.POST.get('wID'))
                warrantyUpdate =  erp_warranty.objects.get(number=request.POST.get('number_wrt'))
                warrantyUpdate.cust_name = request.POST.get('cust_name')
                warrantyUpdate.cust_sex_0 = cus_gender
                warrantyUpdate.cust_address = request.POST.get('cust_address')
                warrantyUpdate.cust_subdistrict_id = cus_subdistrict
                warrantyUpdate.cust_district_id = cus_district
                warrantyUpdate.cust_province = cus_province
                warrantyUpdate.cust_postal_code = request.POST.get('cust_postalcode')
                warrantyUpdate.cust_phone = request.POST.get('cust_phone')
                # warrantyUpdate.cust_??? = request.POST.get('cust_mail')
                warrantyUpdate.cust_date = date_checkNone(request.POST.get('cust_install_date'))
                warrantyUpdate.cust_dob = date_checkNone(request.POST.get('cust_birthday'))
                warrantyUpdate.warranty_exp_date = temp_expiryDate #.strftime('%Y-%m-%d')
                warrantyUpdate.cust_car_type_0 = cus_cartype
                warrantyUpdate.cust_car_brand_0 = cus_carbrand
                warrantyUpdate.cust_car_model_0 = cus_carmodel
                warrantyUpdate.cust_license_plate_bk = request.POST.get('cust_liceseplateblack')
                warrantyUpdate.cust_vin = request.POST.get('cust_vin')
                warrantyUpdate.cust_showroom_0 =showroom_install
                # warrantyUpdate.remark = request.POST.get('another_position')
                warrantyUpdate.remark = installerDetail_TxT
                warrantyUpdate.ref = 'customer_online'
                
                warrantyUpdate.save()
                datas['state'] = "updated"
        elif   request.POST.get('sys_db') == 'ai':
            # erpWCheck = list(erp_warranty.objects.filter(number=request.POST.get('number_wrt')).values('id'))[0]
            if len(erp_wNumber) < 1:
                warrantyInsert =  erp_warranty(
                    number = request.POST.get('number_wrt'),
                    product = w_product,
                    cust_name = request.POST.get('cust_name'),
                    cust_sex_0 = cus_gender,
                    cust_address = request.POST.get('cust_address'),
                    cust_subdistrict = cus_subdistrict,
                    cust_district = cus_district,
                    cust_province = cus_province,
                    cust_postal_code = request.POST.get('cust_postalcode'),
                    cust_phone = request.POST.get('cust_phone'),
                    cust_date = date_checkNone(request.POST.get('cust_install_date')),
                    cust_dob = date_checkNone(request.POST.get('cust_birthday')),
                    warranty_exp_date = temp_expiryDate, #.strftime('%Y-%m-%d'),
                    cust_car_type_0 = cus_cartype,    
                    cust_car_brand_0 = cus_carbrand,
                    cust_car_model_0 = cus_carmodel,
                    cust_license_plate_bk = request.POST.get('cust_liceseplateblack'),
                    cust_vin = request.POST.get('cust_vin'),
                    cust_showroom_0 = showroom_install,
                    # remark = request.POST.get('another_position'), 
                    remark = installerDetail_TxT,
                    state = 'active',
                    warranty_type= 'warranty_card',
                    create_time = datetimeNowTxT,
                    write_time = datetimeNowTxT,
                    # contact = showroom_install,
                    ref = 'customer_online_AI'
                )
                warrantyInsert.save()
                datas['state'] = "Inserted"
            else:
                pass
        else:
            pass
           
    return datas