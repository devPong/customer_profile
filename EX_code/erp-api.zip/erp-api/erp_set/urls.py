from django.urls import path,include
from . import views



app_name = 'erp_set'
urlpatterns = [
    path('woupdate',views.warranty_update, name='woupdate'),
    path('upload-wImage/', views.warrantyImage_Upload, name='wImgupload'),
    path('test/', views.testupload, name='test'),
    
]
