from django.core.files.storage import default_storage
from django.core.files.base import ContentFile
from django.http import JsonResponse
from django.db.models import F, Value
from django.db.models.functions import Concat
from django.shortcuts import render
from django.views.decorators.csrf import csrf_exempt
from erp_set.fn_warrantUpdate import update_warrantyOnlineData

warrantyFilePath_base= 'C:\PythonSite\ERP_api\erp-api\staticImg'

@csrf_exempt
def warranty_update(request):
    print ('ff')
    if request.method == 'POST':
        result = update_warrantyOnlineData(request)
        return JsonResponse (result, json_dumps_params={'ensure_ascii': False} ,safe=False)

@csrf_exempt  
def warrantyImage_Upload(request):
    
    if request.method == 'POST' and request.FILES.get('image'):
        fileName = request.POST.get('filename')
        fileReceipt = request.FILES.get('image')
        ext = fileReceipt.name.split('.')[-1]
        print (fileReceipt.name)
        f_path = default_storage.save('warrantyOnlineImg/' + fileName+"."+ext, ContentFile(fileReceipt.read()))
        print (f_path)
        # f_path_txt = warrantyFilePath_base+'media/'+f_path
        # image = request.FILES['image']
        # ImageUpload.objects.create(image=image)
        return JsonResponse({'message': 'Image uploaded successfully!'})
    return JsonResponse({'error': 'No image provided'}, status=400)

def testupload (request):
    return render(request, 'testupload.htm')